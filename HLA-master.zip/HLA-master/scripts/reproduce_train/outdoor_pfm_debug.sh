# #!/bin/bash -l
# export PYTORCH_ALLOC_CONF=expandable_segments:True,max_split_size_mb:128
# export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
# export TORCH_DISTRIBUTED_DEBUG=DETAIL


# SCRIPTPATH=$(dirname $(readlink -f "$0"))
# PROJECT_DIR="${SCRIPTPATH}/../../"

# export PYTHONPATH=$PROJECT_DIR:$PYTHONPATH
# cd $PROJECT_DIR



# # to reproduced the results in our paper, please use:
# TRAIN_IMG_SIZE=832
# data_cfg_path="configs/data/megadepth_trainval_${TRAIN_IMG_SIZE}.py"
# main_cfg_path="configs/jamma/outdoor/final.py"
# n_nodes=1
# n_gpus_per_node=1
# torch_num_workers=16
# batch_size=2
# pin_memory=true
# exp_name="jamma"

# python -u ./train.py \
#     ${data_cfg_path} \
#     ${main_cfg_path} \
#     --exp_name=${exp_name} \
#     --gpus=${n_gpus_per_node} --num_nodes=${n_nodes} --accelerator="gpu"  --strategy="ddp" \
#     --batch_size=${batch_size} --num_workers=${torch_num_workers} --pin_memory=${pin_memory} \
#     --check_val_every_n_epoch=1 \
#     --log_every_n_steps=1000 \
#     --limit_val_batches=1. \
#     --num_sanity_val_steps=10 \
#     --benchmark=True \
#     --max_epochs=30 \


#!/usr/bin/env bash
set -euo pipefail

# HLA/JamMa PFM 训练排障脚本。
# 建议将本文件放在 scripts/reproduce_train/ 下，与 outdoor.sh 放在一起。
# 用法：bash scripts/reproduce_train/outdoor_pfm_debug.sh full
#       bash scripts/reproduce_train/outdoor_pfm_debug.sh raw_ri
#       bash scripts/reproduce_train/outdoor_pfm_debug.sh signed4
#       bash scripts/reproduce_train/outdoor_pfm_debug.sh elu4
# 默认每种模式只训练 50 个 batch，用于定位异常；不是最终性能评测。

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

# 优先使用显式指定的项目根目录，否则兼容放在项目根目录或
# scripts/reproduce_train/ 目录中的情况。
if [[ -n "${PROJECT_DIR:-}" && -f "${PROJECT_DIR}/train.py" ]]; then
    PROJECT_DIR="$(cd -- "${PROJECT_DIR}" && pwd)"
elif [[ -f "${SCRIPT_DIR}/../../train.py" ]]; then
    PROJECT_DIR="$(cd -- "${SCRIPT_DIR}/../.." && pwd)"
elif [[ -f "${SCRIPT_DIR}/train.py" ]]; then
    PROJECT_DIR="${SCRIPT_DIR}"
else
    echo "错误：找不到项目根目录中的 train.py。请把脚本放在项目根目录或 scripts/reproduce_train/ 下，或设置 PROJECT_DIR。" >&2
    exit 2
fi

PFM_MODE="${1:-${HLA_PFM_MODE:-full}}"
case "${PFM_MODE}" in
    full|raw_ri|signed4|relu4|elu4|amplitude4|phase_only) ;;
    *)
        echo "错误：未知 PFM_MODE='${PFM_MODE}'。可选：full, raw_ri, signed4, relu4, elu4, amplitude4, phase_only" >&2
        exit 2
        ;;
esac

# 固定比较条件：各模式分别启动新进程，使用同一 seed、配置、数据与 batch 顺序。
SEED="${SEED:-66}"
RUN_ID="${RUN_ID:-$(date +%Y%m%d_%H%M%S)}"
LIMIT_TRAIN_BATCHES="${LIMIT_TRAIN_BATCHES:-50}"
MAX_EPOCHS="${MAX_EPOCHS:-1}"
LIMIT_VAL_BATCHES="${LIMIT_VAL_BATCHES:-0}"
LOG_EVERY_N_STEPS="${LOG_EVERY_N_STEPS:-10}"

TRAIN_IMG_SIZE=832
data_cfg_path="configs/data/megadepth_trainval_${TRAIN_IMG_SIZE}.py"
main_cfg_path="configs/jamma/outdoor/final.py"
n_nodes=1
n_gpus_per_node=1
torch_num_workers=16
batch_size=2
pin_memory=true
exp_name="${EXP_NAME:-jamma_pfm_${PFM_MODE}_${RUN_ID}}"

if [[ ! -f "${PROJECT_DIR}/src/utils/pfm_training_diagnostics.py" ]]; then
    echo "错误：缺少 src/utils/pfm_training_diagnostics.py。请先安装 PFM 训练诊断版文件。" >&2
    exit 2
fi
if [[ ! -f "${PROJECT_DIR}/src/jamma/mamba_module.py" || ! -f "${PROJECT_DIR}/src/lightning/lightning_jamma.py" ]]; then
    echo "错误：未找到预期的 HLA/JamMa 源文件，请确认项目目录。" >&2
    exit 2
fi

cd "${PROJECT_DIR}"

export PYTHONPATH="${PROJECT_DIR}:${PYTHONPATH:-}"
export PYTORCH_ALLOC_CONF="${PYTORCH_ALLOC_CONF:-expandable_segments:True,max_split_size_mb:128}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
export TORCH_DISTRIBUTED_DEBUG="${TORCH_DISTRIBUTED_DEBUG:-DETAIL}"

# PFM 训练数值诊断。日志按模式和运行时间隔离，避免不同实验混写。
export HLA_PFM_MODE="${PFM_MODE}"
export HLA_PFM_DIAG=1
export HLA_PFM_LOG_EVERY="${HLA_PFM_LOG_EVERY:-1}"
export HLA_PFM_DIAG_DIR="${HLA_PFM_DIAG_DIR:-${PROJECT_DIR}/pfm_logs/${PFM_MODE}_${RUN_ID}}"
mkdir -p "${HLA_PFM_DIAG_DIR}"

# 本次只诊断训练；关闭上一阶段的测试计时和 FLOPs hooks。
unset HLA_REVIEW_TIMING HLA_REVIEW_FLOPS

# Lightning 的 seed_everything(None) 会读取 PL_GLOBAL_SEED。
export PL_GLOBAL_SEED="${SEED}"
export PYTHONHASHSEED="${SEED}"

echo "Project:               ${PROJECT_DIR}"
echo "PFM mode:              ${HLA_PFM_MODE}"
echo "Seed:                  ${SEED}"
echo "Train batches:         ${LIMIT_TRAIN_BATCHES}"
echo "Max epochs:            ${MAX_EPOCHS}"
echo "Validation batches:    ${LIMIT_VAL_BATCHES}"
echo "Diagnostic log dir:    ${HLA_PFM_DIAG_DIR}"
echo "Experiment name:       ${exp_name}"
echo "注意：请确认 ${main_cfg_path} 中 JAMMA.MP=False，以 FP32 先做数值排障。"

python -u ./train.py \
    "${data_cfg_path}" \
    "${main_cfg_path}" \
    --exp_name="${exp_name}" \
    --gpus="${n_gpus_per_node}" --num_nodes="${n_nodes}" --accelerator="gpu" --strategy="ddp" \
    --batch_size="${batch_size}" --num_workers="${torch_num_workers}" --pin_memory="${pin_memory}" \
    --check_val_every_n_epoch=1 \
    --log_every_n_steps="${LOG_EVERY_N_STEPS}" \
    --limit_train_batches="${LIMIT_TRAIN_BATCHES}" \
    --limit_val_batches="${LIMIT_VAL_BATCHES}" \
    --num_sanity_val_steps=0 \
    --benchmark=True \
    --max_epochs="${MAX_EPOCHS}" \
    2>&1 | tee "${HLA_PFM_DIAG_DIR}/train_console.log"

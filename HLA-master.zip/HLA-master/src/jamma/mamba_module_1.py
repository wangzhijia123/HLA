# import torch
# from torch import nn
# import math
# import copy
# from src.jamma.utils.utils import GLU_3

# from functools import partial

# from src.utils.profiler import PassThroughProfiler
# import torch
# import torch.nn as nn
# import torch.nn.functional as F

# import torch.utils.checkpoint as checkpoint
# from timm.models.layers import DropPath, to_2tuple, trunc_normal_
# from src.jamma.transformer import  LocalFeatureTransformer

# import pdb

# class Conv2d_BN_Act(nn.Sequential):
#     def __init__(
#         self,
#         a,
#         b,
#         ks=1,
#         stride=1,
#         pad=0,
#         dilation=1,
#         groups=1,
#         bn_weight_init=1,
#         act=None,
#         drop=None,
#     ):
#         super().__init__()
#         self.inp_channel = a
#         self.out_channel = b
#         self.ks = ks
#         self.pad = pad
#         self.stride = stride
#         self.dilation = dilation
#         self.groups = groups

#         self.add_module(
#             "c", nn.Conv2d(a, b, ks, stride, pad, dilation, groups, bias=False)
#         )
#         bn = nn.GroupNorm(8, b)
#         nn.init.constant_(bn.weight, bn_weight_init)
#         nn.init.constant_(bn.bias, 0)
#         self.add_module("bn", bn)
#         if act != None:
#             self.add_module("a", act)
#         if drop != None:
#             self.add_module("d", nn.Dropout(drop))


# class CIM(nn.Module):
#     """Feature Aggregation, Correlation Injection Module"""

#     def __init__(self):
#         super(CIM, self).__init__()

#         self.drop = 0
#         self.block_dims = [32, 64, 256, 256]
#         self.fc16 = Conv2d_BN_Act(
#             self.block_dims[-1], self.block_dims[-1], 1, drop=self.drop
#         )
#         self.fc8 = Conv2d_BN_Act(
#             self.block_dims[-2], self.block_dims[-1], 1, drop=self.drop
#         )
#         self.att16 = Conv2d_BN_Act(
#             self.block_dims[-1],
#             self.block_dims[-1],
#             1,
#             act=nn.Sigmoid(),
#             drop=self.drop,
#         )

#         self.dwconv8 = nn.Sequential(
#             Conv2d_BN_Act(
#                 self.block_dims[-1],
#                 self.block_dims[-1],
#                 ks=3,
#                 pad=1,
#                 groups=self.block_dims[-1],
#                 act=nn.GELU(),
#             ),
#             Conv2d_BN_Act(self.block_dims[-1], self.block_dims[-1], 1),
#         )

#         self.loftr_16 = LocalFeatureTransformer()

#     def forward(self, f8, f16, mask_c0=None, mask_c1=None):
        
        
#         f16 = self.fc16(f16)    #[2*B, c16, w, h]
#         f16_0, f16_1 = f16.chunk(2, dim=0)  #[B, c16, w, h]
#         f16_0, f16_1 = self.loftr_16(f16_0, f16_1, mask_c0, mask_c1)
#         f16 = torch.cat([f16_0, f16_1], dim=0)
       
#         f16_up = F.interpolate(f16, scale_factor=2.0, mode="bilinear")
#         att16_up = F.interpolate(self.att16(f16), scale_factor=2.0, mode="bilinear")
#         f8 = self.fc8(f8)
#         f8 = self.dwconv8(f8 * att16_up + f16_up)

#         feat_c0, feat_c1 = f8.chunk(2, dim=0)
#         return feat_c0, feat_c1



# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x)
#         x = self.act(x)
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x





# class RoPE(torch.nn.Module):
#     r"""Rotary Positional Embedding.
#     """
#     def __init__(self, shape, base=10000):
#         super(RoPE, self).__init__()

#         channel_dims, feature_dim = shape[:-1], shape[-1]
#         k_max = feature_dim // (2 * len(channel_dims))

#         assert feature_dim % k_max == 0

#         # angles
#         theta_ks = 1 / (base ** (torch.arange(k_max) / k_max))
#         angles = torch.cat([t.unsqueeze(-1) * theta_ks for t in torch.meshgrid([torch.arange(d) for d in channel_dims], indexing='ij')], dim=-1)

#         # rotation
#         rotations_re = torch.cos(angles).unsqueeze(dim=-1)
#         rotations_im = torch.sin(angles).unsqueeze(dim=-1)
#         rotations = torch.cat([rotations_re, rotations_im], dim=-1)
#         self.register_buffer('rotations', rotations)

#     def forward(self, x):
#         if x.dtype != torch.float32:
#             x = x.to(torch.float32)
#         x = torch.view_as_complex(x.reshape(*x.shape[:-1], -1, 2))
#         pe_x = torch.view_as_complex(self.rotations) * x
#         return torch.view_as_real(pe_x).flatten(-2)

        


# class LinearAttention(nn.Module):
#     r""" Linear Attention with LePE and RoPE.

#     Args:
#         dim (int): Number of input channels.
#         num_heads (int): Number of attention heads.
#         qkv_bias (bool, optional):  If True, add a learnable bias to query, key, value. Default: True
#     """

#     def __init__(self, dim, input_resolution, num_heads, rope = False, qkv_bias=True, **kwargs):

#         super().__init__()
#         self.dim = dim
#         self.isrope = rope
#         self.input_resolution = input_resolution
#         self.num_heads = num_heads
#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         # self.elu = nn.ELU()
#         self.relu = nn.ReLU()
#         self.scale = nn.Parameter(torch.zeros(size = (1, 1 ,dim)))
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.rope = RoPE(shape=(input_resolution[0], input_resolution[1], dim))

#     def forward(self, x, source, x_mask=None, source_mask=None) :
#         """
#         Args:
#             x: input features with shape of (B, N, C)
#             x_mask: input mask with shape of (B, h, w)
#         """
        
#         b, n, c = x.shape
#         h = int(n ** 0.5)
#         w = int(n ** 0.5)
#         num_heads = self.num_heads
#         head_dim = c // num_heads

#         focusing_factor = 3
#         q = self.q(x)
#         k = self.k(source)
#         q, k, v = q, k, source      # q, k, v: b, n, c

#         q = self.relu(q) + 1e-6
#         k = self.relu(k) + 1e-6
#         scale = nn.Softplus()(self.scale)
#         q = q / scale
#         k = k / scale
#         q_norm = q.norm(dim=-1, keepdim=True)
#         k_norm = k.norm(dim=-1, keepdim=True)
#         q = q ** focusing_factor
#         k = k ** focusing_factor
#         q = (q / q.norm(dim = -1, keepdim = True))*q_norm
#         k = (k / k.norm(dim = -1, keepdim = True))*k_norm
#         # q = self.elu(q) + 1.0
#         # k = self.elu(k) + 1.0
 
#         if x_mask is not None:
#             x_mask = x_mask.reshape(b,1,n).transpose(1,2)
#             q = q * x_mask
#         if source_mask is not None:
#             source_mask = source_mask.reshape(b,1,n).transpose(1,2)
#             k = k * source_mask
#             v = v * source_mask

#         if self.isrope == True:
#             q_rope = self.rope(q.reshape(b, h, w, c)).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#             k_rope = self.rope(k.reshape(b, h, w, c)).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         else:
#             q_rope = q.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#             k_rope = k.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
    
#         q = q.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         k = k.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         v = v.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)

#         z = 1 / (q @ k.mean(dim=-2, keepdim=True).transpose(-2, -1) + 1e-6)
#         kv = (k_rope.transpose(-2, -1) * (n ** -0.5)) @ (v * (n ** -0.5))
#         x = q_rope @ kv * z

#         x = x.transpose(1, 2).reshape(b, n, c)
#         v = v.transpose(1, 2).reshape(b, h, w, c).permute(0, 3, 1, 2)
#         x = x + self.lepe(v).permute(0, 2, 3, 1).reshape(b, n, c)

#         return x

#     def extra_repr(self) -> str:
#         return f'dim={self.dim}, num_heads={self.num_heads}'


# class MLLABlock(nn.Module):
#     r""" MLLA Block.

#     Args:
#         dim (int): Number of input channels.
#         input_resolution (tuple[int]): Input resulotion.
#         num_heads (int): Number of attention heads.
#         mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
#         qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
#         drop (float, optional): Dropout rate. Default: 0.0
#         drop_path (float, optional): Stochastic depth rate. Default: 0.0
#         act_layer (nn.Module, optional): Activation layer. Default: nn.GELU
#         norm_layer (nn.Module, optional): Normalization layer.  Default: nn.LayerNorm
#     """

#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., rope=False, qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.num_heads = num_heads
#         self.mlp_ratio = mlp_ratio
#         self.input_resolution = input_resolution

#         self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm1 = norm_layer(dim)
#         self.in_proj = nn.Linear(dim, dim)
#         self.act_proj = nn.Linear(dim, dim)
#         self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.act = nn.SiLU()
#         self.attn = LinearAttention(dim=dim, input_resolution=input_resolution, num_heads=num_heads, rope = rope, qkv_bias=qkv_bias)
#         self.out_proj = nn.Linear(dim, dim)
        
#         self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, x, source, x_mask=None, source_mask=None):
        
#         '''
#             x: input feature of shape: [B, L, C]
#         '''
#         H, W = self.input_resolution
#         B, L, C = x.shape

#         x1 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe1(x1.contiguous()).flatten(2).permute(0, 2, 1)
#         source1 = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         source = source + self.cpe1(source1.contiguous()).flatten(2).permute(0, 2, 1)
#         shortcut = x

#         x = self.norm1(x)
#         source = self.norm1(source)
#         act_res = self.act(self.act_proj(x))
#         x = self.in_proj(x).view(B, H, W, C)
#         source = self.in_proj(source).view(B, H, W, C)
#         # x = self.act(self.dwc(x.permute(0, 3, 1, 2))).permute(0, 2, 3, 1).view(B, L, C)
#         x = self.act(self.dwc(x.permute(0, 3, 1, 2).contiguous())).permute(0, 2, 3, 1).view(B, L, C)
#         source = self.act(self.dwc(source.permute(0, 3, 1, 2).contiguous())).permute(0, 2, 3, 1).view(B, L, C)

#         # # Linear Attention
#         x = self.attn(x, source, x_mask, source_mask)
        
#         x = self.out_proj(x * act_res)
#         x = shortcut + x
#         x2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe2(x2.contiguous()).flatten(2).permute(0, 2, 1)

#         # # FFN
#         x = x + self.mlp(self.norm2(x))
#         return x

#     def extra_repr(self) -> str:
#         return f"dim={self.dim}, input_resolution={self.input_resolution}, num_heads={self.num_heads}, " \
#                f"mlp_ratio={self.mlp_ratio}"

# class MLLA(nn.Module):

#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.,):
#         super(MLLA, self).__init__()
#         self.layer_names = ["self", "cross"]*2
        
#         self_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = True,
#         )
#         cross_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = False,    
#         )

#         self.layers = nn.ModuleList(
#             [
#                 (
#                     copy.deepcopy(self_layer)
#                     if _ == "self"
#                     else copy.deepcopy(cross_layer)
#                 )
#                 for _ in self.layer_names
#             ]
#         )
#         self._reset_parameters()

#     def _reset_parameters(self):
#         for p in self.parameters():
#             if p.dim() > 1:
#                 nn.init.xavier_uniform_(p)

#     def forward(self, feat0, feat1, mask0=None, mask1=None, data=None):
#         """
#         Args:
#             feat0 (torch.Tensor): [N, C, H, W]
#             feat1 (torch.Tensor): [N, C, H, W]
#             mask0 (torch.Tensor): [N, H, W]
#             mask1 (torch.Tensor): [N, H, W]
#         """
#         # B, C, H, W = feat0.shape
#         # feat0 = feat0.reshape(B, H*W, C)
#         # feat1 = feat1.reshape(B, H*W, C)
#         for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
#             if name == "self":
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif name == "cross":
#                 feat0 = layer(feat0, feat1, mask0, mask1)
#                 feat1 = layer(feat1, feat0, mask1, mask0)
#             else:
#                 raise KeyError

#         return feat0, feat1



# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()

#         self.nhead = 8  
#         dim = 256
#         input_resolution = [104,104]

#         self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
#         # self.neck = CIM()
       

#     def forward(self, data):
        
#         feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
#         # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
#         # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
#         # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
#         # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)

#         mask_c0 = mask_c1 = None  # mask is useful in training
#         if "mask0" in data:
#             mask_c0, mask_c1 = data["mask0"], data["mask1"]
#         # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
#         # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
#         feat_8_0, feat_8_1 = self.atten(feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
#         # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
#         # B, C, H, W = feat_8_0.shape
#         # feat_c0 = feat_8_0.reshape(B, H*W, C)
#         # feat_c1 = feat_8_1.reshape(B, H*W, C)
#         data.update({
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1
#         })

# import torch
# from torch import nn
# import math
# from src.jamma.utils.utils import GLU_3
# from mamba_ssm import Mamba

# from einops import rearrange, repeat
# try:
#     from mamba_ssm.ops.triton.layernorm_gated import RMSNorm, LayerNorm
# except ImportError:
#     RMSNorm, LayerNorm = None, None
# from src.utils.profiler import PassThroughProfiler
# from mamba_ssm.ops.selective_scan_interface import selective_scan_fn, selective_scan_ref
# import torch.nn.functional as F
# import pdb
# from torch.cuda.amp import autocast



# class ScanJego(nn.Module):
#     def __init__(self, d_inner=256, reduction_ratio=4, step_size=2):
#         super().__init__()
#         self.step_size = step_size


#     def forward(self, desc0, desc1, is_conv=True):
#         desc_2w = torch.cat([desc0, desc1], dim=3)  # [B,C,H,2W]
#         desc_2h = torch.cat([desc0, desc1], dim=2)  # [B,C,2H,W]



#         B, C, H, W_2 = desc_2w.shape
#         _, _, H_2, W = desc_2h.shape

#         step = self.step_size
#         xs = desc_2w.new_empty((B, 4, C, (H // step) * (W_2 // step)))

#         # Top-left: [::step, ::step]
#         xs[:, 0] = desc_2w[:, :, ::step, ::step].contiguous().view(B, C, -1)

#         # Bottom-right transposed: [w, 2w] -> [1::step, 1::step]
#         xs[:, 1] = desc_2h.transpose(2, 3)[:, :, 1::step, 1::step].contiguous().view(B, C, -1)

#         # Top-right flipped
#         xs[:, 2] = desc_2w[:, :, ::step, 1::step].contiguous().view(B, C, -1).flip(dims=[2])

#         # Bottom-left flipped
#         xs[:, 3] = desc_2h.transpose(2, 3)[:, :, ::step, 1::step].contiguous().view(B, C, -1).flip(dims=[2])

#         xs = xs.view(B, 4, C, -1).transpose(2, 3)  # [B, 4, L, C]
#         return xs, H, W

# def merge_jego(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2w[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)
#     y_2w[:, :, ::step_size, 1::step_size] = ys[:, 2].flip([2]).reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, ::step_size] = ys[:, 3].flip([2]).reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# def scan_jego_seq(desc0, desc1, step_size):
#     desc_2w, desc_2h = torch.cat([desc0, desc1], 3), torch.cat([desc0, desc1], 2)
#     _, _, org_h, org_2w = desc_2w.shape
#     B, C, org_2h, org_w = desc_2h.shape

#     H = org_h // step_size
#     W = org_2w // step_size

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2h[:, :, ::step_size, ::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.transpose(dim0=2, dim1=3)[:, :, 1::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]
#     xs[:, 2] = desc_2h[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1).flip([2])  # [h/2, 2w/2]
#     xs[:, 3] = desc_2w.transpose(dim0=2, dim1=3)[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_jego_seq(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2h[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, 2*H, W)
#     y_2w[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, 2*W, H).transpose(dim0=2, dim1=3)
#     y_2h[:, :, ::step_size, 1::step_size] = ys[:, 2].flip([2]).reshape(B, C, 2*H, W)
#     y_2w[:, :, 1::step_size, ::step_size] = ys[:, 3].flip([2]).reshape(B, C, 2*W, H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# def scan_vim(desc0, desc1):
#     B, C, org_h, org_w = desc0.shape
#     desc_2w = torch.cat([desc0, desc1], 3)

#     H = org_h
#     W = desc_2w.shape[3]

#     xs = desc_2w.new_empty((B, 2, C, H*W))

#     xs[:, 0] = desc_2w.view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 2, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_vim(ys, org_h, org_w):
#     B, K, C, L = ys.shape

#     y_2w_f = ys[:, 0].reshape(B, C, org_h, 2*org_w)
#     y_2w_b = ys[:, 1].flip([2]).reshape(B, C, org_h, 2*org_w)
#     y_2w = y_2w_f + y_2w_b
#     desc0, desc1 = torch.chunk(y_2w, 2, dim=3)
#     return desc0, desc1


# def scan_vmamba(desc0, desc1):
#     B, C, org_h, org_w = desc0.shape
#     desc_2w = torch.cat([desc0, desc1], 3)
#     desc_2h = torch.cat([desc0, desc1], 2)

#     H = org_h
#     W = desc_2w.shape[3]

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2w.view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.view(B, C, -1).flip([2])  # [w/2, 2w/2]
#     xs[:, 2] = desc_2h.transpose(dim0=2, dim1=3).contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 3] = desc_2h.transpose(dim0=2, dim1=3).contiguous().view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_vmamba(ys, org_h, org_w):
#     B, K, C, L = ys.shape

#     y_2w_f = ys[:, 0].reshape(B, C, org_h, 2*org_w)
#     y_2w_b = ys[:, 1].flip([2]).reshape(B, C, org_h, 2*org_w)
#     y_2h_f = ys[:, 2].reshape(B, C, org_w, 2*org_h).transpose(2, 3)
#     y_2h_b = ys[:, 3].flip([2]).reshape(B, C, org_w, 2*org_h).transpose(2, 3)
#     y_2w, y_2h = y_2w_f + y_2w_b, y_2h_f + y_2h_b
#     desc0_w, desc1_w = torch.chunk(y_2w, 2, dim=3)
#     desc0_h, desc1_h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_w+desc0_h, desc1_w+desc1_h


# def scan_evmamba(desc0, desc1, step_size):
#     desc_2w, desc_2h = torch.cat([desc0, desc1], 3), torch.cat([desc0, desc1], 2)
#     _, _, org_h, org_2w = desc_2w.shape
#     B, C, org_2h, org_w = desc_2h.shape

#     H = org_h // step_size
#     W = org_2w // step_size

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2w[:, :, ::step_size, ::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2h.transpose(dim0=2, dim1=3)[:, :, 1::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]
#     xs[:, 2] = desc_2w[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 3] = desc_2h.transpose(dim0=2, dim1=3)[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_evmamba(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2w[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)
#     y_2w[:, :, ::step_size, 1::step_size] = ys[:, 2].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, ::step_size] = ys[:, 3].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# class Selective_Scan(nn.Module):
#     def __init__(
#             self,
#             d_model,
#             d_state=16,
#             expand=2.,
#             dt_rank="auto",
#             dt_min=0.001,
#             dt_max=0.1,
#             dt_init="random",
#             dt_scale=1.0,
#             dt_init_floor=1e-4,
#             device=None,
#             dtype=None,
#             **kwargs,
#     ):
#         factory_kwargs = {"device": device, "dtype": dtype}
#         super().__init__()
#         self.d_model = d_model
#         self.d_state = d_state
#         self.expand = expand
#         self.d_inner = int(self.expand * self.d_model)
#         self.dt_rank = math.ceil(self.d_model / 16) if dt_rank == "auto" else dt_rank

#         self.x_proj = nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs)
#         self.x_proj_weight = nn.Parameter(self.x_proj.weight)  # (K=4, N, inner)
#         del self.x_proj

#         self.x_conv_proj = nn.Linear(self.d_inner, self.dt_rank, bias=False, **factory_kwargs)
#         self.x_conv_proj_weight = nn.Parameter(self.x_conv_proj.weight)
#         del self.x_conv_proj

#         self.x_inverse_proj = nn.Linear(self.d_inner, self.d_state, bias=False, **factory_kwargs)
#         self.x_inverse_proj_weight = nn.Parameter(self.x_inverse_proj.weight)
#         del self.x_inverse_proj

#         self.dt_proj = self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
#                          **factory_kwargs)
#         self.dt_proj_weight = nn.Parameter(self.dt_proj.weight)
#         self.dt_proj_bias = nn.Parameter(self.dt_proj.bias) 
#         del self.dt_proj  

#         self.A_logs = self.A_log_init(self.d_state, self.d_inner, copies=1, merge=True)  
#         self.Ds = self.D_init(self.d_inner, copies=1, merge=True)  
#         self.selective_scan = selective_scan_fn

#         # self.alpha = nn.Parameter(torch.tensor(1.0))  # base: dts（当前 token）
#         # self.beta  = nn.Parameter(torch.tensor(0.0))  # local: dts_conv（邻域）
#         # self.tau   = nn.Parameter(torch.tensor(1.0))  # 温度，统一控制尺度



#     @staticmethod
#     def dt_init(dt_rank, d_inner, dt_scale=1.0, dt_init="random", dt_min=0.001, dt_max=0.1, dt_init_floor=1e-4,
#                 **factory_kwargs):
#         dt_proj = nn.Linear(dt_rank, d_inner, bias=True, **factory_kwargs)

#         # Initialize special dt projection to preserve variance at initialization
#         dt_init_std = dt_rank ** -0.5 * dt_scale
#         if dt_init == "constant":
#             nn.init.constant_(dt_proj.weight, dt_init_std)
#         elif dt_init == "random":
#             nn.init.uniform_(dt_proj.weight, -dt_init_std, dt_init_std)
#         else:
#             raise NotImplementedError

#         # Initialize dt bias so that F.softplus(dt_bias) is between dt_min and dt_max
#         dt = torch.exp(
#             torch.rand(d_inner, **factory_kwargs) * (math.log(dt_max) - math.log(dt_min))
#             + math.log(dt_min)
#         ).clamp(min=dt_init_floor)
#         # Inverse of softplus: https://github.com/pytorch/pytorch/issues/72759
#         inv_dt = dt + torch.log(-torch.expm1(-dt))
#         with torch.no_grad():
#             dt_proj.bias.copy_(inv_dt)
#         # Our initialization would set all Linear.bias to zero, need to mark this one as _no_reinit
#         dt_proj.bias._no_reinit = True

#         return dt_proj

#     @staticmethod
#     def A_log_init(d_state, d_inner, copies=1, device=None, merge=True):
#         # S4D real initialization
#         A = repeat(
#             torch.arange(1, d_state + 1, dtype=torch.float32, device=device),
#             "n -> d n",
#             d=d_inner,
#         ).contiguous()
#         A_log = torch.log(A)  # Keep A_log in fp32
#         if copies > 1:
#             A_log = repeat(A_log, "d n -> r d n", r=copies)
#             if merge:
#                 A_log = A_log.flatten(0, 1)
#         A_log = nn.Parameter(A_log)
#         A_log._no_weight_decay = True
#         return A_log

#     @staticmethod
#     def D_init(d_inner, copies=1, device=None, merge=True):
#         # D "skip" parameter
#         D = torch.ones(d_inner, device=device)
#         if copies > 1:
#             D = repeat(D, "n1 -> r n1", r=copies)
#             if merge:
#                 D = D.flatten(0, 1)
#         D = nn.Parameter(D)  # Keep in fp32
#         D._no_weight_decay = True
#         return D

#     def forward_core(self, x: torch.Tensor, x_inverse:torch.Tensor=None):
#         B, L, C = x.shape
#         K = 1
#         xs = x.reshape(B * L, C)
#         x_dbl = F.linear(xs, self.x_proj_weight)
#         dts, Bs, Cs = torch.split(x_dbl, [self.dt_rank, self.d_state, self.d_state], dim=1)
#         dts = torch.einsum("b r l, d r -> b d l", dts.reshape(B, -1, L), self.dt_proj_weight)



#         dts = dts.float()
#         if x_inverse is not None:
#             u = x_inverse.float().view(B, -1, L)
#         else:
#             u = xs.float().view(B, -1, L)

#         Bs = Bs.float().reshape(B, 1, -1, L)
#         Cs = Cs.float().reshape(B, 1, -1, L)  
#         Ds = self.Ds.float().view(-1)
#         As = -torch.exp(self.A_logs).view(-1, self.d_state)
#         dt_proj_bias = self.dt_proj_bias.view(-1)  
        
#         out_y = self.selective_scan(
#             u, dts,
#             As, Bs, Cs, Ds, z=None,
#             delta_bias=dt_proj_bias,
#             delta_softplus=True,
#             return_last_state=False,
#         ).view(B, K, -1, L)
#         assert out_y.dtype == torch.float

#         return out_y[:, 0]

#     def forward(self, x, x_inverse:torch.Tensor=None):
#         # b, l, c = prompt.shape
#         # prompt = prompt.permammute(0, 2, 1).contiguous().view(b, 1, c, l)
#         if x_inverse is not None:
#             y = self.forward_core(x, x_inverse)  # [B, L, C]
#         else:
#             y = self.forward_core(x, )
#         y = y.permute(0, 2, 1).contiguous()
#         return y





# class Mambablock(nn.Module):
#     def __init__(self, dim, d_state, mlp_ratio=1.0):
#         super().__init__()
#         self.dim = dim
#         # Mamba params
#         self.expand = mlp_ratio
#         hidden = int(self.dim * self.expand)
#         self.d_state = d_state
#         self.selectiveScan = Selective_Scan(d_model=self.dim, d_state=self.d_state, expand=2)

#         self.in_norm = nn.LayerNorm(self.dim)
#         self.out_proj = nn.Linear(hidden, self.dim, bias=True)
#         self.in_proj = nn.Linear(self.dim, hidden)

#     def forward(self, x, x_inverse:torch.Tensor=None):

#         shortcut = x
#         if x_inverse is not None:

#             x = self.in_proj(self.in_norm(x))
#             x_inverse = self.in_proj(self.in_norm(x_inverse))
#             # x_conv = self.in_proj(self.in_norm(x_conv))
#             y = self.selectiveScan(x, x_inverse)
#             y = self.out_proj(y)

#         else:

#             x = self.in_proj(self.in_norm(x))
#             # x_conv = self.in_proj(self.in_norm(x_conv))
#             y = self.selectiveScan(x, x_inverse)
#             y = self.out_proj(y)

#         return y + shortcut
    

    
# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, depth,
#                  profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()
#         self.num_layers = depth

#         d_state=16
#         mlp_ratio=2
#         C = feature_dim
 
#         self.layers = nn.ModuleList()
#         for i in range(depth):
#             self.layers.append(Mambablock(
#                 C,
#                 d_state,
#                 mlp_ratio=mlp_ratio
#                 ))
#         self.gamma = nn.Parameter(torch.tensor(0.1))
#         # self.proj_w = nn.Sequential(
#         #     nn.Linear(2*C, 2*C),
#         #     nn.GELU(),
#         #     nn.Linear(2*C, C),
#         # )
#         # self.proj_h = nn.Sequential(
#         #     nn.Linear(2*C, 2*C),
#         #     nn.GELU(),
#         #     nn.Linear(2*C, C),
#         # )
#         self.proj = nn.Linear(2*C, C) 
#         self.aggregator = GLU_3(feature_dim, feature_dim)
#         self.scan_jego = ScanJego(d_inner=feature_dim, reduction_ratio=4, step_size=2)
         
#     def forward(self, data):
#         desc0, desc1 = data['feat_8_0'], data['feat_8_1']
#         desc0, desc1 = desc0.view(data['bs'], -1, data['h_8'], data['w_8']), desc1.view(data['bs'], -1, data['h_8'], data['w_8'])

#         # x_conv, ori_h, ori_w = self.scan_jego(desc0, desc1, True)
#         x, ori_h, ori_w = self.scan_jego(desc0, desc1, False)
#         # prompt_2w, prompt_2h = self.prompt_gen (desc0, desc1)
        
#         for i in range(len(self.layers) // 4):

#             y2 = self.layers[i * 4 + 2](x[:, 2])
#             y1 = self.layers[i * 4 + 1](x[:, 1])
#             y0_fused = torch.cat([x[:, 0], y2.flip(1)], dim=-1)  # [B,L,C] + [B,L,C] -> [B,L,2C]
#             y3_fused = torch.cat([x[:, 3], y1.flip(1)], dim=-1)
            
#             y3_fused = x[:, 3] + self.gamma * self.proj(y3_fused)
#             y0_fused = x[:, 0] + self.gamma * self.proj(y0_fused)

#             y0 = self.layers[i * 4](y0_fused, x[:, 0])
#             y3 = self.layers[i * 4 + 3](y3_fused,  x[:, 3])
#             y = torch.stack([y0, y1, y2, y3], 1).transpose(2, 3)

#         desc0, desc1 = merge_jego(y, ori_h, ori_w, 2)
#         desc = self.aggregator(torch.cat([desc0, desc1], 0))
#         desc0, desc1 = torch.chunk(desc, 2, dim=0)
#         desc0, desc1 = desc0.flatten(2, 3), desc1.flatten(2, 3)
#         data.update({
#             'feat_8_0': desc0,
#             'feat_8_1': desc1,
#         })




# import torch
# from torch import nn
# import math
# from src.jamma.utils.utils import GLU_3
# from mamba_ssm import Mamba

# from einops import rearrange, repeat
# try:
#     from mamba_ssm.ops.triton.layernorm_gated import RMSNorm, LayerNorm
# except ImportError:
#     RMSNorm, LayerNorm = None, None
# from src.utils.profiler import PassThroughProfiler
# from mamba_ssm.ops.selective_scan_interface import selective_scan_fn, selective_scan_ref
# import torch.nn.functional as F
# import pdb
# from torch.cuda.amp import autocast



# class ScanJego(nn.Module):
#     def __init__(self, d_inner=256, reduction_ratio=4, step_size=2):
#         super().__init__()
#         self.step_size = step_size
#         # self.spatial_enhancer = SpatialEnhancer(d_inner=d_inner, reduction_ratio=reduction_ratio)

#     def forward(self, desc0, desc1, is_conv=True):
#         desc_2w = torch.cat([desc0, desc1], dim=3)  # [B,C,H,2W]
#         desc_2h = torch.cat([desc0, desc1], dim=2)  # [B,C,2H,W]

#         # if is_conv:
#         #     desc_2w = self.spatial_enhancer(desc_2w)  # ✅ 自动在正确设备上
#         #     desc_2h = self.spatial_enhancer(desc_2h)

#         B, C, H, W_2 = desc_2w.shape
#         _, _, H_2, W = desc_2h.shape

#         step = self.step_size
#         xs = desc_2w.new_empty((B, 4, C, (H // step) * (W_2 // step)))

#         # Top-left: [::step, ::step]
#         xs[:, 0] = desc_2w[:, :, ::step, ::step].contiguous().view(B, C, -1)

#         # Bottom-right transposed: [w, 2w] -> [1::step, 1::step]
#         xs[:, 1] = desc_2h.transpose(2, 3)[:, :, 1::step, 1::step].contiguous().view(B, C, -1)

#         # Top-right flipped
#         xs[:, 2] = desc_2w[:, :, ::step, 1::step].contiguous().view(B, C, -1).flip(dims=[2])

#         # Bottom-left flipped
#         xs[:, 3] = desc_2h.transpose(2, 3)[:, :, ::step, 1::step].contiguous().view(B, C, -1).flip(dims=[2])

#         xs = xs.view(B, 4, C, -1).transpose(2, 3)  # [B, 4, L, C]
#         return xs, H, W

# def merge_jego(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2w[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)
#     y_2w[:, :, ::step_size, 1::step_size] = ys[:, 2].flip([2]).reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, ::step_size] = ys[:, 3].flip([2]).reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# def scan_jego_seq(desc0, desc1, step_size):
#     desc_2w, desc_2h = torch.cat([desc0, desc1], 3), torch.cat([desc0, desc1], 2)
#     _, _, org_h, org_2w = desc_2w.shape
#     B, C, org_2h, org_w = desc_2h.shape

#     H = org_h // step_size
#     W = org_2w // step_size

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2h[:, :, ::step_size, ::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.transpose(dim0=2, dim1=3)[:, :, 1::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]
#     xs[:, 2] = desc_2h[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1).flip([2])  # [h/2, 2w/2]
#     xs[:, 3] = desc_2w.transpose(dim0=2, dim1=3)[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_jego_seq(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2h[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, 2*H, W)
#     y_2w[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, 2*W, H).transpose(dim0=2, dim1=3)
#     y_2h[:, :, ::step_size, 1::step_size] = ys[:, 2].flip([2]).reshape(B, C, 2*H, W)
#     y_2w[:, :, 1::step_size, ::step_size] = ys[:, 3].flip([2]).reshape(B, C, 2*W, H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# def scan_vim(desc0, desc1):
#     B, C, org_h, org_w = desc0.shape
#     desc_2w = torch.cat([desc0, desc1], 3)

#     H = org_h
#     W = desc_2w.shape[3]

#     xs = desc_2w.new_empty((B, 2, C, H*W))

#     xs[:, 0] = desc_2w.view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 2, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_vim(ys, org_h, org_w):
#     B, K, C, L = ys.shape

#     y_2w_f = ys[:, 0].reshape(B, C, org_h, 2*org_w)
#     y_2w_b = ys[:, 1].flip([2]).reshape(B, C, org_h, 2*org_w)
#     y_2w = y_2w_f + y_2w_b
#     desc0, desc1 = torch.chunk(y_2w, 2, dim=3)
#     return desc0, desc1


# def scan_vmamba(desc0, desc1):
#     B, C, org_h, org_w = desc0.shape
#     desc_2w = torch.cat([desc0, desc1], 3)
#     desc_2h = torch.cat([desc0, desc1], 2)

#     H = org_h
#     W = desc_2w.shape[3]

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2w.view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.view(B, C, -1).flip([2])  # [w/2, 2w/2]
#     xs[:, 2] = desc_2h.transpose(dim0=2, dim1=3).contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 3] = desc_2h.transpose(dim0=2, dim1=3).contiguous().view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_vmamba(ys, org_h, org_w):
#     B, K, C, L = ys.shape

#     y_2w_f = ys[:, 0].reshape(B, C, org_h, 2*org_w)
#     y_2w_b = ys[:, 1].flip([2]).reshape(B, C, org_h, 2*org_w)
#     y_2h_f = ys[:, 2].reshape(B, C, org_w, 2*org_h).transpose(2, 3)
#     y_2h_b = ys[:, 3].flip([2]).reshape(B, C, org_w, 2*org_h).transpose(2, 3)
#     y_2w, y_2h = y_2w_f + y_2w_b, y_2h_f + y_2h_b
#     desc0_w, desc1_w = torch.chunk(y_2w, 2, dim=3)
#     desc0_h, desc1_h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_w+desc0_h, desc1_w+desc1_h


# def scan_evmamba(desc0, desc1, step_size):
#     desc_2w, desc_2h = torch.cat([desc0, desc1], 3), torch.cat([desc0, desc1], 2)
#     _, _, org_h, org_2w = desc_2w.shape
#     B, C, org_2h, org_w = desc_2h.shape

#     H = org_h // step_size
#     W = org_2w // step_size

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2w[:, :, ::step_size, ::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2h.transpose(dim0=2, dim1=3)[:, :, 1::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]
#     xs[:, 2] = desc_2w[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 3] = desc_2h.transpose(dim0=2, dim1=3)[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_evmamba(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2w[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)
#     y_2w[:, :, ::step_size, 1::step_size] = ys[:, 2].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, ::step_size] = ys[:, 3].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# class Selective_Scan(nn.Module):
#     def __init__(
#             self,
#             d_model,
#             d_state=16,
#             expand=2.,
#             dt_rank="auto",
#             dt_min=0.001,
#             dt_max=0.1,
#             dt_init="random",
#             dt_scale=1.0,
#             dt_init_floor=1e-4,
#             device=None,
#             dtype=None,
#             **kwargs,
#     ):
#         factory_kwargs = {"device": device, "dtype": dtype}
#         super().__init__()
#         self.d_model = d_model
#         self.d_state = d_state
#         self.expand = expand
#         self.d_inner = int(self.expand * self.d_model)
#         self.dt_rank = math.ceil(self.d_model / 16) if dt_rank == "auto" else dt_rank

#         self.x_proj = nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs)
#         self.x_proj_weight = nn.Parameter(self.x_proj.weight)  # (K=4, N, inner)
#         del self.x_proj

#         # self.x_inverse_proj = nn.Linear(self.d_inner, self.d_state, bias=False, **factory_kwargs)
#         # self.x_inverse_proj_weight = nn.Parameter(self.x_inverse_proj.weight)
#         # del self.x_inverse_proj

#         self.dt_proj = self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
#                          **factory_kwargs)
#         self.dt_proj_weight = nn.Parameter(self.dt_proj.weight)
#         self.dt_proj_bias = nn.Parameter(self.dt_proj.bias) 
#         del self.dt_proj  

#         self.A_logs = self.A_log_init(self.d_state, self.d_inner, copies=1, merge=True)  
#         self.Ds = self.D_init(self.d_inner, copies=1, merge=True)  
#         self.selective_scan = selective_scan_fn


#     @staticmethod
#     def dt_init(dt_rank, d_inner, dt_scale=1.0, dt_init="random", dt_min=0.001, dt_max=0.1, dt_init_floor=1e-4,
#                 **factory_kwargs):
#         dt_proj = nn.Linear(dt_rank, d_inner, bias=True, **factory_kwargs)

#         # Initialize special dt projection to preserve variance at initialization
#         dt_init_std = dt_rank ** -0.5 * dt_scale
#         if dt_init == "constant":
#             nn.init.constant_(dt_proj.weight, dt_init_std)
#         elif dt_init == "random":
#             nn.init.uniform_(dt_proj.weight, -dt_init_std, dt_init_std)
#         else:
#             raise NotImplementedError

#         # Initialize dt bias so that F.softplus(dt_bias) is between dt_min and dt_max
#         dt = torch.exp(
#             torch.rand(d_inner, **factory_kwargs) * (math.log(dt_max) - math.log(dt_min))
#             + math.log(dt_min)
#         ).clamp(min=dt_init_floor)
#         # Inverse of softplus: https://github.com/pytorch/pytorch/issues/72759
#         inv_dt = dt + torch.log(-torch.expm1(-dt))
#         with torch.no_grad():
#             dt_proj.bias.copy_(inv_dt)
#         # Our initialization would set all Linear.bias to zero, need to mark this one as _no_reinit
#         dt_proj.bias._no_reinit = True

#         return dt_proj

#     @staticmethod
#     def A_log_init(d_state, d_inner, copies=1, device=None, merge=True):
#         # S4D real initialization
#         A = repeat(
#             torch.arange(1, d_state + 1, dtype=torch.float32, device=device),
#             "n -> d n",
#             d=d_inner,
#         ).contiguous()
#         A_log = torch.log(A)  # Keep A_log in fp32
#         if copies > 1:
#             A_log = repeat(A_log, "d n -> r d n", r=copies)
#             if merge:
#                 A_log = A_log.flatten(0, 1)
#         A_log = nn.Parameter(A_log)
#         A_log._no_weight_decay = True
#         return A_log

#     @staticmethod
#     def D_init(d_inner, copies=1, device=None, merge=True):
#         # D "skip" parameter
#         D = torch.ones(d_inner, device=device)
#         if copies > 1:
#             D = repeat(D, "n1 -> r n1", r=copies)
#             if merge:
#                 D = D.flatten(0, 1)
#         D = nn.Parameter(D)  # Keep in fp32
#         D._no_weight_decay = True
#         return D

#     def forward_core(self, x: torch.Tensor, x_fuse:torch.Tensor=None):
#         B, L, C = x.shape
#         K = 1
#         xs = x.reshape(B * L, C)
#         x_dbl = F.linear(xs, self.x_proj_weight)
#         dts, Bs, Cs = torch.split(x_dbl, [self.dt_rank, self.d_state, self.d_state], dim=1)
#         dts = torch.einsum("b r l, d r -> b d l", dts.reshape(B, -1, L), self.dt_proj_weight)

#         dts = dts.float()
#         if x_fuse is not None:
#             u = x_fuse.float().view(B, -1, L)
#         else:
#             u = xs.float().view(B, -1, L)

#         Bs = Bs.float().reshape(B, 1, -1, L)
#         Cs = Cs.float().reshape(B, 1, -1, L)  
#         Ds = self.Ds.float().view(-1)
#         As = -torch.exp(self.A_logs).view(-1, self.d_state)
#         dt_proj_bias = self.dt_proj_bias.view(-1)  
        
#         out_y = self.selective_scan(
#             u, dts,
#             As, Bs, Cs, Ds, z=None,
#             delta_bias=dt_proj_bias,
#             delta_softplus=True,
#             return_last_state=False,
#         ).view(B, K, -1, L)
#         assert out_y.dtype == torch.float

#         return out_y[:, 0]

#     def forward(self, x, x_fuse:torch.Tensor=None):
#         # b, l, c = prompt.shape
#         # prompt = prompt.permammute(0, 2, 1).contiguous().view(b, 1, c, l)
#         y = self.forward_core(x, x_fuse)  # [B, L, C]
#         y = y.permute(0, 2, 1).contiguous()
#         return y




# class Mambablock(nn.Module):
#     def __init__(self, dim, d_state, mlp_ratio=1.0):
#         super().__init__()
#         self.dim = dim
#         # Mamba params
#         self.expand = mlp_ratio
#         hidden = int(self.dim * self.expand)
#         self.d_state = d_state
#         self.selectiveScan = Selective_Scan(d_model=self.dim, d_state=self.d_state, expand=2)

#         self.in_norm = nn.LayerNorm(self.dim)
#         self.out_proj = nn.Linear(hidden, self.dim, bias=True)
#         self.in_proj = nn.Linear(self.dim, hidden)

#     def forward(self, x, x_fuse: torch.Tensor=None):

        
#         if x_fuse is not None:
#             shortcut = x_fuse
#             x = self.in_proj(self.in_norm(x))
#             x_fuse = self.in_proj(self.in_norm(x_fuse))
#             # x_conv = self.in_proj(self.in_norm(x_conv))
#             y = self.selectiveScan(x, x_fuse)
#             y = self.out_proj(y)
#         else:
#             shortcut = x
#             x = self.in_proj(self.in_norm(x))
#             # x_conv = self.in_proj(self.in_norm(x_conv))
#             y = self.selectiveScan(x, x_fuse)
#             y = self.out_proj(y)

#         return y + shortcut
    

    
# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, depth,
#                  profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()
#         self.num_layers = depth

#         d_state=16
#         mlp_ratio=2
#         C = feature_dim
 
#         self.layers = nn.ModuleList()
#         for i in range(depth):
#             self.layers.append(Mambablock(
#                 C,
#                 d_state,
#                 mlp_ratio=mlp_ratio
#                 ))
#         # self.gamma = nn.Parameter(torch.tensor(0.1))

#         # self.proj = nn.Linear(2*C, C)      
#         # self.act = nn.GELU()  
#         self.aggregator = GLU_3(feature_dim, feature_dim)
#         self.scan_jego = ScanJego(d_inner=feature_dim, reduction_ratio=4, step_size=2)
#         # self.prompt_gen = PromptGenerator(d_inner=feature_dim* mlp_ratio)
#     def forward(self, data):
#         desc0, desc1 = data['feat_8_0'], data['feat_8_1']
#         desc0, desc1 = desc0.view(data['bs'], -1, data['h_8'], data['w_8']), desc1.view(data['bs'], -1, data['h_8'], data['w_8'])

#         # x_conv, ori_h, ori_w = self.scan_jego(desc0, desc1, True)
#         x, ori_h, ori_w = self.scan_jego(desc0, desc1, False)
#         # prompt_2w, prompt_2h = self.prompt_gen (desc0, desc1)
        
#         for i in range(len(self.layers) // 4):

#             y2 = self.layers[i * 4 + 2](x[:, 2])
#             y1 = self.layers[i * 4 + 1](x[:, 1])
#             y0_fused = torch.cat([x[:, 0], y2.flip(1)], dim=-1)  # [B,L,C] + [B,L,C] -> [B,L,2C]
#             y3_fused = torch.cat([x[:, 3], y1.flip(1)], dim=-1)
            
#             y3_fused = x[:, 3] + self.gamma * self.act(self.proj(y3_fused))
#             y0_fused = x[:, 0] + self.gamma * self.act(self.proj(y0_fused))

#             y0 = self.layers[i * 4](y0_fused, x[:, 0])
#             y3 = self.layers[i * 4 + 3](y3_fused, x[:, 3])
#             # y0 = self.layers[i * 4](x[:, 0])
#             # y3 = self.layers[i * 4 + 3](x[:, 3])
#             y = torch.stack([y0, y1, y2, y3], 1).transpose(2, 3)

#         desc0, desc1 = merge_jego(y, ori_h, ori_w, 2)
#         desc = self.aggregator(torch.cat([desc0, desc1], 0))
#         desc0, desc1 = torch.chunk(desc, 2, dim=0)
#         desc0, desc1 = desc0.flatten(2, 3), desc1.flatten(2, 3)
#         data.update({
#             'feat_8_0': desc0,
#             'feat_8_1': desc1,
#         })



# import torch
# from torch import nn
# import math
# from src.jamma.utils.utils import GLU_3
# from mamba_ssm import Mamba

# from einops import rearrange, repeat
# try:
#     from mamba_ssm.ops.triton.layernorm_gated import RMSNorm, LayerNorm
# except ImportError:
#     RMSNorm, LayerNorm = None, None
# from src.utils.profiler import PassThroughProfiler
# from mamba_ssm.ops.selective_scan_interface import selective_scan_fn, selective_scan_ref
# import torch.nn.functional as F
# import pdb
# from torch.cuda.amp import autocast



# class ScanJego(nn.Module):
#     def __init__(self, d_inner=256, reduction_ratio=4, step_size=2):
#         super().__init__()
#         self.step_size = step_size
#         # self.spatial_enhancer = SpatialEnhancer(d_inner=d_inner, reduction_ratio=reduction_ratio)

#     def forward(self, desc0, desc1, is_conv=True):
#         desc_2w = torch.cat([desc0, desc1], dim=3)  # [B,C,H,2W]
#         desc_2h = torch.cat([desc0, desc1], dim=2)  # [B,C,2H,W]

#         # if is_conv:
#         #     desc_2w = self.spatial_enhancer(desc_2w)  # ✅ 自动在正确设备上
#         #     desc_2h = self.spatial_enhancer(desc_2h)

#         B, C, H, W_2 = desc_2w.shape
#         _, _, H_2, W = desc_2h.shape

#         step = self.step_size
#         xs = desc_2w.new_empty((B, 4, C, (H // step) * (W_2 // step)))

#         # Top-left: [::step, ::step]
#         xs[:, 0] = desc_2w[:, :, ::step, ::step].contiguous().view(B, C, -1)

#         # Bottom-right transposed: [w, 2w] -> [1::step, 1::step]
#         xs[:, 1] = desc_2h.transpose(2, 3)[:, :, 1::step, 1::step].contiguous().view(B, C, -1)

#         # Top-right flipped
#         xs[:, 2] = desc_2w[:, :, ::step, 1::step].contiguous().view(B, C, -1).flip(dims=[2])

#         # Bottom-left flipped
#         xs[:, 3] = desc_2h.transpose(2, 3)[:, :, ::step, 1::step].contiguous().view(B, C, -1).flip(dims=[2])

#         xs = xs.view(B, 4, C, -1).transpose(2, 3)  # [B, 4, L, C]
#         return xs, H, W

# def merge_jego(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2w[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)
#     y_2w[:, :, ::step_size, 1::step_size] = ys[:, 2].flip([2]).reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, ::step_size] = ys[:, 3].flip([2]).reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# def scan_jego_seq(desc0, desc1, step_size):
#     desc_2w, desc_2h = torch.cat([desc0, desc1], 3), torch.cat([desc0, desc1], 2)
#     _, _, org_h, org_2w = desc_2w.shape
#     B, C, org_2h, org_w = desc_2h.shape

#     H = org_h // step_size
#     W = org_2w // step_size

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2h[:, :, ::step_size, ::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.transpose(dim0=2, dim1=3)[:, :, 1::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]
#     xs[:, 2] = desc_2h[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1).flip([2])  # [h/2, 2w/2]
#     xs[:, 3] = desc_2w.transpose(dim0=2, dim1=3)[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_jego_seq(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2h[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, 2*H, W)
#     y_2w[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, 2*W, H).transpose(dim0=2, dim1=3)
#     y_2h[:, :, ::step_size, 1::step_size] = ys[:, 2].flip([2]).reshape(B, C, 2*H, W)
#     y_2w[:, :, 1::step_size, ::step_size] = ys[:, 3].flip([2]).reshape(B, C, 2*W, H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# def scan_vim(desc0, desc1):
#     B, C, org_h, org_w = desc0.shape
#     desc_2w = torch.cat([desc0, desc1], 3)

#     H = org_h
#     W = desc_2w.shape[3]

#     xs = desc_2w.new_empty((B, 2, C, H*W))

#     xs[:, 0] = desc_2w.view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 2, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_vim(ys, org_h, org_w):
#     B, K, C, L = ys.shape

#     y_2w_f = ys[:, 0].reshape(B, C, org_h, 2*org_w)
#     y_2w_b = ys[:, 1].flip([2]).reshape(B, C, org_h, 2*org_w)
#     y_2w = y_2w_f + y_2w_b
#     desc0, desc1 = torch.chunk(y_2w, 2, dim=3)
#     return desc0, desc1


# def scan_vmamba(desc0, desc1):
#     B, C, org_h, org_w = desc0.shape
#     desc_2w = torch.cat([desc0, desc1], 3)
#     desc_2h = torch.cat([desc0, desc1], 2)

#     H = org_h
#     W = desc_2w.shape[3]

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2w.view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.view(B, C, -1).flip([2])  # [w/2, 2w/2]
#     xs[:, 2] = desc_2h.transpose(dim0=2, dim1=3).contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 3] = desc_2h.transpose(dim0=2, dim1=3).contiguous().view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_vmamba(ys, org_h, org_w):
#     B, K, C, L = ys.shape

#     y_2w_f = ys[:, 0].reshape(B, C, org_h, 2*org_w)
#     y_2w_b = ys[:, 1].flip([2]).reshape(B, C, org_h, 2*org_w)
#     y_2h_f = ys[:, 2].reshape(B, C, org_w, 2*org_h).transpose(2, 3)
#     y_2h_b = ys[:, 3].flip([2]).reshape(B, C, org_w, 2*org_h).transpose(2, 3)
#     y_2w, y_2h = y_2w_f + y_2w_b, y_2h_f + y_2h_b
#     desc0_w, desc1_w = torch.chunk(y_2w, 2, dim=3)
#     desc0_h, desc1_h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_w+desc0_h, desc1_w+desc1_h


# def scan_evmamba(desc0, desc1, step_size):
#     desc_2w, desc_2h = torch.cat([desc0, desc1], 3), torch.cat([desc0, desc1], 2)
#     _, _, org_h, org_2w = desc_2w.shape
#     B, C, org_2h, org_w = desc_2h.shape

#     H = org_h // step_size
#     W = org_2w // step_size

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2w[:, :, ::step_size, ::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2h.transpose(dim0=2, dim1=3)[:, :, 1::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]
#     xs[:, 2] = desc_2w[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 3] = desc_2h.transpose(dim0=2, dim1=3)[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_evmamba(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2w[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)
#     y_2w[:, :, ::step_size, 1::step_size] = ys[:, 2].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, ::step_size] = ys[:, 3].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# class Selective_Scan(nn.Module):
#     def __init__(
#             self,
#             d_model,
#             d_state=16,
#             expand=2.,
#             dt_rank="auto",
#             dt_min=0.001,
#             dt_max=0.1,
#             dt_init="random",
#             dt_scale=1.0,
#             dt_init_floor=1e-4,
#             device=None,
#             dtype=None,
#             **kwargs,
#     ):
#         factory_kwargs = {"device": device, "dtype": dtype}
#         super().__init__()
#         self.d_model = d_model
#         self.d_state = d_state
#         self.expand = expand
#         self.d_inner = int(self.expand * self.d_model)
#         self.dt_rank = math.ceil(self.d_model / 16) if dt_rank == "auto" else dt_rank

#         self.x_proj = nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs)
#         self.x_proj_weight = nn.Parameter(self.x_proj.weight)  # (K=4, N, inner)
#         del self.x_proj

#         self.dt_proj = self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
#                          **factory_kwargs)
#         self.dt_proj_weight = nn.Parameter(self.dt_proj.weight)
#         self.dt_proj_bias = nn.Parameter(self.dt_proj.bias) 
#         del self.dt_proj  

#         self.conv1d = nn.Conv1d(
#             in_channels=d_inner,
#             out_channels=d_inner,
#             kernel_size=4,
#             groups=d_inner,
#             padding=4// 2,
#         )
#         self.act = nn.SiLU()

#         self.A_logs = self.A_log_init(self.d_state, self.d_inner, copies=1, merge=True)  
#         self.Ds = self.D_init(self.d_inner, copies=1, merge=True)  
#         self.selective_scan = selective_scan_fn


#     @staticmethod
#     def dt_init(dt_rank, d_inner, dt_scale=1.0, dt_init="random", dt_min=0.001, dt_max=0.1, dt_init_floor=1e-4,
#                 **factory_kwargs):
#         dt_proj = nn.Linear(dt_rank, d_inner, bias=True, **factory_kwargs)

#         # Initialize special dt projection to preserve variance at initialization
#         dt_init_std = dt_rank ** -0.5 * dt_scale
#         if dt_init == "constant":
#             nn.init.constant_(dt_proj.weight, dt_init_std)
#         elif dt_init == "random":
#             nn.init.uniform_(dt_proj.weight, -dt_init_std, dt_init_std)
#         else:
#             raise NotImplementedError

#         # Initialize dt bias so that F.softplus(dt_bias) is between dt_min and dt_max
#         dt = torch.exp(
#             torch.rand(d_inner, **factory_kwargs) * (math.log(dt_max) - math.log(dt_min))
#             + math.log(dt_min)
#         ).clamp(min=dt_init_floor)
#         # Inverse of softplus: https://github.com/pytorch/pytorch/issues/72759
#         inv_dt = dt + torch.log(-torch.expm1(-dt))
#         with torch.no_grad():
#             dt_proj.bias.copy_(inv_dt)
#         # Our initialization would set all Linear.bias to zero, need to mark this one as _no_reinit
#         dt_proj.bias._no_reinit = True

#         return dt_proj

#     @staticmethod
#     def A_log_init(d_state, d_inner, copies=1, device=None, merge=True):
#         # S4D real initialization
#         A = repeat(
#             torch.arange(1, d_state + 1, dtype=torch.float32, device=device),
#             "n -> d n",
#             d=d_inner,
#         ).contiguous()
#         A_log = torch.log(A)  # Keep A_log in fp32
#         if copies > 1:
#             A_log = repeat(A_log, "d n -> r d n", r=copies)
#             if merge:
#                 A_log = A_log.flatten(0, 1)
#         A_log = nn.Parameter(A_log)
#         A_log._no_weight_decay = True
#         return A_log

#     @staticmethod
#     def D_init(d_inner, copies=1, device=None, merge=True):
#         # D "skip" parameter
#         D = torch.ones(d_inner, device=device)
#         if copies > 1:
#             D = repeat(D, "n1 -> r n1", r=copies)
#             if merge:
#                 D = D.flatten(0, 1)
#         D = nn.Parameter(D)  # Keep in fp32
#         D._no_weight_decay = True
#         return D

#     def forward_core(self, x: torch.Tensor, x_fuse:torch.Tensor=None, z):
#         B, L, C = x.shape
#         x = self.act(self.conv1d(x.permute(0, 2, 1).contiguous()))
#         K = 1
#         xs = x.permute(0, 2, 1).reshape(B * L, C)
#         x_dbl = F.linear(xs, self.x_proj_weight)
#         dts, Bs, Cs = torch.split(x_dbl, [self.dt_rank, self.d_state, self.d_state], dim=1)
#         dts = torch.einsum("b r l, d r -> b d l", dts.reshape(B, -1, L), self.dt_proj_weight)

#         dts = dts.float()
#         if x_fuse is not None:
#             u = x_fuse.float().view(B, -1, L)
#         else:
#             u = x.float().view(B, -1, L)

#         Bs = Bs.float().reshape(B, 1, -1, L)
#         Cs = Cs.float().reshape(B, 1, -1, L)  
#         Ds = self.Ds.float().view(-1)
#         As = -torch.exp(self.A_logs).view(-1, self.d_state)
#         dt_proj_bias = self.dt_proj_bias.view(-1)  
        
#         out_y = self.selective_scan(
#             u, dts,
#             As, Bs, Cs, Ds, z=z.float(),
#             delta_bias=dt_proj_bias,
#             delta_softplus=True,
#             return_last_state=False,
#         ).view(B, K, -1, L)
#         assert out_y.dtype == torch.float

#         return out_y[:, 0]

#     def forward(self, x, x_fuse:torch.Tensor=None, z):
#         # b, l, c = prompt.shape
#         # prompt = prompt.permammute(0, 2, 1).contiguous().view(b, 1, c, l)
#         y = self.forward_core(x, x_fuse, z)  # [B, L, C]
#         y = y.permute(0, 2, 1).contiguous()
#         return y




# class Mambablock(nn.Module):
#     def __init__(self, dim, d_state, mlp_ratio=1.0):
#         super().__init__()
#         self.dim = dim
#         # Mamba params
#         self.expand = mlp_ratio
#         hidden = int(self.dim * self.expand)
#         self.d_state = d_state
#         self.selectiveScan = Selective_Scan(d_model=self.dim, d_state=self.d_state, expand=2)

#         self.in_norm = nn.LayerNorm(self.dim)
#         self.out_proj = nn.Linear(hidden, self.dim, bias=True)
#         self.in_proj = nn.Linear(self.dim, 2*hidden)

#     def forward(self, x, x_fuse: torch.Tensor=None):

        
#         if x_fuse is not None:
#             shortcut = x_fuse
#             xz = self.in_proj(self.in_norm(x))
#             x, z = torch.chunk(xz, 2, dim=-1)
#             x_fuse = self.in_proj(self.in_norm(x_fuse))
#             x, z = torch.chunk(xz, 2, dim=-1)
#             y = self.selectiveScan(x, x_fuse, z)
#             y = self.out_proj(y)
#         else:
#             shortcut = x
#             xz = self.in_proj(self.in_norm(x))
#             x, z = torch.chunk(xz, 2, dim=-1)
#             y = self.selectiveScan(x, x_fuse, z)
#             y = self.out_proj(y)

#         return y + shortcut
    

    
# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, depth,
#                  profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()
#         self.num_layers = depth

#         d_state=16
#         mlp_ratio=2
#         C = feature_dim
 
#         self.layers = nn.ModuleList()
#         for i in range(depth):
#             self.layers.append(Mambablock(
#                 C,
#                 d_state,
#                 mlp_ratio=mlp_ratio
#                 ))
#         self.gamma = nn.Parameter(torch.tensor(0.1))

#         self.proj = nn.Linear(2*C, C)      
#         self.act = nn.GELU()  
#         self.aggregator = GLU_3(feature_dim, feature_dim)
#         self.scan_jego = ScanJego(d_inner=feature_dim, reduction_ratio=4, step_size=2)
#         # self.prompt_gen = PromptGenerator(d_inner=feature_dim* mlp_ratio)
#     def forward(self, data):
#         desc0, desc1 = data['feat_8_0'], data['feat_8_1']
#         desc0, desc1 = desc0.view(data['bs'], -1, data['h_8'], data['w_8']), desc1.view(data['bs'], -1, data['h_8'], data['w_8'])

#         # x_conv, ori_h, ori_w = self.scan_jego(desc0, desc1, True)
#         x, ori_h, ori_w = self.scan_jego(desc0, desc1, False)
#         # prompt_2w, prompt_2h = self.prompt_gen (desc0, desc1)
        
#         for i in range(len(self.layers) // 4):

#             y2 = self.layers[i * 4 + 2](x[:, 2])
#             y1 = self.layers[i * 4 + 1](x[:, 1])
#             y0_fused = torch.cat([x[:, 0], y2.flip(1)], dim=-1)  # [B,L,C] + [B,L,C] -> [B,L,2C]
#             y3_fused = torch.cat([x[:, 3], y1.flip(1)], dim=-1)
            
#             y3_fused = x[:, 3] + self.gamma * self.act(self.proj(y3_fused))
#             y0_fused = x[:, 0] + self.gamma * self.act(self.proj(y0_fused))

#             y0 = self.layers[i * 4](y0_fused, x[:, 0])
#             y3 = self.layers[i * 4 + 3](y3_fused, x[:, 3])
#             # y0 = self.layers[i * 4](y0_fused)
#             # y3 = self.layers[i * 4 + 3](y3_fused)
#             # y0 = self.layers[i * 4](x[:, 0])
#             # y3 = self.layers[i * 4 + 3](x[:, 3])
#             y = torch.stack([y0, y1, y2, y3], 1).transpose(2, 3)

#         desc0, desc1 = merge_jego(y, ori_h, ori_w, 2)
#         desc = self.aggregator(torch.cat([desc0, desc1], 0))
#         desc0, desc1 = torch.chunk(desc, 2, dim=0)
#         desc0, desc1 = desc0.flatten(2, 3), desc1.flatten(2, 3)
#         data.update({
#             'feat_8_0': desc0,
#             'feat_8_1': desc1,
#         })



# import torch
# from torch import nn
# import math
# from src.jamma.utils.utils import GLU_3
# from mamba_ssm import Mamba

# from einops import rearrange, repeat
# try:
#     from mamba_ssm.ops.triton.layernorm_gated import RMSNorm, LayerNorm
# except ImportError:
#     RMSNorm, LayerNorm = None, None
# from src.utils.profiler import PassThroughProfiler
# from mamba_ssm.ops.selective_scan_interface import selective_scan_fn, selective_scan_ref
# import torch.nn.functional as F
# import pdb
# from torch.cuda.amp import autocast



# class ScanJego(nn.Module):
#     def __init__(self, d_inner=256, reduction_ratio=4, step_size=2):
#         super().__init__()
#         self.step_size = step_size
#         self.spatial_enhancer = SpatialEnhancer(d_inner=d_inner, reduction_ratio=reduction_ratio)

#     def forward(self, desc0, desc1, is_conv=True):
#         desc_2w = torch.cat([desc0, desc1], dim=3)  # [B,C,H,2W]
#         desc_2h = torch.cat([desc0, desc1], dim=2)  # [B,C,2H,W]

#         if is_conv:
#             desc_2w = self.spatial_enhancer(desc_2w)  # ✅ 自动在正确设备上
#             desc_2h = self.spatial_enhancer(desc_2h)

#         B, C, H, W_2 = desc_2w.shape
#         _, _, H_2, W = desc_2h.shape

#         step = self.step_size
#         xs = desc_2w.new_empty((B, 4, C, (H // step) * (W_2 // step)))

#         # Top-left: [::step, ::step]
#         xs[:, 0] = desc_2w[:, :, ::step, ::step].contiguous().view(B, C, -1)

#         # Bottom-right transposed: [w, 2w] -> [1::step, 1::step]
#         xs[:, 1] = desc_2h.transpose(2, 3)[:, :, 1::step, 1::step].contiguous().view(B, C, -1)

#         # Top-right flipped
#         xs[:, 2] = desc_2w[:, :, ::step, 1::step].contiguous().view(B, C, -1).flip(dims=[2])

#         # Bottom-left flipped
#         xs[:, 3] = desc_2h.transpose(2, 3)[:, :, ::step, 1::step].contiguous().view(B, C, -1).flip(dims=[2])

#         xs = xs.view(B, 4, C, -1).transpose(2, 3)  # [B, 4, L, C]
#         return xs, H, W

# def merge_jego(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2w[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)
#     y_2w[:, :, ::step_size, 1::step_size] = ys[:, 2].flip([2]).reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, ::step_size] = ys[:, 3].flip([2]).reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# def scan_jego_seq(desc0, desc1, step_size):
#     desc_2w, desc_2h = torch.cat([desc0, desc1], 3), torch.cat([desc0, desc1], 2)
#     _, _, org_h, org_2w = desc_2w.shape
#     B, C, org_2h, org_w = desc_2h.shape

#     H = org_h // step_size
#     W = org_2w // step_size

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2h[:, :, ::step_size, ::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.transpose(dim0=2, dim1=3)[:, :, 1::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]
#     xs[:, 2] = desc_2h[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1).flip([2])  # [h/2, 2w/2]
#     xs[:, 3] = desc_2w.transpose(dim0=2, dim1=3)[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_jego_seq(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2h[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, 2*H, W)
#     y_2w[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, 2*W, H).transpose(dim0=2, dim1=3)
#     y_2h[:, :, ::step_size, 1::step_size] = ys[:, 2].flip([2]).reshape(B, C, 2*H, W)
#     y_2w[:, :, 1::step_size, ::step_size] = ys[:, 3].flip([2]).reshape(B, C, 2*W, H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# def scan_vim(desc0, desc1):
#     B, C, org_h, org_w = desc0.shape
#     desc_2w = torch.cat([desc0, desc1], 3)

#     H = org_h
#     W = desc_2w.shape[3]

#     xs = desc_2w.new_empty((B, 2, C, H*W))

#     xs[:, 0] = desc_2w.view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 2, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_vim(ys, org_h, org_w):
#     B, K, C, L = ys.shape

#     y_2w_f = ys[:, 0].reshape(B, C, org_h, 2*org_w)
#     y_2w_b = ys[:, 1].flip([2]).reshape(B, C, org_h, 2*org_w)
#     y_2w = y_2w_f + y_2w_b
#     desc0, desc1 = torch.chunk(y_2w, 2, dim=3)
#     return desc0, desc1


# def scan_vmamba(desc0, desc1):
#     B, C, org_h, org_w = desc0.shape
#     desc_2w = torch.cat([desc0, desc1], 3)
#     desc_2h = torch.cat([desc0, desc1], 2)

#     H = org_h
#     W = desc_2w.shape[3]

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2w.view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.view(B, C, -1).flip([2])  # [w/2, 2w/2]
#     xs[:, 2] = desc_2h.transpose(dim0=2, dim1=3).contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 3] = desc_2h.transpose(dim0=2, dim1=3).contiguous().view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_vmamba(ys, org_h, org_w):
#     B, K, C, L = ys.shape

#     y_2w_f = ys[:, 0].reshape(B, C, org_h, 2*org_w)
#     y_2w_b = ys[:, 1].flip([2]).reshape(B, C, org_h, 2*org_w)
#     y_2h_f = ys[:, 2].reshape(B, C, org_w, 2*org_h).transpose(2, 3)
#     y_2h_b = ys[:, 3].flip([2]).reshape(B, C, org_w, 2*org_h).transpose(2, 3)
#     y_2w, y_2h = y_2w_f + y_2w_b, y_2h_f + y_2h_b
#     desc0_w, desc1_w = torch.chunk(y_2w, 2, dim=3)
#     desc0_h, desc1_h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_w+desc0_h, desc1_w+desc1_h


# def scan_evmamba(desc0, desc1, step_size):
#     desc_2w, desc_2h = torch.cat([desc0, desc1], 3), torch.cat([desc0, desc1], 2)
#     _, _, org_h, org_2w = desc_2w.shape
#     B, C, org_2h, org_w = desc_2h.shape

#     H = org_h // step_size
#     W = org_2w // step_size

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2w[:, :, ::step_size, ::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2h.transpose(dim0=2, dim1=3)[:, :, 1::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]
#     xs[:, 2] = desc_2w[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 3] = desc_2h.transpose(dim0=2, dim1=3)[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_evmamba(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2w[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)
#     y_2w[:, :, ::step_size, 1::step_size] = ys[:, 2].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, ::step_size] = ys[:, 3].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# class Selective_Scan(nn.Module):
#     def __init__(
#             self,
#             d_model,
#             d_state=16,
#             expand=2.,
#             dt_rank="auto",
#             dt_min=0.001,
#             dt_max=0.1,
#             dt_init="random",
#             dt_scale=1.0,
#             dt_init_floor=1e-4,
#             device=None,
#             dtype=None,
#             **kwargs,
#     ):
#         factory_kwargs = {"device": device, "dtype": dtype}
#         super().__init__()
#         self.d_model = d_model
#         self.d_state = d_state
#         self.expand = expand
#         self.d_inner = int(self.expand * self.d_model)
#         self.dt_rank = math.ceil(self.d_model / 16) if dt_rank == "auto" else dt_rank

#         self.x_proj = nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs)
#         self.x_proj_weight = nn.Parameter(self.x_proj.weight)  # (K=4, N, inner)
#         del self.x_proj

#         self.x_conv_proj = nn.Linear(self.d_inner, self.dt_rank, bias=False, **factory_kwargs)
#         self.x_conv_proj_weight = nn.Parameter(self.x_conv_proj.weight)
#         del self.x_conv_proj

#         self.x_inverse_proj = nn.Linear(self.d_inner, self.d_state, bias=False, **factory_kwargs)
#         self.x_inverse_proj_weight = nn.Parameter(self.x_inverse_proj.weight)
#         del self.x_inverse_proj

#         self.dt_proj = self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
#                          **factory_kwargs)
#         self.dt_proj_weight = nn.Parameter(self.dt_proj.weight)
#         self.dt_proj_bias = nn.Parameter(self.dt_proj.bias) 
#         del self.dt_proj  

#         self.A_logs = self.A_log_init(self.d_state, self.d_inner, copies=1, merge=True)  
#         self.Ds = self.D_init(self.d_inner, copies=1, merge=True)  
#         self.selective_scan = selective_scan_fn


#     @staticmethod
#     def dt_init(dt_rank, d_inner, dt_scale=1.0, dt_init="random", dt_min=0.001, dt_max=0.1, dt_init_floor=1e-4,
#                 **factory_kwargs):
#         dt_proj = nn.Linear(dt_rank, d_inner, bias=True, **factory_kwargs)

#         # Initialize special dt projection to preserve variance at initialization
#         dt_init_std = dt_rank ** -0.5 * dt_scale
#         if dt_init == "constant":
#             nn.init.constant_(dt_proj.weight, dt_init_std)
#         elif dt_init == "random":
#             nn.init.uniform_(dt_proj.weight, -dt_init_std, dt_init_std)
#         else:
#             raise NotImplementedError

#         # Initialize dt bias so that F.softplus(dt_bias) is between dt_min and dt_max
#         dt = torch.exp(
#             torch.rand(d_inner, **factory_kwargs) * (math.log(dt_max) - math.log(dt_min))
#             + math.log(dt_min)
#         ).clamp(min=dt_init_floor)
#         # Inverse of softplus: https://github.com/pytorch/pytorch/issues/72759
#         inv_dt = dt + torch.log(-torch.expm1(-dt))
#         with torch.no_grad():
#             dt_proj.bias.copy_(inv_dt)
#         # Our initialization would set all Linear.bias to zero, need to mark this one as _no_reinit
#         dt_proj.bias._no_reinit = True

#         return dt_proj

#     @staticmethod
#     def A_log_init(d_state, d_inner, copies=1, device=None, merge=True):
#         # S4D real initialization
#         A = repeat(
#             torch.arange(1, d_state + 1, dtype=torch.float32, device=device),
#             "n -> d n",
#             d=d_inner,
#         ).contiguous()
#         A_log = torch.log(A)  # Keep A_log in fp32
#         if copies > 1:
#             A_log = repeat(A_log, "d n -> r d n", r=copies)
#             if merge:
#                 A_log = A_log.flatten(0, 1)
#         A_log = nn.Parameter(A_log)
#         A_log._no_weight_decay = True
#         return A_log

#     @staticmethod
#     def D_init(d_inner, copies=1, device=None, merge=True):
#         # D "skip" parameter
#         D = torch.ones(d_inner, device=device)
#         if copies > 1:
#             D = repeat(D, "n1 -> r n1", r=copies)
#             if merge:
#                 D = D.flatten(0, 1)
#         D = nn.Parameter(D)  # Keep in fp32
#         D._no_weight_decay = True
#         return D

#     def forward_core(self, x: torch.Tensor, x_inverse:torch.Tensor=None):
#         B, L, C = x.shape
#         K = 1
#         xs = x.reshape(B * L, C)
#         x_dbl = F.linear(xs, self.x_proj_weight)
#         dts, Bs, Cs = torch.split(x_dbl, [self.dt_rank, self.d_state, self.d_state], dim=1)
#         dts = torch.einsum("b r l, d r -> b d l", dts.reshape(B, -1, L), self.dt_proj_weight)

#         dts = dts.float()
#         if x_inverse is not None:
#             u = x_inverse.float().view(B, -1, L)
#         else:
#             u = xs.float().view(B, -1, L)

#         Bs = Bs.float().reshape(B, 1, -1, L)
#         Cs = Cs.float().reshape(B, 1, -1, L)  
#         Ds = self.Ds.float().view(-1)
#         As = -torch.exp(self.A_logs).view(-1, self.d_state)
#         dt_proj_bias = self.dt_proj_bias.view(-1)  
        
#         out_y = self.selective_scan(
#             u, dts,
#             As, Bs, Cs, Ds, z=None,
#             delta_bias=dt_proj_bias,
#             delta_softplus=True,
#             return_last_state=False,
#         ).view(B, K, -1, L)
#         assert out_y.dtype == torch.float

#         return out_y[:, 0]

#     def forward(self, x, x_inverse:torch.Tensor=None):
#         # b, l, c = prompt.shape
#         # prompt = prompt.permammute(0, 2, 1).contiguous().view(b, 1, c, l)
#         if x_inverse is not None:
#             y = self.forward_core(x, x_inverse)  # [B, L, C]
#         else:
#             y = self.forward_core(x, )
#         y = y.permute(0, 2, 1).contiguous()
#         return y

# class SpatialEnhancer(nn.Module):
#     """
#     Minimal & reliable local aggregation:
#     Depthwise 3x3 (BN+GELU) -> Pointwise 1x1 (BN) -> Residual
#     """
#     def __init__(self, d_inner: int = 256, reduction_ratio: int = 4, use_gn: bool = True):
#         super().__init__()
#         assert d_inner > 0
#         hidden_dim = max(1, d_inner // reduction_ratio)

#         Norm = (lambda c: nn.GroupNorm(1, c)) if use_gn else (lambda c: nn.BatchNorm2d(c))

#         # Depthwise 3x3（每通道独立卷积）
#         self.dw = nn.Conv2d(d_inner, d_inner, 3, padding=1, groups=d_inner, bias=False)
#         self.dw_norm = Norm(d_inner)
#         self.act = nn.GELU()

#         # Pointwise 1x1: 降维→升维（可选，若 reduction_ratio=1 则退化成恒等）
#         if hidden_dim != d_inner:
#             self.pw_reduce = nn.Conv2d(d_inner, hidden_dim, 1, bias=False)
#             self.pw_reduce_norm = Norm(hidden_dim)
#             self.pw_expand = nn.Conv2d(hidden_dim, d_inner, 1, bias=False)
#             self.pw_expand_norm = Norm(d_inner)
#         else:
#             self.pw_reduce = nn.Identity()
#             self.pw_reduce_norm = nn.Identity()
#             self.pw_expand = nn.Identity()
#             self.pw_expand_norm = nn.Identity()

#         self._init_weights()

#     def _init_weights(self):
#         # Kaiming 初始化更稳（配合 GELU/BN）
#         for m in self.modules():
#             if isinstance(m, nn.Conv2d):
#                 nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
#             elif isinstance(m, (nn.BatchNorm2d, nn.GroupNorm)):
#                 nn.init.ones_(m.weight)
#                 if hasattr(m, "bias") and m.bias is not None:
#                     nn.init.zeros_(m.bias)

#     def forward(self, x: torch.Tensor) -> torch.Tensor:
     
#         x = self.dw(x)
#         x = self.dw_norm(x)
#         x = self.act(x)

#         x = self.pw_reduce(x)
#         x = self.pw_reduce_norm(x)
#         x = self.act(x)

#         x = self.pw_expand(x)
#         x = self.pw_expand_norm(x)

#         return x 


# class Mambablock(nn.Module):
#     def __init__(self, dim, d_state, mlp_ratio=1.0):
#         super().__init__()
#         self.dim = dim
#         # Mamba params
#         self.expand = mlp_ratio
#         hidden = int(self.dim * self.expand)
#         self.d_state = d_state
#         self.selectiveScan = Selective_Scan(d_model=self.dim, d_state=self.d_state, expand=2)

#         self.in_norm = nn.LayerNorm(self.dim)
#         self.out_proj = nn.Linear(hidden, self.dim, bias=True)
#         self.in_proj = nn.Linear(self.dim, hidden)

#     def forward(self, x, x_inverse:torch.Tensor=None):

#         shortcut = x
#         if x_inverse is not None:

#             x = self.in_proj(self.in_norm(x))
#             x_inverse = self.in_proj(self.in_norm(x_inverse))
#             # x_conv = self.in_proj(self.in_norm(x_conv))
#             y = self.selectiveScan(x, x_inverse)
#             y = self.out_proj(y)

#         else:

#             x = self.in_proj(self.in_norm(x))
#             # x_conv = self.in_proj(self.in_norm(x_conv))
#             y = self.selectiveScan(x, x_inverse)
#             y = self.out_proj(y)

#         return y + shortcut
    

    
# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, depth,
#                  profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()
#         self.num_layers = depth

#         d_state=16
#         mlp_ratio=2
#         C = feature_dim
 
#         self.layers = nn.ModuleList()
#         for i in range(depth):
#             self.layers.append(Mambablock(
#                 C,
#                 d_state,
#                 mlp_ratio=mlp_ratio
#                 ))
#         self.gamma = nn.Parameter(torch.tensor(0.1))

#         self.proj = nn.Linear(2*C, C)      
#         self.act = nn.GELU()  
#         self.aggregator = GLU_3(feature_dim, feature_dim)
#         self.scan_jego = ScanJego(d_inner=feature_dim, reduction_ratio=4, step_size=2)
#         # self.prompt_gen = PromptGenerator(d_inner=feature_dim* mlp_ratio)
#     def forward(self, data):
#         desc0, desc1 = data['feat_8_0'], data['feat_8_1']
#         desc0, desc1 = desc0.view(data['bs'], -1, data['h_8'], data['w_8']), desc1.view(data['bs'], -1, data['h_8'], data['w_8'])

#         x_conv, ori_h, ori_w = self.scan_jego(desc0, desc1, True)
#         x, ori_h, ori_w = self.scan_jego(desc0, desc1, False)
#         # prompt_2w, prompt_2h = self.prompt_gen (desc0, desc1)
        
#         for i in range(len(self.layers) // 4):

#             y2 = self.layers[i * 4 + 2](x[:, 2])
#             y1 = self.layers[i * 4 + 1](x[:, 1])
#             y0_fused = torch.cat([x[:, 0], y2.flip(1)], dim=-1)  # [B,L,C] + [B,L,C] -> [B,L,2C]
#             y3_fused = torch.cat([x[:, 3], y1.flip(1)], dim=-1)
            
#             y3_fused = x[:, 3] + self.gamma * self.act(self.proj(y3_fused))
#             y0_fused = x[:, 0] + self.gamma * self.act(self.proj(y0_fused))

#             y0 = self.layers[i * 4](y0_fused, x[:, 0])
#             y3 = self.layers[i * 4 + 3](y3_fused,  x[:, 3])
#             y = torch.stack([y0, y1, y2, y3], 1).transpose(2, 3)

#         desc0, desc1 = merge_jego(y, ori_h, ori_w, 2)
#         desc = self.aggregator(torch.cat([desc0, desc1], 0))
#         desc0, desc1 = torch.chunk(desc, 2, dim=0)
#         desc0, desc1 = desc0.flatten(2, 3), desc1.flatten(2, 3)
#         data.update({
#             'feat_8_0': desc0,
#             'feat_8_1': desc1,
#         })

# import torch
# from torch import nn
# import math
# from src.jamma.utils.utils import GLU_3
# from mamba_ssm import Mamba

# from einops import rearrange, repeat
# try:
#     from mamba_ssm.ops.triton.layernorm_gated import RMSNorm, LayerNorm
# except ImportError:
#     RMSNorm, LayerNorm = None, None
# from src.utils.profiler import PassThroughProfiler
# from mamba_ssm.ops.selective_scan_interface import selective_scan_fn, selective_scan_ref
# import torch.nn.functional as F
# import pdb
# from torch.cuda.amp import autocast



# class ScanJego(nn.Module):
#     def __init__(self, d_inner=256, reduction_ratio=4, step_size=2):
#         super().__init__()
#         self.step_size = step_size
#         # self.spatial_enhancer = SpatialEnhancer(d_inner=d_inner, reduction_ratio=reduction_ratio)

#     def forward(self, desc0, desc1, is_conv=True):
#         desc_2w = torch.cat([desc0, desc1], dim=3)  # [B,C,H,2W]
#         desc_2h = torch.cat([desc0, desc1], dim=2)  # [B,C,2H,W]

#         # if is_conv:
#         #     desc_2w = self.spatial_enhancer(desc_2w)  # ✅ 自动在正确设备上
#         #     desc_2h = self.spatial_enhancer(desc_2h)

#         B, C, H, W_2 = desc_2w.shape
#         _, _, H_2, W = desc_2h.shape

#         step = self.step_size
#         xs = desc_2w.new_empty((B, 4, C, (H // step) * (W_2 // step)))

#         # Top-left: [::step, ::step]
#         xs[:, 0] = desc_2w[:, :, ::step, ::step].contiguous().view(B, C, -1)

#         # Bottom-right transposed: [w, 2w] -> [1::step, 1::step]
#         xs[:, 1] = desc_2h.transpose(2, 3)[:, :, 1::step, 1::step].contiguous().view(B, C, -1)

#         # Top-right flipped
#         xs[:, 2] = desc_2w[:, :, ::step, 1::step].contiguous().view(B, C, -1).flip(dims=[2])

#         # Bottom-left flipped
#         xs[:, 3] = desc_2h.transpose(2, 3)[:, :, ::step, 1::step].contiguous().view(B, C, -1).flip(dims=[2])

#         xs = xs.view(B, 4, C, -1).transpose(2, 3)  # [B, 4, L, C]
#         return xs, H, W

# def merge_jego(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2w[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)
#     y_2w[:, :, ::step_size, 1::step_size] = ys[:, 2].flip([2]).reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, ::step_size] = ys[:, 3].flip([2]).reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# def scan_jego_seq(desc0, desc1, step_size):
#     desc_2w, desc_2h = torch.cat([desc0, desc1], 3), torch.cat([desc0, desc1], 2)
#     _, _, org_h, org_2w = desc_2w.shape
#     B, C, org_2h, org_w = desc_2h.shape

#     H = org_h // step_size
#     W = org_2w // step_size

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2h[:, :, ::step_size, ::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.transpose(dim0=2, dim1=3)[:, :, 1::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]
#     xs[:, 2] = desc_2h[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1).flip([2])  # [h/2, 2w/2]
#     xs[:, 3] = desc_2w.transpose(dim0=2, dim1=3)[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_jego_seq(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2h[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, 2*H, W)
#     y_2w[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, 2*W, H).transpose(dim0=2, dim1=3)
#     y_2h[:, :, ::step_size, 1::step_size] = ys[:, 2].flip([2]).reshape(B, C, 2*H, W)
#     y_2w[:, :, 1::step_size, ::step_size] = ys[:, 3].flip([2]).reshape(B, C, 2*W, H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# def scan_vim(desc0, desc1):
#     B, C, org_h, org_w = desc0.shape
#     desc_2w = torch.cat([desc0, desc1], 3)

#     H = org_h
#     W = desc_2w.shape[3]

#     xs = desc_2w.new_empty((B, 2, C, H*W))

#     xs[:, 0] = desc_2w.view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 2, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_vim(ys, org_h, org_w):
#     B, K, C, L = ys.shape

#     y_2w_f = ys[:, 0].reshape(B, C, org_h, 2*org_w)
#     y_2w_b = ys[:, 1].flip([2]).reshape(B, C, org_h, 2*org_w)
#     y_2w = y_2w_f + y_2w_b
#     desc0, desc1 = torch.chunk(y_2w, 2, dim=3)
#     return desc0, desc1


# def scan_vmamba(desc0, desc1):
#     B, C, org_h, org_w = desc0.shape
#     desc_2w = torch.cat([desc0, desc1], 3)
#     desc_2h = torch.cat([desc0, desc1], 2)

#     H = org_h
#     W = desc_2w.shape[3]

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2w.view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2w.view(B, C, -1).flip([2])  # [w/2, 2w/2]
#     xs[:, 2] = desc_2h.transpose(dim0=2, dim1=3).contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 3] = desc_2h.transpose(dim0=2, dim1=3).contiguous().view(B, C, -1).flip([2])  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_vmamba(ys, org_h, org_w):
#     B, K, C, L = ys.shape

#     y_2w_f = ys[:, 0].reshape(B, C, org_h, 2*org_w)
#     y_2w_b = ys[:, 1].flip([2]).reshape(B, C, org_h, 2*org_w)
#     y_2h_f = ys[:, 2].reshape(B, C, org_w, 2*org_h).transpose(2, 3)
#     y_2h_b = ys[:, 3].flip([2]).reshape(B, C, org_w, 2*org_h).transpose(2, 3)
#     y_2w, y_2h = y_2w_f + y_2w_b, y_2h_f + y_2h_b
#     desc0_w, desc1_w = torch.chunk(y_2w, 2, dim=3)
#     desc0_h, desc1_h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_w+desc0_h, desc1_w+desc1_h


# def scan_evmamba(desc0, desc1, step_size):
#     desc_2w, desc_2h = torch.cat([desc0, desc1], 3), torch.cat([desc0, desc1], 2)
#     _, _, org_h, org_2w = desc_2w.shape
#     B, C, org_2h, org_w = desc_2h.shape

#     H = org_h // step_size
#     W = org_2w // step_size

#     xs = desc_2w.new_empty((B, 4, C, H*W))

#     xs[:, 0] = desc_2w[:, :, ::step_size, ::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 1] = desc_2h.transpose(dim0=2, dim1=3)[:, :, 1::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]
#     xs[:, 2] = desc_2w[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1)  # [h/2, 2w/2]
#     xs[:, 3] = desc_2h.transpose(dim0=2, dim1=3)[:, :, ::step_size, 1::step_size].contiguous().view(B, C, -1)  # [w/2, 2w/2]

#     xs = xs.view(B, 4, C, -1).transpose(2, 3)
#     return xs, org_h, org_w


# def merge_evmamba(ys, ori_h: int, ori_w: int, step_size=2):
#     B, K, C, L = ys.shape
#     H, W = math.ceil(ori_h / step_size), math.ceil(ori_w / step_size)

#     new_h = H * step_size
#     new_w = W * step_size

#     y_2w = torch.zeros((B, C, new_h, 2*new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, new_h, 2*new_w))
#     y_2h = torch.zeros((B, C, 2*new_h, new_w), device=ys.device, dtype=ys.dtype)  # ys.new_empty((B, C, 2*new_h, new_w))

#     y_2w[:, :, ::step_size, ::step_size] = ys[:, 0].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, 1::step_size] = ys[:, 1].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)
#     y_2w[:, :, ::step_size, 1::step_size] = ys[:, 2].reshape(B, C, H, 2*W)
#     y_2h[:, :, 1::step_size, ::step_size] = ys[:, 3].reshape(B, C, W, 2*H).transpose(dim0=2, dim1=3)

#     if ori_h != new_h or ori_w != new_w:
#         y_2w = y_2w[:, :, :ori_h, :ori_w].contiguous()
#         y_2h = y_2h[:, :, :ori_h, :ori_w].contiguous()
#     desc0_2w, desc1_2w = torch.chunk(y_2w, 2, dim=3)
#     desc0_2h, desc1_2h = torch.chunk(y_2h, 2, dim=2)
#     return desc0_2w+desc0_2h, desc1_2w+desc1_2h


# class Selective_Scan(nn.Module):
#     def __init__(
#             self,
#             d_model,
#             d_state=16,
#             expand=2.,
#             dt_rank="auto",
#             dt_min=0.001,
#             dt_max=0.1,
#             dt_init="random",
#             dt_scale=1.0,
#             dt_init_floor=1e-4,
#             device=None,
#             dtype=None,
#             **kwargs,
#     ):
#         factory_kwargs = {"device": device, "dtype": dtype}
#         super().__init__()
#         self.d_model = d_model
#         self.d_state = d_state
#         self.expand = expand
#         self.d_inner = int(self.expand * self.d_model)
#         self.dt_rank = math.ceil(self.d_model / 16) if dt_rank == "auto" else dt_rank

#         self.x_proj = nn.Linear(self.d_inner, (self.dt_rank + self.d_state * 2), bias=False, **factory_kwargs)
#         self.x_proj_weight = nn.Parameter(self.x_proj.weight)  # (K=4, N, inner)
#         del self.x_proj

#         # self.x_inverse_proj = nn.Linear(self.d_inner, self.d_state, bias=False, **factory_kwargs)
#         # self.x_inverse_proj_weight = nn.Parameter(self.x_inverse_proj.weight)
#         # del self.x_inverse_proj

#         self.dt_proj = self.dt_init(self.dt_rank, self.d_inner, dt_scale, dt_init, dt_min, dt_max, dt_init_floor,
#                          **factory_kwargs)
#         self.dt_proj_weight = nn.Parameter(self.dt_proj.weight)
#         self.dt_proj_bias = nn.Parameter(self.dt_proj.bias) 
#         del self.dt_proj  

#         self.A_logs = self.A_log_init(self.d_state, self.d_inner, copies=1, merge=True)  
#         self.Ds = self.D_init(self.d_inner, copies=1, merge=True)  
#         self.selective_scan = selective_scan_fn


#     @staticmethod
#     def dt_init(dt_rank, d_inner, dt_scale=1.0, dt_init="random", dt_min=0.001, dt_max=0.1, dt_init_floor=1e-4,
#                 **factory_kwargs):
#         dt_proj = nn.Linear(dt_rank, d_inner, bias=True, **factory_kwargs)

#         # Initialize special dt projection to preserve variance at initialization
#         dt_init_std = dt_rank ** -0.5 * dt_scale
#         if dt_init == "constant":
#             nn.init.constant_(dt_proj.weight, dt_init_std)
#         elif dt_init == "random":
#             nn.init.uniform_(dt_proj.weight, -dt_init_std, dt_init_std)
#         else:
#             raise NotImplementedError

#         # Initialize dt bias so that F.softplus(dt_bias) is between dt_min and dt_max
#         dt = torch.exp(
#             torch.rand(d_inner, **factory_kwargs) * (math.log(dt_max) - math.log(dt_min))
#             + math.log(dt_min)
#         ).clamp(min=dt_init_floor)
#         # Inverse of softplus: https://github.com/pytorch/pytorch/issues/72759
#         inv_dt = dt + torch.log(-torch.expm1(-dt))
#         with torch.no_grad():
#             dt_proj.bias.copy_(inv_dt)
#         # Our initialization would set all Linear.bias to zero, need to mark this one as _no_reinit
#         dt_proj.bias._no_reinit = True

#         return dt_proj

#     @staticmethod
#     def A_log_init(d_state, d_inner, copies=1, device=None, merge=True):
#         # S4D real initialization
#         A = repeat(
#             torch.arange(1, d_state + 1, dtype=torch.float32, device=device),
#             "n -> d n",
#             d=d_inner,
#         ).contiguous()
#         A_log = torch.log(A)  # Keep A_log in fp32
#         if copies > 1:
#             A_log = repeat(A_log, "d n -> r d n", r=copies)
#             if merge:
#                 A_log = A_log.flatten(0, 1)
#         A_log = nn.Parameter(A_log)
#         A_log._no_weight_decay = True
#         return A_log

#     @staticmethod
#     def D_init(d_inner, copies=1, device=None, merge=True):
#         # D "skip" parameter
#         D = torch.ones(d_inner, device=device)
#         if copies > 1:
#             D = repeat(D, "n1 -> r n1", r=copies)
#             if merge:
#                 D = D.flatten(0, 1)
#         D = nn.Parameter(D)  # Keep in fp32
#         D._no_weight_decay = True
#         return D

#     def forward_core(self, x: torch.Tensor, x_fuse:torch.Tensor=None):
#         B, L, C = x.shape
#         K = 1
#         xs = x.reshape(B * L, C)
#         x_dbl = F.linear(xs, self.x_proj_weight)
#         dts, Bs, Cs = torch.split(x_dbl, [self.dt_rank, self.d_state, self.d_state], dim=1)
#         dts = torch.einsum("b r l, d r -> b d l", dts.reshape(B, -1, L), self.dt_proj_weight)

#         dts = dts.float()
#         if x_fuse is not None:
#             u = x_fuse.float().view(B, -1, L)
#         else:
#             u = x.float().view(B, -1, L)

#         Bs = Bs.float().reshape(B, 1, -1, L)
#         Cs = Cs.float().reshape(B, 1, -1, L)  
#         Ds = self.Ds.float().view(-1)
#         As = -torch.exp(self.A_logs).view(-1, self.d_state)
#         dt_proj_bias = self.dt_proj_bias.view(-1)  
        
#         out_y = self.selective_scan(
#             u, dts,
#             As, Bs, Cs, Ds, z=None,
#             delta_bias=dt_proj_bias,
#             delta_softplus=True,
#             return_last_state=False,
#         ).view(B, K, -1, L)
#         assert out_y.dtype == torch.float

#         return out_y[:, 0]

#     def forward(self, x, x_fuse:torch.Tensor=None):
#         # b, l, c = prompt.shape
#         # prompt = prompt.permammute(0, 2, 1).contiguous().view(b, 1, c, l)
#         y = self.forward_core(x, x_fuse)  # [B, L, C]
#         y = y.permute(0, 2, 1).contiguous()
#         return y




# class Mambablock(nn.Module):
#     def __init__(self, dim, d_state, mlp_ratio=1.0):
#         super().__init__()
#         self.dim = dim
#         # Mamba params
#         self.expand = mlp_ratio
#         hidden = int(self.dim * self.expand)
#         self.d_state = d_state
#         self.selectiveScan = Selective_Scan(d_model=self.dim, d_state=self.d_state, expand=2)

#         self.in_norm = nn.LayerNorm(self.dim)
#         self.out_proj = nn.Linear(hidden, self.dim, bias=True)
#         self.in_proj = nn.Linear(self.dim, hidden)

#     def forward(self, x, x_fuse: torch.Tensor=None):

        
#         if x_fuse is not None:
#             shortcut = x_fuse
#             x = self.in_proj(self.in_norm(x))
#             x_fuse = self.in_proj(self.in_norm(x_fuse))
#             # x_conv = self.in_proj(self.in_norm(x_conv))
#             y = self.selectiveScan(x, x_fuse)
#             y = self.out_proj(y)
#         else:
#             shortcut = x
#             x = self.in_proj(self.in_norm(x))
#             # x_conv = self.in_proj(self.in_norm(x_conv))
#             y = self.selectiveScan(x, x_fuse)
#             y = self.out_proj(y)

#         return y + shortcut
    

    
# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, depth,
#                  profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()
#         self.num_layers = depth

#         d_state=16
#         mlp_ratio=2
#         C = feature_dim
 
#         self.layers = nn.ModuleList()
#         for i in range(depth):
#             self.layers.append(Mambablock(
#                 C,
#                 d_state,
#                 mlp_ratio=mlp_ratio
#                 ))
#         self.gamma = nn.Parameter(torch.tensor(0.1))

#         self.proj = nn.Linear(2*C, C)      
#         self.act = nn.GELU()  
#         self.aggregator = GLU_3(feature_dim, feature_dim)
#         self.scan_jego = ScanJego(d_inner=feature_dim, reduction_ratio=4, step_size=2)
#         # self.prompt_gen = PromptGenerator(d_inner=feature_dim* mlp_ratio)
#     def forward(self, data):
#         desc0, desc1 = data['feat_8_0'], data['feat_8_1']
#         desc0, desc1 = desc0.view(data['bs'], -1, data['h_8'], data['w_8']), desc1.view(data['bs'], -1, data['h_8'], data['w_8'])

#         # x_conv, ori_h, ori_w = self.scan_jego(desc0, desc1, True)
#         x, ori_h, ori_w = self.scan_jego(desc0, desc1, False)
#         # prompt_2w, prompt_2h = self.prompt_gen (desc0, desc1)
        
#         for i in range(len(self.layers) // 4):

#             y2 = self.layers[i * 4 + 2](x[:, 2])
#             y1 = self.layers[i * 4 + 1](x[:, 1])
#             y0_fused = torch.cat([x[:, 0], y2.flip(1)], dim=-1)  # [B,L,C] + [B,L,C] -> [B,L,2C]
#             y3_fused = torch.cat([x[:, 3], y1.flip(1)], dim=-1)
            
#             y3_fused = x[:, 3] + self.gamma * self.act(self.proj(y3_fused))
#             y0_fused = x[:, 0] + self.gamma * self.act(self.proj(y0_fused))

#             # y0 = self.layers[i * 4](y0_fused, x[:, 0])
#             # y3 = self.layers[i * 4 + 3](y3_fused, x[:, 3])
#             y0 = self.layers[i * 4](y0_fused)
#             y3 = self.layers[i * 4 + 3](y3_fused)
#             # y0 = self.layers[i * 4](x[:, 0])
#             # y3 = self.layers[i * 4 + 3](x[:, 3])
#             y = torch.stack([y0, y1, y2, y3], 1).transpose(2, 3)

#         desc0, desc1 = merge_jego(y, ori_h, ori_w, 2)
#         desc = self.aggregator(torch.cat([desc0, desc1], 0))
#         desc0, desc1 = torch.chunk(desc, 2, dim=0)
#         desc0, desc1 = desc0.flatten(2, 3), desc1.flatten(2, 3)
#         data.update({
#             'feat_8_0': desc0,
#             'feat_8_1': desc1,
#         })






# import torch
# import matplotlib.pyplot as plt

# def token_cosine_sim_matrix(h: torch.Tensor, eps=1e-8):
#     """
#     h: [L, C] or [N, L, C]
#     return: [L, L] or [N, L, L]
#     """
#     if h.dim() == 2:
#         h_norm = h / (h.norm(dim=-1, keepdim=True) + eps)   # [L,C]
#         sim = h_norm @ h_norm.T                             # [L,L]
#         return sim
#     elif h.dim() == 3:
#         h_norm = h / (h.norm(dim=-1, keepdim=True) + eps)   # [N,L,C]
#         sim = torch.einsum("nlc,nsc->nls", h_norm, h_norm)  # [N,L,L]
#         return sim
#     else:
#         raise ValueError("h must be [L,C] or [N,L,C]")
# def plot_token_sim_heatmap(sim, b=0, title="Token representation cosine similarity"):
#     """
#     sim: [L,L] or [N,L,L]
#     """
#     if sim.dim() == 3:
#         mat = sim[b]
#     else:
#         mat = sim

#     mat = mat.detach().float().cpu()

#     plt.figure(figsize=(8, 6))
#     plt.imshow(mat.numpy(), aspect="auto", vmin=-1, vmax=1)   # cosine范围固定，便于对比
#     plt.title(title)
#     plt.xlabel("Token position j")
#     plt.ylabel("Token position i")
#     plt.colorbar(label="cosine similarity")
#     plt.tight_layout()
#     plt.show()


# import numpy as np

# def sim_vs_distance(sim_2d: torch.Tensor):
#     """
#     sim_2d: [L,L] cosine sim
#     returns: distances (0..L-1), mean_sim_by_dist
#     """
#     if sim_2d.dim() == 3:
#         sim = sim_2d[0]
#     else:
#         sim = sim_2d
#     sim = sim.detach().float().cpu().numpy()
#     L = sim.shape[0]
#     vals = [[] for _ in range(L)]
#     for i in range(L):
#         for j in range(L):
#             d = abs(i - j)
#             vals[d].append(sim[i, j])
#     mean_by_d = np.array([np.mean(v) for v in vals])
#     return np.arange(L), mean_by_d

# def plot_sim_decay(sim_2d, title="Cosine similarity vs distance"):
#     ds, ys = sim_vs_distance(sim_2d)
#     plt.figure(figsize=(7,4))
#     plt.plot(ds, ys)
#     plt.title(title)
#     plt.xlabel("Absolute distance |i-j|")
#     plt.ylabel("Mean cosine similarity")
#     plt.tight_layout()
#     plt.show()


# import torch
# from torch import nn
# import math
# import copy
# from src.jamma.utils.utils import GLU_3

# from functools import partial

# from src.utils.profiler import PassThroughProfiler
# import torch
# import torch.nn as nn
# import torch.nn.functional as F

# import torch.utils.checkpoint as checkpoint
# from timm.models.layers import DropPath, to_2tuple, trunc_normal_
# from src.jamma.transformer import  LocalFeatureTransformer

# import pdb

# class Conv2d_BN_Act(nn.Sequential):
#     def __init__(
#         self,
#         a,
#         b,
#         ks=1,
#         stride=1,
#         pad=0,
#         dilation=1,
#         groups=1,
#         bn_weight_init=1,
#         act=None,
#         drop=None,
#     ):
#         super().__init__()
#         self.inp_channel = a
#         self.out_channel = b
#         self.ks = ks
#         self.pad = pad
#         self.stride = stride
#         self.dilation = dilation
#         self.groups = groups

#         self.add_module(
#             "c", nn.Conv2d(a, b, ks, stride, pad, dilation, groups, bias=False)
#         )
#         bn = nn.GroupNorm(8, b)
#         nn.init.constant_(bn.weight, bn_weight_init)
#         nn.init.constant_(bn.bias, 0)
#         self.add_module("bn", bn)
#         if act != None:
#             self.add_module("a", act)
#         if drop != None:
#             self.add_module("d", nn.Dropout(drop))


# class CIM(nn.Module):
#     """Feature Aggregation, Correlation Injection Module"""

#     def __init__(self):
#         super(CIM, self).__init__()

#         self.drop = 0
#         self.block_dims = [32, 64, 256, 256]
#         self.fc16 = Conv2d_BN_Act(
#             self.block_dims[-1], self.block_dims[-1], 1, drop=self.drop
#         )
#         self.fc8 = Conv2d_BN_Act(
#             self.block_dims[-2], self.block_dims[-1], 1, drop=self.drop
#         )
#         self.att16 = Conv2d_BN_Act(
#             self.block_dims[-1],
#             self.block_dims[-1],
#             1,
#             act=nn.Sigmoid(),
#             drop=self.drop,
#         )

#         self.dwconv8 = nn.Sequential(
#             Conv2d_BN_Act(
#                 self.block_dims[-1],
#                 self.block_dims[-1],
#                 ks=3,
#                 pad=1,
#                 groups=self.block_dims[-1],
#                 act=nn.GELU(),
#             ),
#             Conv2d_BN_Act(self.block_dims[-1], self.block_dims[-1], 1),
#         )

#         self.loftr_16 = LocalFeatureTransformer()

#     def forward(self, f8, f16, mask_c0=None, mask_c1=None):
        
        
#         f16 = self.fc16(f16)    #[2*B, c16, w, h]
#         f16_0, f16_1 = f16.chunk(2, dim=0)  #[B, c16, w, h]
#         f16_0, f16_1 = self.loftr_16(f16_0, f16_1, mask_c0, mask_c1)
#         f16 = torch.cat([f16_0, f16_1], dim=0)
       
#         f16_up = F.interpolate(f16, scale_factor=2.0, mode="bilinear")
#         att16_up = F.interpolate(self.att16(f16), scale_factor=2.0, mode="bilinear")
#         f8 = self.fc8(f8)
#         f8 = self.dwconv8(f8 * att16_up + f16_up)

#         feat_c0, feat_c1 = f8.chunk(2, dim=0)
#         return feat_c0, feat_c1



# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x)
#         x = self.act(x)
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x


# # class ConvLayer(nn.Module):
# #     def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=0, dilation=1, groups=1,
# #                  bias=True, dropout=0, norm=nn.BatchNorm2d, act_func=nn.ReLU):
# #         super(ConvLayer, self).__init__()
# #         self.dropout = nn.Dropout2d(dropout, inplace=False) if dropout > 0 else None
# #         self.conv = nn.Conv2d(
# #             in_channels,
# #             out_channels,
# #             kernel_size=(kernel_size, kernel_size),
# #             stride=(stride, stride),
# #             padding=(padding, padding),
# #             dilation=(dilation, dilation),
# #             groups=groups,
# #             bias=bias,
# #         )
# #         self.norm = norm(num_features=out_channels) if norm else None
# #         self.act = act_func() if act_func else None

# #     def forward(self, x: torch.Tensor) -> torch.Tensor:
# #         if self.dropout is not None:
# #             x = self.dropout(x)
# #         x = self.conv(x)
# #         if self.norm:
# #             x = self.norm(x)
# #         if self.act:
# #             x = self.act(x)
# #         return x


# class RoPE(torch.nn.Module):
#     r"""Rotary Positional Embedding.
#     """
#     def __init__(self, shape, base=10000):
#         super(RoPE, self).__init__()

#         channel_dims, feature_dim = shape[:-1], shape[-1]
#         k_max = feature_dim // (2 * len(channel_dims))

#         assert feature_dim % k_max == 0

#         # angles
#         theta_ks = 1 / (base ** (torch.arange(k_max) / k_max))
#         angles = torch.cat([t.unsqueeze(-1) * theta_ks for t in torch.meshgrid([torch.arange(d) for d in channel_dims], indexing='ij')], dim=-1)

#         # rotation
#         rotations_re = torch.cos(angles).unsqueeze(dim=-1)
#         rotations_im = torch.sin(angles).unsqueeze(dim=-1)
#         rotations = torch.cat([rotations_re, rotations_im], dim=-1)
#         self.register_buffer('rotations', rotations)

#     def forward(self, x):
#         if x.dtype != torch.float32:
#             x = x.to(torch.float32)
#         x = torch.view_as_complex(x.reshape(*x.shape[:-1], -1, 2))
#         pe_x = torch.view_as_complex(self.rotations) * x
#         return torch.view_as_real(pe_x).flatten(-2)

        


# class LinearAttention(nn.Module):
#     r""" Linear Attention with LePE and RoPE.

#     Args:
#         dim (int): Number of input channels.
#         num_heads (int): Number of attention heads.
#         qkv_bias (bool, optional):  If True, add a learnable bias to query, key, value. Default: True
#     """

#     def __init__(self, dim, input_resolution, num_heads, rope = False, qkv_bias=True, **kwargs):

#         super().__init__()
#         self.dim = dim
#         self.isrope = rope
#         self.input_resolution = input_resolution
#         self.num_heads = num_heads
#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.elu = nn.ELU()
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.rope = RoPE(shape=(input_resolution[0], input_resolution[1], dim))

#     def forward(self, x, source, x_mask=None, source_mask=None) :
#         """
#         Args:
#             x: input features with shape of (B, N, C)
#             x_mask: input mask with shape of (B, h, w)
#         """
        
#         b, n, c = x.shape
#         h = int(n ** 0.5)
#         w = int(n ** 0.5)
#         num_heads = self.num_heads
#         head_dim = c // num_heads

#         q = self.q(x)
#         k = self.k(source)
#         q, k, v = q, k, source      # q, k, v: b, n, c
#         q = self.elu(q) + 1.0
#         k = self.elu(k) + 1.0
 
#         if x_mask is not None:
#             x_mask = x_mask.reshape(b,1,n).transpose(1,2)
#             q = q * x_mask
#         if source_mask is not None:
#             source_mask = source_mask.reshape(b,1,n).transpose(1,2)
#             k = k * source_mask
#             v = v * source_mask

#         if self.isrope == True:
#             q_rope = self.rope(q.reshape(b, h, w, c)).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#             k_rope = self.rope(k.reshape(b, h, w, c)).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         else:
#             q_rope = q.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#             k_rope = k.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
    
#         q = q.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         k = k.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         v = v.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)

#         z = 1 / (q @ k.mean(dim=-2, keepdim=True).transpose(-2, -1) + 1e-6)
#         kv = (k_rope.transpose(-2, -1) * (n ** -0.5)) @ (v * (n ** -0.5))
#         x = q_rope @ kv * z

#         x = x.transpose(1, 2).reshape(b, n, c)
#         v = v.transpose(1, 2).reshape(b, h, w, c).permute(0, 3, 1, 2)
#         x = x + self.lepe(v).permute(0, 2, 3, 1).reshape(b, n, c)

#         return x

#     def extra_repr(self) -> str:
#         return f'dim={self.dim}, num_heads={self.num_heads}'


# class MLLABlock(nn.Module):
#     r""" MLLA Block.

#     Args:
#         dim (int): Number of input channels.
#         input_resolution (tuple[int]): Input resulotion.
#         num_heads (int): Number of attention heads.
#         mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
#         qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
#         drop (float, optional): Dropout rate. Default: 0.0
#         drop_path (float, optional): Stochastic depth rate. Default: 0.0
#         act_layer (nn.Module, optional): Activation layer. Default: nn.GELU
#         norm_layer (nn.Module, optional): Normalization layer.  Default: nn.LayerNorm
#     """

#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., rope=False, qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.num_heads = num_heads
#         self.mlp_ratio = mlp_ratio
#         self.input_resolution = input_resolution

#         self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm1 = norm_layer(dim)
#         self.in_proj = nn.Linear(dim, dim)
#         self.act_proj = nn.Linear(dim, dim)
#         self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.act = nn.SiLU()
#         self.attn = LinearAttention(dim=dim, input_resolution=input_resolution, num_heads=num_heads, rope = rope, qkv_bias=qkv_bias)
#         self.out_proj = nn.Linear(dim, dim)
        
#         self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, x, source, x_mask=None, source_mask=None):
        
#         '''
#             x: input feature of shape: [B, L, C]
#         '''

#         H, W = self.input_resolution
#         B, L, C = x.shape

#         x1 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe1(x1.contiguous()).flatten(2).permute(0, 2, 1)
#         source1 = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         source = source + self.cpe1(source1.contiguous()).flatten(2).permute(0, 2, 1)
#         shortcut = x

#         x = self.norm1(x)
#         source = self.norm1(source)
#         act_res = self.act(self.act_proj(x))
#         x = self.in_proj(x).view(B, H, W, C)
#         source = self.in_proj(source).view(B, H, W, C)
#         # x = self.act(self.dwc(x.permute(0, 3, 1, 2))).permute(0, 2, 3, 1).view(B, L, C)
#         x = self.act(self.dwc(x.permute(0, 3, 1, 2).contiguous())).permute(0, 2, 3, 1).view(B, L, C)
#         source = self.act(self.dwc(source.permute(0, 3, 1, 2).contiguous())).permute(0, 2, 3, 1).view(B, L, C)

#         # # Linear Attention
#         x = self.attn(x, source, x_mask, source_mask)
        
#         x = self.out_proj(x * act_res)
#         x = shortcut + x
#         x2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe2(x2.contiguous()).flatten(2).permute(0, 2, 1)

#         # # FFN
#         x = x + self.mlp(self.norm2(x))
#         return x

#     def extra_repr(self) -> str:
#         return f"dim={self.dim}, input_resolution={self.input_resolution}, num_heads={self.num_heads}, " \
#                f"mlp_ratio={self.mlp_ratio}"

# class MLLA(nn.Module):

#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.,):
#         super(MLLA, self).__init__()
#         self.layer_names = ["self", "cross"]*2
        
#         self_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = True,
#         )
#         cross_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = False,    
#         )

#         self.layers = nn.ModuleList(
#             [
#                 (
#                     copy.deepcopy(self_layer)
#                     if _ == "self"
#                     else copy.deepcopy(cross_layer)
#                 )
#                 for _ in self.layer_names
#             ]
#         )
#         self._reset_parameters()

#     def _reset_parameters(self):
#         for p in self.parameters():
#             if p.dim() > 1:
#                 nn.init.xavier_uniform_(p)

#     def forward(self, feat0, feat1, mask0=None, mask1=None, data=None):
#         """
#         Args:
#             feat0 (torch.Tensor): [N, C, H, W]
#             feat1 (torch.Tensor): [N, C, H, W]
#             mask0 (torch.Tensor): [N, H, W]
#             mask1 (torch.Tensor): [N, H, W]
#         """
#         # B, C, H, W = feat0.shape
#         # feat0 = feat0.reshape(B, H*W, C)
#         # feat1 = feat1.reshape(B, H*W, C)
#         for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
#             if name == "self":
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif name == "cross":
#                 feat0 = layer(feat0, feat1, mask0, mask1)
#                 feat1 = layer(feat1, feat0, mask1, mask0)
#             else:
#                 raise KeyError

#         return feat0, feat1



# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()

#         self.nhead = 8  
#         dim = 256
#         input_resolution = [104,104]

#         self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
#         # self.neck = CIM()
       

#     def forward(self, data):
        
#         feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
#         # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
#         # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
#         # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
#         # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)
   
#         mask_c0 = mask_c1 = None  # mask is useful in training
#         if "mask0" in data:
#             mask_c0, mask_c1 = data["mask0"], data["mask1"]
#         # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
#         # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
#         feat_8_0, feat_8_1 = self.atten(feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
#         # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
#         # B, C, H, W = feat_8_0.shape
#         # feat_c0 = feat_8_0.reshape(B, H*W, C)
#         # feat_c1 = feat_8_1.reshape(B, H*W, C)
#         data.update({
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1
#         })
# import torch
# from torch import nn
# import math
# import copy
# from src.jamma.utils.utils import GLU_3

# from functools import partial

# from src.utils.profiler import PassThroughProfiler
# import torch
# import torch.nn as nn
# import torch.nn.functional as F

# import torch.utils.checkpoint as checkpoint
# from timm.models.layers import DropPath, to_2tuple, trunc_normal_
# from src.jamma.transformer import  LocalFeatureTransformer

# import pdb

# class Conv2d_BN_Act(nn.Sequential):
#     def __init__(
#         self,
#         a,
#         b,
#         ks=1,
#         stride=1,
#         pad=0,
#         dilation=1,
#         groups=1,
#         bn_weight_init=1,
#         act=None,
#         drop=None,
#     ):
#         super().__init__()
#         self.inp_channel = a
#         self.out_channel = b
#         self.ks = ks
#         self.pad = pad
#         self.stride = stride
#         self.dilation = dilation
#         self.groups = groups

#         self.add_module(
#             "c", nn.Conv2d(a, b, ks, stride, pad, dilation, groups, bias=False)
#         )
#         bn = nn.GroupNorm(8, b)
#         nn.init.constant_(bn.weight, bn_weight_init)
#         nn.init.constant_(bn.bias, 0)
#         self.add_module("bn", bn)
#         if act != None:
#             self.add_module("a", act)
#         if drop != None:
#             self.add_module("d", nn.Dropout(drop))


# class CIM(nn.Module):
#     """Feature Aggregation, Correlation Injection Module"""

#     def __init__(self):
#         super(CIM, self).__init__()

#         self.drop = 0
#         self.block_dims = [32, 64, 256, 256]
#         self.fc16 = Conv2d_BN_Act(
#             self.block_dims[-1], self.block_dims[-1], 1, drop=self.drop
#         )
#         self.fc8 = Conv2d_BN_Act(
#             self.block_dims[-2], self.block_dims[-1], 1, drop=self.drop
#         )
#         self.att16 = Conv2d_BN_Act(
#             self.block_dims[-1],
#             self.block_dims[-1],
#             1,
#             act=nn.Sigmoid(),
#             drop=self.drop,
#         )

#         self.dwconv8 = nn.Sequential(
#             Conv2d_BN_Act(
#                 self.block_dims[-1],
#                 self.block_dims[-1],
#                 ks=3,
#                 pad=1,
#                 groups=self.block_dims[-1],
#                 act=nn.GELU(),
#             ),
#             Conv2d_BN_Act(self.block_dims[-1], self.block_dims[-1], 1),
#         )

#         self.loftr_16 = LocalFeatureTransformer()

#     def forward(self, f8, f16, mask_c0=None, mask_c1=None):
        
        
#         f16 = self.fc16(f16)    #[2*B, c16, w, h]
#         f16_0, f16_1 = f16.chunk(2, dim=0)  #[B, c16, w, h]
#         f16_0, f16_1 = self.loftr_16(f16_0, f16_1, mask_c0, mask_c1)
#         f16 = torch.cat([f16_0, f16_1], dim=0)
       
#         f16_up = F.interpolate(f16, scale_factor=2.0, mode="bilinear")
#         att16_up = F.interpolate(self.att16(f16), scale_factor=2.0, mode="bilinear")
#         f8 = self.fc8(f8)
#         f8 = self.dwconv8(f8 * att16_up + f16_up)

#         feat_c0, feat_c1 = f8.chunk(2, dim=0)
#         return feat_c0, feat_c1



# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x)
#         x = self.act(x)
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x





# class RoPE(torch.nn.Module):
#     r"""Rotary Positional Embedding.
#     """
#     def __init__(self, shape, base=10000):
#         super(RoPE, self).__init__()

#         channel_dims, feature_dim = shape[:-1], shape[-1]
#         k_max = feature_dim // (2 * len(channel_dims))

#         assert feature_dim % k_max == 0

#         # angles
#         theta_ks = 1 / (base ** (torch.arange(k_max) / k_max))
#         angles = torch.cat([t.unsqueeze(-1) * theta_ks for t in torch.meshgrid([torch.arange(d) for d in channel_dims], indexing='ij')], dim=-1)

#         # rotation
#         rotations_re = torch.cos(angles).unsqueeze(dim=-1)
#         rotations_im = torch.sin(angles).unsqueeze(dim=-1)
#         rotations = torch.cat([rotations_re, rotations_im], dim=-1)
#         self.register_buffer('rotations', rotations)

#     def forward(self, x):
#         if x.dtype != torch.float32:
#             x = x.to(torch.float32)
#         x = torch.view_as_complex(x.reshape(*x.shape[:-1], -1, 2))
#         pe_x = torch.view_as_complex(self.rotations) * x
#         return torch.view_as_real(pe_x).flatten(-2)

        


# class LinearAttention(nn.Module):
#     r""" Linear Attention with LePE and RoPE.

#     Args:
#         dim (int): Number of input channels.
#         num_heads (int): Number of attention heads.
#         qkv_bias (bool, optional):  If True, add a learnable bias to query, key, value. Default: True
#     """

#     def __init__(self, dim, input_resolution, num_heads, rope = False, qkv_bias=True, **kwargs):

#         super().__init__()
#         self.dim = dim
#         self.isrope = rope
#         self.input_resolution = input_resolution
#         self.num_heads = num_heads
#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         # self.elu = nn.ELU()
#         self.relu = nn.ReLU()
#         self.scale = nn.Parameter(torch.zeros(size = (1, 1 ,dim)))
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.rope = RoPE(shape=(input_resolution[0], input_resolution[1], dim))

#     def forward(self, x, source, x_mask=None, source_mask=None) :
#         """
#         Args:
#             x: input features with shape of (B, N, C)
#             x_mask: input mask with shape of (B, h, w)
#         """
        
#         b, n, c = x.shape
#         h = int(n ** 0.5)
#         w = int(n ** 0.5)
#         num_heads = self.num_heads
#         head_dim = c // num_heads

#         focusing_factor = 3
#         q = self.q(x)
#         k = self.k(source)
#         q, k, v = q, k, source      # q, k, v: b, n, c
        
#         q = self.relu(q) + 1e-6
#         k = self.relu(k) + 1e-6
#         scale = nn.Softplus()(self.scale)
#         q = q / scale
#         k = k / scale
#         q_norm = q.norm(dim=-1, keepdim=True)
#         k_norm = k.norm(dim=-1, keepdim=True)
#         q = q ** focusing_factor
#         k = k ** focusing_factor
#         q = (q / q.norm(dim = -1, keepdim = True))*q_norm
#         k = (k / k.norm(dim = -1, keepdim = True))*k_norm
#         # q = self.elu(q) + 1.0
#         # k = self.elu(k) + 1.0
 
#         if x_mask is not None:
#             x_mask = x_mask.reshape(b,1,n).transpose(1,2)
#             q = q * x_mask
#         if source_mask is not None:
#             source_mask = source_mask.reshape(b,1,n).transpose(1,2)
#             k = k * source_mask
#             v = v * source_mask

#         if self.isrope == True:
#             q_rope = self.rope(q.reshape(b, h, w, c)).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#             k_rope = self.rope(k.reshape(b, h, w, c)).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         else:
#             q_rope = q.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#             k_rope = k.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
    
#         q = q.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         k = k.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         v = v.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)

#         z = 1 / (q @ k.mean(dim=-2, keepdim=True).transpose(-2, -1) + 1e-6)
#         kv = (k_rope.transpose(-2, -1) * (n ** -0.5)) @ (v * (n ** -0.5))
#         x = q_rope @ kv * z

#         x = x.transpose(1, 2).reshape(b, n, c)
#         v = v.transpose(1, 2).reshape(b, h, w, c).permute(0, 3, 1, 2)
#         x = x + self.lepe(v).permute(0, 2, 3, 1).reshape(b, n, c)

#         return x

#     def extra_repr(self) -> str:
#         return f'dim={self.dim}, num_heads={self.num_heads}'


# class MLLABlock(nn.Module):
#     r""" MLLA Block.

#     Args:
#         dim (int): Number of input channels.
#         input_resolution (tuple[int]): Input resulotion.
#         num_heads (int): Number of attention heads.
#         mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
#         qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
#         drop (float, optional): Dropout rate. Default: 0.0
#         drop_path (float, optional): Stochastic depth rate. Default: 0.0
#         act_layer (nn.Module, optional): Activation layer. Default: nn.GELU
#         norm_layer (nn.Module, optional): Normalization layer.  Default: nn.LayerNorm
#     """

#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., rope=False, qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.num_heads = num_heads
#         self.mlp_ratio = mlp_ratio
#         self.input_resolution = input_resolution

#         self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm1 = norm_layer(dim)
#         self.in_proj = nn.Linear(dim, dim)
#         self.act_proj = nn.Linear(dim, dim)
#         self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.act = nn.SiLU()
#         self.attn = LinearAttention(dim=dim, input_resolution=input_resolution, num_heads=num_heads, rope = rope, qkv_bias=qkv_bias)
#         self.out_proj = nn.Linear(dim, dim)
        
#         self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, x, source, x_mask=None, source_mask=None):
        
#         '''
#             x: input feature of shape: [B, L, C]
#         '''
#         H, W = self.input_resolution
#         B, L, C = x.shape

#         x1 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe1(x1.contiguous()).flatten(2).permute(0, 2, 1)
#         source1 = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         source = source + self.cpe1(source1.contiguous()).flatten(2).permute(0, 2, 1)
#         shortcut = x

#         x = self.norm1(x)
#         source = self.norm1(source)
#         act_res = self.act(self.act_proj(x))
#         x = self.in_proj(x).view(B, H, W, C)
#         source = self.in_proj(source).view(B, H, W, C)
#         # x = self.act(self.dwc(x.permute(0, 3, 1, 2))).permute(0, 2, 3, 1).view(B, L, C)
#         x = self.act(self.dwc(x.permute(0, 3, 1, 2).contiguous())).permute(0, 2, 3, 1).view(B, L, C)
#         source = self.act(self.dwc(source.permute(0, 3, 1, 2).contiguous())).permute(0, 2, 3, 1).view(B, L, C)

#         # # Linear Attention
#         x = self.attn(x, source, x_mask, source_mask)
        
#         x = self.out_proj(x * act_res)
#         x = shortcut + x
#         x2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe2(x2.contiguous()).flatten(2).permute(0, 2, 1)

#         # # FFN
#         x = x + self.mlp(self.norm2(x))
#         return x

#     def extra_repr(self) -> str:
#         return f"dim={self.dim}, input_resolution={self.input_resolution}, num_heads={self.num_heads}, " \
#                f"mlp_ratio={self.mlp_ratio}"

# class MLLA(nn.Module):

#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.,):
#         super(MLLA, self).__init__()
#         self.layer_names = ["self", "cross"]*2
        
#         self_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = True,
#         )
#         cross_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = False,    
#         )

#         self.layers = nn.ModuleList(
#             [
#                 (
#                     copy.deepcopy(self_layer)
#                     if _ == "self"
#                     else copy.deepcopy(cross_layer)
#                 )
#                 for _ in self.layer_names
#             ]
#         )
#         self._reset_parameters()

#     def _reset_parameters(self):
#         for p in self.parameters():
#             if p.dim() > 1:
#                 nn.init.xavier_uniform_(p)

#     def forward(self, feat0, feat1, mask0=None, mask1=None, data=None):
#         """
#         Args:
#             feat0 (torch.Tensor): [N, C, H, W]
#             feat1 (torch.Tensor): [N, C, H, W]
#             mask0 (torch.Tensor): [N, H, W]
#             mask1 (torch.Tensor): [N, H, W]
#         """
#         # B, C, H, W = feat0.shape
#         # feat0 = feat0.reshape(B, H*W, C)
#         # feat1 = feat1.reshape(B, H*W, C)
#         for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
#             if name == "self":
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif name == "cross":
#                 feat0 = layer(feat0, feat1, mask0, mask1)
#                 feat1 = layer(feat1, feat0, mask1, mask0)
#             else:
#                 raise KeyError

#         return feat0, feat1



# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()

#         self.nhead = 8  
#         dim = 256
#         input_resolution = [104,104]

#         self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
#         # self.neck = CIM()
       

#     def forward(self, data):
        
#         feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
#         # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
#         # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
#         # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
#         # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)

#         mask_c0 = mask_c1 = None  # mask is useful in training
#         if "mask0" in data:
#             mask_c0, mask_c1 = data["mask0"], data["mask1"]
#         # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
#         # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
#         feat_8_0, feat_8_1 = self.atten(feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
#         # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
#         # B, C, H, W = feat_8_0.shape
#         # feat_c0 = feat_8_0.reshape(B, H*W, C)
#         # feat_c1 = feat_8_1.reshape(B, H*W, C)
#         data.update({
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1
#         })











# import torch
# from torch import nn
# import math
# import copy
# from src.jamma.utils.utils import GLU_3

# from functools import partial

# from src.utils.profiler import PassThroughProfiler
# import torch
# import torch.nn as nn
# import torch.nn.functional as F

# import torch.utils.checkpoint as checkpoint
# from timm.models.layers import DropPath, to_2tuple, trunc_normal_
# from src.jamma.transformer import  LocalFeatureTransformer

# import pdb

# class Conv2d_BN_Act(nn.Sequential):
#     def __init__(
#         self,
#         a,
#         b,
#         ks=1,
#         stride=1,
#         pad=0,
#         dilation=1,
#         groups=1,
#         bn_weight_init=1,
#         act=None,
#         drop=None,
#     ):
#         super().__init__()
#         self.inp_channel = a
#         self.out_channel = b
#         self.ks = ks
#         self.pad = pad
#         self.stride = stride
#         self.dilation = dilation
#         self.groups = groups

#         self.add_module(
#             "c", nn.Conv2d(a, b, ks, stride, pad, dilation, groups, bias=False)
#         )
#         bn = nn.GroupNorm(8, b)
#         nn.init.constant_(bn.weight, bn_weight_init)
#         nn.init.constant_(bn.bias, 0)
#         self.add_module("bn", bn)
#         if act != None:
#             self.add_module("a", act)
#         if drop != None:
#             self.add_module("d", nn.Dropout(drop))


# class CIM(nn.Module):
#     """Feature Aggregation, Correlation Injection Module"""

#     def __init__(self):
#         super(CIM, self).__init__()

#         self.drop = 0
#         self.block_dims = [32, 64, 256, 256]
#         self.fc16 = Conv2d_BN_Act(
#             self.block_dims[-1], self.block_dims[-1], 1, drop=self.drop
#         )
#         self.fc8 = Conv2d_BN_Act(
#             self.block_dims[-2], self.block_dims[-1], 1, drop=self.drop
#         )
#         self.att16 = Conv2d_BN_Act(
#             self.block_dims[-1],
#             self.block_dims[-1],
#             1,
#             act=nn.Sigmoid(),
#             drop=self.drop,
#         )

#         self.dwconv8 = nn.Sequential(
#             Conv2d_BN_Act(
#                 self.block_dims[-1],
#                 self.block_dims[-1],
#                 ks=3,
#                 pad=1,
#                 groups=self.block_dims[-1],
#                 act=nn.GELU(),
#             ),
#             Conv2d_BN_Act(self.block_dims[-1], self.block_dims[-1], 1),
#         )

#         self.loftr_16 = LocalFeatureTransformer()

#     def forward(self, f8, f16, mask_c0=None, mask_c1=None):
        
        
#         f16 = self.fc16(f16)    #[2*B, c16, w, h]
#         f16_0, f16_1 = f16.chunk(2, dim=0)  #[B, c16, w, h]
#         f16_0, f16_1 = self.loftr_16(f16_0, f16_1, mask_c0, mask_c1)
#         f16 = torch.cat([f16_0, f16_1], dim=0)
       
#         f16_up = F.interpolate(f16, scale_factor=2.0, mode="bilinear")
#         att16_up = F.interpolate(self.att16(f16), scale_factor=2.0, mode="bilinear")
#         f8 = self.fc8(f8)
#         f8 = self.dwconv8(f8 * att16_up + f16_up)

#         feat_c0, feat_c1 = f8.chunk(2, dim=0)
#         return feat_c0, feat_c1



# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x)
#         x = self.act(x)
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x





# class RoPE(torch.nn.Module):
#     r"""Rotary Positional Embedding.
#     """
#     def __init__(self, shape, base=10000):
#         super(RoPE, self).__init__()

#         channel_dims, feature_dim = shape[:-1], shape[-1]
#         k_max = feature_dim // (2 * len(channel_dims))

#         assert feature_dim % k_max == 0

#         # angles
#         theta_ks = 1 / (base ** (torch.arange(k_max) / k_max))
#         angles = torch.cat([t.unsqueeze(-1) * theta_ks for t in torch.meshgrid([torch.arange(d) for d in channel_dims], indexing='ij')], dim=-1)

#         # rotation
#         rotations_re = torch.cos(angles).unsqueeze(dim=-1)
#         rotations_im = torch.sin(angles).unsqueeze(dim=-1)
#         rotations = torch.cat([rotations_re, rotations_im], dim=-1)
#         self.register_buffer('rotations', rotations)

#     def forward(self, x):
#         if x.dtype != torch.float32:
#             x = x.to(torch.float32)
#         x = torch.view_as_complex(x.reshape(*x.shape[:-1], -1, 2))
#         pe_x = torch.view_as_complex(self.rotations) * x
#         return torch.view_as_real(pe_x).flatten(-2)
    
# def _safe_norm(x: torch.Tensor, dim: int = -1, eps: float = 1e-6) -> torch.Tensor:
#     return torch.linalg.norm(x, dim=dim, keepdim=True).clamp_min(eps)

# class NaLaFeatureMap(nn.Module):
#     """
#     Implements the NaLaFormer feature maps phi_q and phi_k:
#       p(||q||) = lam * (0.5 + tanh(||q||))                      (Eq. 8)
#       f(d) = (pi/4) * tanh(d)  to map direction to [-pi/4,pi/4] (App. A.2)
#       trig map: [cos(f(d)), sin(f(d))]                          (Eq. 12)
#       phi_q(q) = | d(q)^{p(||q||)} | * [cos(f(d(q))), sin(f(d(q)))]  (Eq. 16)
#       phi_k(k) = | k^{lam_k} |       * [cos(f(d(k))), sin(f(d(k)))]  (Eq. 16)
#     """
#     def __init__(self, lam_q: float = 2.0, lam_k: float = 2.0, eps: float = 1e-5):
#         super().__init__()
#         self.lam_q = lam_q
#         self.lam_k = lam_k
#         self.eps = eps

#     def p_q(self, q_norm: torch.Tensor) -> torch.Tensor:
#         # q_norm: (..., 1)
#         return self.lam_q * (0.5 + torch.tanh(q_norm))

#     def f_dir(self, d: torch.Tensor) -> torch.Tensor:
#         # map each element into [-pi/4, pi/4]
#         return (math.pi / 4.0) * torch.tanh(d)

#     def phi_q(self, q: torch.Tensor) -> torch.Tensor:
#         # q: (B, H, N, D)
#         q_norm = _safe_norm(q, dim=-1, eps=self.eps)            # (B,H,N,1)
#         d = q / q_norm                                          # direction in [-1,1] approximately
#         p = self.p_q(q_norm)                                    # (B,H,N,1) dynamic exponent

#         # |d|^p : use abs to keep non-negativity (paper uses | ... |)
#         amp = torch.pow(d.abs().clamp_min(self.eps), p)          # (B,H,N,D)

#         ang = self.f_dir(d)                                     # (B,H,N,D) in [-pi/4,pi/4]
#         trig = torch.cat([torch.cos(ang), torch.sin(ang)], dim=-1)  # (B,H,N,2D)

#         # broadcast amp to match trig (repeat along last dim)
#         amp2 = torch.cat([amp, amp], dim=-1)                     # (B,H,N,2D)
#         return amp2 * trig                                       # (B,H,N,2D)

#     def phi_k(self, k: torch.Tensor) -> torch.Tensor:
#         # k: (B, H, N, D)
#         k_norm = _safe_norm(k, dim=-1, eps=self.eps)
#         d = k / k_norm

#         # |k|^{lam_k} (paper: |k^lambda|)
#         amp = torch.pow(k.abs().clamp_min(self.eps), self.lam_k) # (B,H,N,D)

#         ang = self.f_dir(d)
#         trig = torch.cat([torch.cos(ang), torch.sin(ang)], dim=-1)  # (B,H,N,2D)
#         amp2 = torch.cat([amp, amp], dim=-1)                     # (B,H,N,2D)
#         return amp2 * trig
        


# class LinearAttention(nn.Module):
#     r""" Linear Attention with LePE and RoPE.

#     Args:
#         dim (int): Number of input channels.
#         num_heads (int): Number of attention heads.
#         qkv_bias (bool, optional):  If True, add a learnable bias to query, key, value. Default: True
#     """

#     def __init__(self, dim, input_resolution, num_heads, rope = False, qkv_bias=True, **kwargs):

#         super().__init__()
#         self.dim = dim
#         self.isrope = rope
#         self.input_resolution = input_resolution
#         self.num_heads = num_heads
#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.feature_map = NaLaFeatureMap()
#         self.attn_eps = 1e-5
#         # self.elu = nn.ELU()
#         # self.relu = nn.ReLU()
#         # self.scale = nn.Parameter(torch.zeros(size = (1, 1 ,dim)))
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.rope = RoPE(shape=(input_resolution[0], input_resolution[1], dim))

#     def forward(self, x, source, x_mask=None, source_mask=None) :
#         """
#         Args:
#             x: input features with shape of (B, N, C)
#             x_mask: input mask with shape of (B, h, w)
#         """
        
#         b, n, c = x.shape
#         h = int(n ** 0.5)
#         w = int(n ** 0.5)
#         num_heads = self.num_heads
#         head_dim = c // num_heads

#         focusing_factor = 3
#         q = self.q(x)
#         k = self.k(source)
#         q, k, v = q, k, source      # q, k, v: b, n, c
        
#         if x_mask is not None:
#             x_mask = x_mask.reshape(b,1,n).transpose(1,2)
#             q = q * x_mask
#         if source_mask is not None:
#             source_mask = source_mask.reshape(b,1,n).transpose(1,2)
#             k = k * source_mask
#             v = v * source_mask

#         if self.isrope == True:
#             q = self.rope(q.reshape(b, h, w, c)).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#             k = self.rope(k.reshape(b, h, w, c)).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         else:
#             q = q.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#             k = k.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)

#         v = v.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)

#         phi_q = self.feature_map.phi_q(q)  # (B,H,N,2d)
#         phi_k = self.feature_map.phi_k(k)  # (B,H,N,2d)

#         # KV: (B,H,2d,d)
#         # einsum: (B,H,N,2d)^T @ (B,H,N,d) -> (B,H,2d,d)
#         KV = torch.einsum("bhnm,bhnd->bhmd", phi_k, v)
#         # K_sum: (B,H,2d)
#         K_sum = phi_k.sum(dim=2)


#         num = torch.einsum("bhnm,bhmd->bhnd", phi_q, KV)               # (B,H,N,d)
#         den = torch.einsum("bhnm,bhm->bhn", phi_q, K_sum).unsqueeze(-1) # (B,H,N,1)
#         den = den.clamp_min(self.attn_eps)

#         out = num / den  # (B,H,N,d)
#         out = out.transpose(1, 2).contiguous().view(b, n, c)
#         v = v.transpose(1, 2).reshape(b, h, w, c).permute(0, 3, 1, 2)
#         x = out + self.lepe(v).permute(0, 2, 3, 1).reshape(b, n, c)

#         return x

#     def extra_repr(self) -> str:
#         return f'dim={self.dim}, num_heads={self.num_heads}'


# class MLLABlock(nn.Module):
#     r""" MLLA Block.

#     Args:
#         dim (int): Number of input channels.
#         input_resolution (tuple[int]): Input resulotion.
#         num_heads (int): Number of attention heads.
#         mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
#         qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
#         drop (float, optional): Dropout rate. Default: 0.0
#         drop_path (float, optional): Stochastic depth rate. Default: 0.0
#         act_layer (nn.Module, optional): Activation layer. Default: nn.GELU
#         norm_layer (nn.Module, optional): Normalization layer.  Default: nn.LayerNorm
#     """

#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., rope=False, qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.num_heads = num_heads
#         self.mlp_ratio = mlp_ratio
#         self.input_resolution = input_resolution

#         self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm1 = norm_layer(dim)
#         self.in_proj = nn.Linear(dim, dim)
#         self.act_proj = nn.Linear(dim, dim)
#         self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.act = nn.SiLU()
#         self.attn = LinearAttention(dim=dim, input_resolution=input_resolution, num_heads=num_heads, rope = rope, qkv_bias=qkv_bias)
#         self.out_proj = nn.Linear(dim, dim)
        
#         self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, x, source, x_mask=None, source_mask=None):
        
#         '''
#             x: input feature of shape: [B, L, C]
#         '''
#         H, W = self.input_resolution
#         B, L, C = x.shape

#         x1 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe1(x1.contiguous()).flatten(2).permute(0, 2, 1)
#         source1 = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         source = source + self.cpe1(source1.contiguous()).flatten(2).permute(0, 2, 1)
#         shortcut = x

#         x = self.norm1(x)
#         source = self.norm1(source)
#         act_res = self.act(self.act_proj(x))
#         x = self.in_proj(x).view(B, H, W, C)
#         source = self.in_proj(source).view(B, H, W, C)
#         # x = self.act(self.dwc(x.permute(0, 3, 1, 2))).permute(0, 2, 3, 1).view(B, L, C)
#         x = self.act(self.dwc(x.permute(0, 3, 1, 2).contiguous())).permute(0, 2, 3, 1).view(B, L, C)
#         source = self.act(self.dwc(source.permute(0, 3, 1, 2).contiguous())).permute(0, 2, 3, 1).view(B, L, C)

#         # # Linear Attention
#         x = self.attn(x, source, x_mask, source_mask)
        
#         x = self.out_proj(x * act_res)
#         x = shortcut + x
#         x2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe2(x2.contiguous()).flatten(2).permute(0, 2, 1)

#         # # FFN
#         x = x + self.mlp(self.norm2(x))
#         return x

#     def extra_repr(self) -> str:
#         return f"dim={self.dim}, input_resolution={self.input_resolution}, num_heads={self.num_heads}, " \
#                f"mlp_ratio={self.mlp_ratio}"

# class MLLA(nn.Module):

#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.,):
#         super(MLLA, self).__init__()
#         self.layer_names = ["self", "cross"]*2
        
#         self_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = True,
#         )
#         cross_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = False,    
#         )

#         self.layers = nn.ModuleList(
#             [
#                 (
#                     copy.deepcopy(self_layer)
#                     if _ == "self"
#                     else copy.deepcopy(cross_layer)
#                 )
#                 for _ in self.layer_names
#             ]
#         )
#         self._reset_parameters()

#     def _reset_parameters(self):
#         for p in self.parameters():
#             if p.dim() > 1:
#                 nn.init.xavier_uniform_(p)

#     def forward(self, feat0, feat1, mask0=None, mask1=None, data=None):
#         """
#         Args:
#             feat0 (torch.Tensor): [N, C, H, W]
#             feat1 (torch.Tensor): [N, C, H, W]
#             mask0 (torch.Tensor): [N, H, W]
#             mask1 (torch.Tensor): [N, H, W]
#         """
#         # B, C, H, W = feat0.shape
#         # feat0 = feat0.reshape(B, H*W, C)
#         # feat1 = feat1.reshape(B, H*W, C)
#         for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
#             if name == "self":
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif name == "cross":
#                 feat0 = layer(feat0, feat1, mask0, mask1)
#                 feat1 = layer(feat1, feat0, mask1, mask0)
#             else:
#                 raise KeyError

#         return feat0, feat1



# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()

#         self.nhead = 8  
#         dim = 256
#         input_resolution = [104,104]

#         self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
#         # self.neck = CIM()
       

#     def forward(self, data):
        
#         feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
#         # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
#         # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
#         # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
#         # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)

#         mask_c0 = mask_c1 = None  # mask is useful in training
#         if "mask0" in data:
#             mask_c0, mask_c1 = data["mask0"], data["mask1"]
#         # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
#         # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
#         feat_8_0, feat_8_1 = self.atten(feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
#         # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
#         # B, C, H, W = feat_8_0.shape
#         # feat_c0 = feat_8_0.reshape(B, H*W, C)
#         # feat_c1 = feat_8_1.reshape(B, H*W, C)
#         data.update({
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1
#         })



# import torch
# from torch import nn
# import math
# import copy
# from src.jamma.utils.utils import GLU_3

# from functools import partial

# from src.utils.profiler import PassThroughProfiler
# import torch
# import torch.nn as nn
# import torch.nn.functional as F

# import torch.utils.checkpoint as checkpoint
# from timm.models.layers import DropPath, to_2tuple, trunc_normal_
# from src.jamma.transformer import  LocalFeatureTransformer

# import pdb

# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x)
#         x = self.act(x)
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x


# class MGCAFeatureMap(nn.Module):
#     """
#     Multi-scale Geometric Consistency Attention (MGCA)
#     - Energy: Saliency competition based on relative amplitude.
#     - Phase: Multi-scale rotation mapping for geometric verification.
#     """
#     def __init__(self, head_dim, sigma_min=0.5, sigma_max=2.0, lam=6.0, eps=1e-6):
#         super().__init__()
#         self.head_dim = head_dim
#         self.lam = lam
#         self.eps = eps
        
#         # Register multi-scale frequencies (sigma) as buffer
#         num_pairs = head_dim // 2
#         sigmas = torch.linspace(sigma_min, sigma_max, num_pairs)
#         self.register_buffer('sigmas', sigmas.view(1, 1, 1, num_pairs))

#     def forward(self, x):
#         # x: (B, H, N, D)
#         B, H, N, D = x.shape
        
#         # 1. Vectorization: group into D/2 pairs of 2D vectors
#         x_pairs = x.view(B, H, N, D // 2, 2)
        
#         # 2. Extract polar coordinates: magnitude (r) and phase (phi)
#         r = torch.norm(x_pairs, dim=-1)
#         phi = torch.atan2(x_pairs[..., 1], x_pairs[..., 0])

#         # 3. Energy branch: Local saliency competition
#         r_mean = r.mean(dim=-1, keepdim=True) 
#         saliency = torch.sigmoid(10*(r - r_mean) / (r_mean + self.eps))
#         amp = F.softplus(r * saliency * self.lam)

#         # 4. Phase branch: Multi-scale rotation mapping
#         phi_scaled = phi * self.sigmas
#         # trig_cos = torch.cos(phi_scaled)
#         # trig_sin = torch.sin(phi_scaled)

#         # # 5. Output: [amp*cos, amp*sin] (Reconstructs D channels)
#         # out_cos = amp * (trig_cos + 1) * 0.5
#         # out_sin = amp * (trig_sin + 1) * 0.5
#         phi = torch.cat([torch.cos(phi_scaled), torch.sin(phi_scaled)], dim=-1)  # 允许负值
#         phi = F.elu(phi) + 1.0  # 变回正值核特征
#         out = amp.repeat_interleave(2, dim=-1) * phi

        
#         # return torch.stack([out_cos, out_sin], dim=-1).view(B, H, N, D)
#         return out.view(B, H, N, D)

# class LinearAttention(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, rope=False, qkv_bias=True, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.isrope = rope
#         self.input_resolution = input_resolution
#         self.num_heads = num_heads
#         head_dim = dim // num_heads
        
#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.feature_map = MGCAFeatureMap(head_dim)
        
#         self.attn_eps = 1e-5
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
        
#         # MGCA inherently encodes geometric info; RoPE is optional/redundant
#         # self.rope = RoPE(shape=(input_resolution[0], input_resolution[1], dim)) if rope else None

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         b, n, c = x.shape
#         h, w = self.input_resolution
#         num_heads = self.num_heads
#         head_dim = c // num_heads

#         # 1. Linear projection
#         q = self.q(x)
#         k = self.k(source)
#         v = source 

#         # 2. Apply masks
#         if x_mask is not None:
#             q = q * x_mask.reshape(b, n, 1)
#         if source_mask is not None:
#             mask = source_mask.reshape(b, n, 1)
#             k = k * mask
#             v = v * mask

#         # 3. Reshape to multi-head (B, H, N, D)
#         q = q.view(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         k = k.view(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         v = v.view(b, n, num_heads, head_dim).permute(0, 2, 1, 3)

#         # 4. Feature mapping (Geometric Transformation)
#         phi_q = self.feature_map(q)
#         phi_k = self.feature_map(k)

#         # 5. Linear Attention: (phi_q @ (phi_k.T @ v)) for O(N) complexity
#         # Context: (B, H, D, D)
#         kv = torch.einsum('bhnd, bhnv -> bhdv', phi_k, v)
        
#         # Numerator: (B, H, N, D)
#         num = torch.einsum('bhnd, bhdv -> bhnv', phi_q, kv)
        
#         # Normalizer (Denominator)
#         k_sum = phi_k.sum(dim=2) # (B, H, D)
#         den = torch.einsum('bhnd, bhd -> bhn', phi_q, k_sum).unsqueeze(-1)
#         den = den.clamp_min(self.attn_eps)

#         # 6. Final output & LEPE (Local Enhancement)
#         out = (num / den).transpose(1, 2).contiguous().view(b, n, c)
        
#         # Reshape V for spatial convolution
#         v_img = v.transpose(1, 2).reshape(b, h, w, c).permute(0, 3, 1, 2)
#         lepe_res = self.lepe(v_img).permute(0, 2, 3, 1).reshape(b, n, c)
        
#         return out + lepe_res

#     def extra_repr(self) -> str:
#         return f'dim={self.dim}, num_heads={self.num_heads}, mgca=True'
    
# class PreservationFeatureMap(nn.Module):
#     """
#     全相关性保持特征映射
#     通过 [pos(x), neg(x)] 拆分，确保 -1 * -1 = 1 的逻辑在线性空间成立
#     """
#     def __init__(self, head_dim):
#         super().__init__()
#         # 这里的输出维度会翻倍，因为每个维度拆成了正负两个分量
#         self.head_dim = head_dim

#     def forward(self, x_complex, energy):
#         # 1. 提取实部和虚部 (B, H, N, D/2)
#         real = x_complex.real * energy
#         imag = x_complex.imag * energy
        
#         # 2. 正负拆分 (Bifurcation)
#         # 对于每个值 x，映射为 [max(0, x), max(0, -x)]
#         # 这样无论原值正负，在对应位置都会留下“强信号”
#         real_pos = F.Softplus(real)
#         real_neg = F.Softplus(-real)
#         imag_pos = F.Softplus(imag)
#         imag_neg = F.Softplus(-imag)
        
#         # 3. 拼接
#         # 输出维度变为原来的 2 倍：(B, H, N, D*2)
#         # 这种做法保留了所有相位信息，且点积结果严格非负
#         phi = torch.cat([real_pos, real_neg, imag_pos, imag_neg], dim=-1)
#         return phi

# class HarmonicLinearAttentionFull(nn.Module):
#     def __init__(self, dim, num_heads, qkv_bias=True, order=2):
#         super().__init__()
#         self.dim = dim
#         self.num_heads = num_heads
#         self.head_dim = dim // num_heads
#         self.order = order
        
#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.v = nn.Linear(dim, dim, bias=qkv_bias)
        
#         self.feature_map = PreservationFeatureMap(self.head_dim)
#         self.out_proj = nn.Linear(dim, dim)
#         self.eps = 1e-6

#     def forward(self, x):
#         B, N, C = x.shape
#         H = self.num_heads
#         D = self.head_dim

#         # 1. 获取 Q, K, V
#         q = self.q(x).view(B, N, H, D).transpose(1, 2)
#         k = self.k(x).view(B, N, H, D).transpose(1, 2)
#         v = self.v(x).view(B, N, H, D).transpose(1, 2)

#         # 2. 复数几何变换 (内部处理)
#         def get_harmonic_phi(t):
#             t_complex = torch.view_as_complex(t.reshape(B, H, N, D//2, 2))
#             r = t_complex.abs()
#             energy = F.softplus(r)
#             # 归一化并旋转
#             norm_z = t_complex / (r + self.eps)
#             harmonic_z = torch.pow(norm_z, self.order)
#             # 使用“正负拆分”映射
#             return self.feature_map(harmonic_z, energy)

#         phi_q = get_harmonic_phi(q) # (B, H, N, D*2)
#         phi_k = get_harmonic_phi(k) # (B, H, N, D*2)

#         # 3. 线性注意力 (KV 聚合)
#         # 复杂度 O(N * (2D)^2)
#         kv = torch.matmul(phi_k.transpose(-2, -1), v) # (B, H, 2D, D)
        
#         # 4. 分子与分母
#         num = torch.matmul(phi_q, kv) # (B, H, N, D)
#         den = torch.matmul(phi_q, phi_k.sum(dim=2, keepdim=True).transpose(-2, -1))
#         den = den.clamp_min(self.eps)

#         out = (num / den).transpose(1, 2).reshape(B, N, C)
#         return self.out_proj(out)


# class MLLABlock(nn.Module):
#     r""" MLLA Block.

#     Args:
#         dim (int): Number of input channels.
#         input_resolution (tuple[int]): Input resulotion.
#         num_heads (int): Number of attention heads.
#         mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
#         qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
#         drop (float, optional): Dropout rate. Default: 0.0
#         drop_path (float, optional): Stochastic depth rate. Default: 0.0
#         act_layer (nn.Module, optional): Activation layer. Default: nn.GELU
#         norm_layer (nn.Module, optional): Normalization layer.  Default: nn.LayerNorm
#     """

#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., rope=False, qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.num_heads = num_heads
#         self.mlp_ratio = mlp_ratio
#         self.input_resolution = input_resolution

#         self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm1 = norm_layer(dim)
#         self.in_proj = nn.Linear(dim, dim)
#         self.act_proj = nn.Linear(dim, dim)
#         self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.act = nn.SiLU()
#         self.attn = LinearAttention(dim=dim, input_resolution=input_resolution, num_heads=num_heads, rope = rope, qkv_bias=qkv_bias)
#         self.out_proj = nn.Linear(dim, dim)
        
#         self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, x, source, x_mask=None, source_mask=None):
        
#         '''
#             x: input feature of shape: [B, L, C]
#         '''
#         H, W = self.input_resolution
#         B, L, C = x.shape

#         x1 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe1(x1.contiguous()).flatten(2).permute(0, 2, 1)
#         source1 = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         source = source + self.cpe1(source1.contiguous()).flatten(2).permute(0, 2, 1)
#         shortcut = x

#         x = self.norm1(x)
#         source = self.norm1(source)
#         act_res = self.act(self.act_proj(x))
#         x = self.in_proj(x).view(B, H, W, C)
#         source = self.in_proj(source).view(B, H, W, C)
#         # x = self.act(self.dwc(x.permute(0, 3, 1, 2))).permute(0, 2, 3, 1).view(B, L, C)
#         x = self.act(self.dwc(x.permute(0, 3, 1, 2).contiguous())).permute(0, 2, 3, 1).view(B, L, C)
#         source = self.act(self.dwc(source.permute(0, 3, 1, 2).contiguous())).permute(0, 2, 3, 1).view(B, L, C)

#         # # Linear Attention
#         x = self.attn(x, source, x_mask, source_mask)
        
#         x = self.out_proj(x * act_res)
#         x = shortcut + x
#         x2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe2(x2.contiguous()).flatten(2).permute(0, 2, 1)

#         # # FFN
#         x = x + self.mlp(self.norm2(x))
#         return x

#     def extra_repr(self) -> str:
#         return f"dim={self.dim}, input_resolution={self.input_resolution}, num_heads={self.num_heads}, " \
#                f"mlp_ratio={self.mlp_ratio}"

# class MLLA(nn.Module):

#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.,):
#         super(MLLA, self).__init__()
#         self.layer_names = ["self", "cross"]*2
        
#         self_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = True,
#         )
#         cross_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = False,    
#         )

#         self.layers = nn.ModuleList(
#             [
#                 (
#                     copy.deepcopy(self_layer)
#                     if _ == "self"
#                     else copy.deepcopy(cross_layer)
#                 )
#                 for _ in self.layer_names
#             ]
#         )
#         self._reset_parameters()

#     def _reset_parameters(self):
#         for p in self.parameters():
#             if p.dim() > 1:
#                 nn.init.xavier_uniform_(p)

#     def forward(self, feat0, feat1, mask0=None, mask1=None, data=None):
#         """
#         Args:
#             feat0 (torch.Tensor): [N, C, H, W]
#             feat1 (torch.Tensor): [N, C, H, W]
#             mask0 (torch.Tensor): [N, H, W]
#             mask1 (torch.Tensor): [N, H, W]
#         """
#         # B, C, H, W = feat0.shape
#         # feat0 = feat0.reshape(B, H*W, C)
#         # feat1 = feat1.reshape(B, H*W, C)
#         for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
#             if name == "self":
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif name == "cross":
#                 feat0 = layer(feat0, feat1, mask0, mask1)
#                 feat1 = layer(feat1, feat0, mask1, mask0)
#             else:
#                 raise KeyError

#         return feat0, feat1



# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()

#         self.nhead = 8  
#         dim = 256
#         input_resolution = [104,104]

#         self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
#         # self.neck = CIM()
       

#     def forward(self, data):
        
#         feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
#         # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
#         # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
#         # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
#         # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)

#         mask_c0 = mask_c1 = None  # mask is useful in training
#         if "mask0" in data:
#             mask_c0, mask_c1 = data["mask0"], data["mask1"]
#         # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
#         # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
#         feat_8_0, feat_8_1 = self.atten(feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
#         # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
#         # B, C, H, W = feat_8_0.shape
#         # feat_c0 = feat_8_0.reshape(B, H*W, C)
#         # feat_c1 = feat_8_1.reshape(B, H*W, C)
#         data.update({
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1
#         })






import torch
from torch import nn
import math
import copy
from src.jamma.utils.utils import GLU_3

from functools import partial

from src.utils.profiler import PassThroughProfiler
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange


import torch.utils.checkpoint as checkpoint
from timm.models.layers import DropPath, to_2tuple, trunc_normal_
from src.jamma.transformer import  LocalFeatureTransformer

import pdb
import torch
import torch.nn as nn
import torch.nn.functional as F
import copy

# # ==========================================
# # 1. 核心特征映射：正负保真拆分 (Bifurcation)
# # ==========================================
# class PreservationFeatureMap(nn.Module):
#     """
#     通过 [pos(x), neg(x)] 拆分，确保负负得正逻辑在线性空间成立。
#     将 D/2 个复数映射为 4 * (D/2) = 2D 维度的非负特征。
#     """
#     def __init__(self, head_dim):
#         super().__init__()
#         self.head_dim = head_dim

#     def forward(self, x_complex, energy):
#         # 注入能量信息（幅值敏感性）
#         # x_complex: (B, H, N, D/2)
#         real = x_complex.real * energy
#         imag = x_complex.imag * energy
        
#         # 正负拆分：解决 -1 * -1 = 1 的问题
#         # 使用 F.softplus 保证平滑性和非负性
#         real_pos = F.softplus(real)
#         real_neg = F.softplus(-real)
#         imag_pos = F.softplus(imag)
#         imag_neg = F.softplus(-imag)
        
#         # 拼接后的 phi 维度为 (B, H, N, D*2)
#         phi = torch.cat([real_pos, real_neg, imag_pos, imag_neg], dim=-1)
#         return phi

# # ==========================================
# # 2. 谐波线性注意力 (Harmonic Linear Attention)
# # ==========================================
# class HarmonicLinearAttentionFull(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, qkv_bias=True, order=2, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.input_resolution = input_resolution
#         self.num_heads = num_heads
#         self.head_dim = dim // num_heads
#         self.order = order
        
#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.v = nn.Linear(dim, dim, bias=qkv_bias)
        
#         self.feature_map = PreservationFeatureMap(self.head_dim)
#         # LEPE: 局部增强位置编码，弥补线性注意力的局部细节丢失
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.out_proj = nn.Linear(dim, dim)
#         self.attn_eps = 1e-6

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         B, N, C = x.shape
#         H, W = self.input_resolution
#         num_heads = self.num_heads
#         d = self.head_dim

#         # 1. 投影并转置为多头格式 (B, H, N, D)
#         q = self.q(x).view(B, N, num_heads, d).permute(0, 2, 1, 3)
#         k = self.k(source).view(B, N, num_heads, d).permute(0, 2, 1, 3)
#         v = self.v(source).view(B, N, num_heads, d).permute(0, 2, 1, 3)

#         # 2. 遮罩处理
#         if x_mask is not None:
#             q = q * x_mask.view(B, 1, N, 1)
#         if source_mask is not None:
#             k = k * source_mask.view(B, 1, N, 1)
#             v = v * source_mask.view(B, 1, N, 1)

#         # 3. 几何特征映射 (复数旋转 + 正负拆分)
#         def get_phi(t):
#             # 将实数维度打包为复数 (D -> D/2)
#             t_complex = torch.view_as_complex(t.reshape(B, num_heads, N, d // 2, 2))
#             r = t_complex.abs()
#             energy = F.softplus(r) # 保留幅值显著性
#             # 谐波旋转 z^n
#             norm_z = t_complex / (r + self.attn_eps)
#             harmonic_z = torch.pow(norm_z, self.order)
#             return self.feature_map(harmonic_z, energy)

#         phi_q = get_phi(q) # (B, H, N, 2D)
#         phi_k = get_phi(k) # (B, H, N, 2D)

#         # 4. 线性注意力核心：Q(K^T V)
#         # kv context: (B, H, 2D, D)
#         kv = torch.matmul(phi_k.transpose(-2, -1), v)
        
#         # 分子 (Numerator)
#         num = torch.matmul(phi_q, kv) # (B, H, N, D)
        
#         # 分母 (Denominator/Normalizer)
#         k_sum = phi_k.sum(dim=2, keepdim=True) # (B, H, 1, 2D)
#         den = torch.matmul(phi_q, k_sum.transpose(-2, -1)) # (B, H, N, 1)
#         den = den.clamp_min(self.attn_eps)

#         # 5. 合并头并还原维度
#         out = (num / den).transpose(1, 2).reshape(B, N, C)
        
#         # 6. 局部增强 (LEPE)
#         v_img = v.transpose(1, 2).reshape(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         lepe_res = self.lepe(v_img).flatten(2).transpose(1, 2)
        
#         return self.out_proj(out + lepe_res)

# # ==========================================
# # 3. 基础 MLP 模块
# # ==========================================
# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x)
#         x = self.act(x)
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x

# # ==========================================
# # 4. MLLA Block 封装
# # ==========================================
# class MLLABlock(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., order=2, qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.input_resolution = input_resolution
        
#         self.norm1 = norm_layer(dim)
#         self.attn = HarmonicLinearAttentionFull(
#             dim=dim, input_resolution=input_resolution, num_heads=num_heads, 
#             qkv_bias=qkv_bias, order=order
#         )
        
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         # 注意力路径
#         x = x + self.attn(self.norm1(x), self.norm1(source), x_mask, source_mask)
#         # MLP 路径
#         x = x + self.mlp(self.norm2(x))
#         return x

# # ==========================================
# # 5. 最终 MLLA 模块 (支持 Self & Cross Attention)
# # ==========================================
# class MLLA(nn.Module):
#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.):
#         super().__init__()
#         self.layer_names = ["self", "cross"] * 2
        
#         # Self-Attention 通常阶数低，Cross-Attention 阶数高以增强几何匹配
#         self.layers = nn.ModuleList()
#         for name in self.layer_names:
#             order = 1 if name == "self" else 4
#             self.layers.append(
#                 MLLABlock(feature_dim, input_resolution, nhead, mlp_ratio, order=order)
#             )

#     def forward(self, feat0, feat1, mask0=None, mask1=None):
#         for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
#             if name == "self":
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif name == "cross":
#                 feat0 = layer(feat0, feat1, mask0, mask1)
#                 feat1 = layer(feat1, feat0, mask1, mask0)
#         return feat0, feat1


# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()

#         self.nhead = 8  
#         dim = 256
#         input_resolution = [104,104]

#         self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
#         # self.neck = CIM()
       

#     def forward(self, data):
        
#         feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
#         # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
#         # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
#         # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
#         # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)

#         mask_c0 = mask_c1 = None  # mask is useful in training
#         if "mask0" in data:
#             mask_c0, mask_c1 = data["mask0"], data["mask1"]
#         # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
#         # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
#         feat_8_0, feat_8_1 = self.atten(feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
#         # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
#         # B, C, H, W = feat_8_0.shape
#         # feat_c0 = feat_8_0.reshape(B, H*W, C)
#         # feat_c1 = feat_8_1.reshape(B, H*W, C)
#         data.update({
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1
#         })


# ==========================================
# 1. 核心特征映射：正负保真拆分
# ==========================================
# class PreservationFeatureMap(nn.Module):
#     def __init__(self, head_dim):
#         super().__init__()
#         self.head_dim = head_dim

#     def forward(self, x_complex, energy):
#         real = x_complex.real * energy
#         imag = x_complex.imag * energy
#         # 这种拆分确保了线性注意力也能表达复杂的相位相关性
#         real_pos = F.softplus(real)
#         real_neg = F.softplus(-real)
#         imag_pos = F.softplus(imag)
#         imag_neg = F.softplus(-imag)
#         return torch.cat([real_pos, real_neg, imag_pos, imag_neg], dim=-1)

# # ==========================================
# # 2. 谐波线性注意力 (替换原有的 LinearAttention)
# # ==========================================
# class HarmonicLinearAttentionFull(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, qkv_bias=True, order=2, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.input_resolution = input_resolution
#         self.num_heads = num_heads
#         self.head_dim = dim // num_heads
#         self.order = order
        
#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.v = nn.Linear(dim, dim, bias=qkv_bias)
        
#         self.feature_map = PreservationFeatureMap(self.head_dim)
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.attn_eps = 1e-6

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         B, N, C = x.shape
#         H, W = self.input_resolution
#         h_dim = self.head_dim

#         q = self.q(x).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
#         k = self.k(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
#         v = self.v(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)

#         if x_mask is not None:
#             q = q * x_mask.view(B, 1, N, 1)
#         if source_mask is not None:
#             k = k * source_mask.view(B, 1, N, 1)
#             v = v * source_mask.view(B, 1, N, 1)

#         def get_phi(t):
#             t_complex = torch.view_as_complex(t.reshape(B, self.num_heads, N, h_dim // 2, 2))
#             r = t_complex.abs()
#             energy = F.softplus(r)
#             norm_z = t_complex / (r + self.attn_eps)
#             harmonic_z = torch.pow(norm_z, self.order)
#             return self.feature_map(harmonic_z, energy)

#         phi_q = get_phi(q) # (B, H, N, 2D)
#         phi_k = get_phi(k) # (B, H, N, 2D)

#         # 线性注意力核心
#         kv = torch.matmul(phi_k.transpose(-2, -1), v)
#         num = torch.matmul(phi_q, kv)
#         k_sum = phi_k.sum(dim=2, keepdim=True)
#         den = torch.matmul(phi_q, k_sum.transpose(-2, -1)).clamp_min(self.attn_eps)

#         out = (num / den).transpose(1, 2).reshape(B, N, C)
        
#         # LEPE 分支
#         v_img = v.transpose(1, 2).reshape(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         lepe_res = self.lepe(v_img).flatten(2).transpose(1, 2)
        
#         return out + lepe_res

# # ==========================================
# # 3. MLLA Block (完整融合 CPE, DWC, Act_Proj)
# # ==========================================
# class MLLABlock(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., order=2, qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.input_resolution = input_resolution
        
#         # 1. CPE: 条件位置编码分支
#         self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
        
#         # 2. 主路径预处理
#         self.norm1 = norm_layer(dim)
#         self.in_proj = nn.Linear(dim, dim)
#         self.act_proj = nn.Linear(dim, dim) # 激活分支
#         self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim) # 深度卷积增强
#         self.act = nn.SiLU()
        
#         # 3. 升级版谐波注意力
#         self.attn = HarmonicLinearAttentionFull(
#             dim=dim, input_resolution=input_resolution, num_heads=num_heads, 
#             qkv_bias=qkv_bias, order=order
#         )
#         self.out_proj = nn.Linear(dim, dim)
        
#         # 4. FFN 部分
#         self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         H, W = self.input_resolution
#         B, L, C = x.shape

#         # --- CPE1 阶段 ---
#         x1 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe1(x1.contiguous()).flatten(2).permute(0, 2, 1)
#         source1 = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         source = source + self.cpe1(source1.contiguous()).flatten(2).permute(0, 2, 1)
#         shortcut = x

#         # --- 变换阶段 ---
#         x = self.norm1(x)
#         source = self.norm1(source)
        
#         # 激活残差分支 (Gating Mechanism)
#         act_res = self.act(self.act_proj(x))
        
#         # 投影与 DWC 增强
#         x_proj = self.in_proj(x).view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         x = self.act(self.dwc(x_proj)).flatten(2).permute(0, 2, 1)
        
#         src_proj = self.in_proj(source).view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         source = self.act(self.dwc(src_proj)).flatten(2).permute(0, 2, 1)

#         # --- 注意力计算 ---
#         x = self.attn(x, source, x_mask, source_mask)
        
#         # 融合门控并投影
#         x = self.out_proj(x * act_res)
#         x = shortcut + x

#         # --- FFN & CPE2 阶段 ---
#         x2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe2(x2.contiguous()).flatten(2).permute(0, 2, 1)
#         x = x + self.mlp(self.norm2(x))
#         return x


# # ==========================================
# # 3. 基础 MLP 模块
# # ==========================================
# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x)
#         x = self.act(x)
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x



# # ==========================================
# # 5. 最终 MLLA 模块 (支持 Self & Cross Attention)
# # ==========================================
# class MLLA(nn.Module):
#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.):
#         super().__init__()
#         self.layer_names = ["self", "cross"] * 2
        
#         # Self-Attention 通常阶数低，Cross-Attention 阶数高以增强几何匹配
#         self.layers = nn.ModuleList()
#         for name in self.layer_names:
#             order = 1 if name == "self" else 4
#             self.layers.append(
#                 MLLABlock(feature_dim, input_resolution, nhead, mlp_ratio, order=order)
#             )

#     def forward(self, feat0, feat1, mask0=None, mask1=None):
#         for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
#             if name == "self":
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif name == "cross":
#                 feat0 = layer(feat0, feat1, mask0, mask1)
#                 feat1 = layer(feat1, feat0, mask1, mask0)
#         return feat0, feat1


# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()

#         self.nhead = 8  
#         dim = 256
#         input_resolution = [104,104]
#         # input_resolution = [80,60]

#         self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
#         # self.neck = CIM()
       

#     def forward(self, data):
        
#         feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
#         # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
#         # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
#         # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
#         # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)

#         mask_c0 = mask_c1 = None  # mask is useful in training
#         if "mask0" in data:
#             mask_c0, mask_c1 = data["mask0"], data["mask1"]
#         # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
#         # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
#         feat_8_0, feat_8_1 = self.atten(feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
#         # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
#         # B, C, H, W = feat_8_0.shape
#         # feat_c0 = feat_8_0.reshape(B, H*W, C)
#         # feat_c1 = feat_8_1.reshape(B, H*W, C)
#         data.update({
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1
#         })















# ==========================================
# 1. 核心特征映射：正负保真拆分
# ==========================================
# class PreservationFeatureMap(nn.Module):
#     def __init__(self, head_dim):
#         super().__init__()
#         self.head_dim = head_dim

#     def forward(self, x_complex, energy):
#         real = x_complex.real * energy
#         imag = x_complex.imag * energy
#         # 拆分为 4 路非负特征，确保线性点积在复数空间逻辑完备
#         return torch.cat([
#             F.softplus(real), F.softplus(-real), 
#             F.softplus(imag), F.softplus(-imag)
#         ], dim=-1)

# ==========================================
# 2. 改进版：可学习全频段谐波线性注意力
# ==========================================
# class HarmonicLinearAttentionFull(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, qkv_bias=True, order=2, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.input_resolution = input_resolution
#         self.num_heads = num_heads
#         self.head_dim = dim // num_heads
#         self.order = order
        
#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.v = nn.Linear(dim, dim, bias=qkv_bias)
        
#         self.feature_map = PreservationFeatureMap(self.head_dim)
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.attn_eps = 1e-6

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         B, N, C = x.shape
#         H, W = self.input_resolution
#         h_dim = self.head_dim

#         q = self.q(x).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
#         k = self.k(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
#         v = self.v(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)

#         if x_mask is not None:
#             q = q * x_mask.view(B, 1, N, 1)
#         if source_mask is not None:
#             k = k * source_mask.view(B, 1, N, 1)
#             v = v * source_mask.view(B, 1, N, 1)

#         def get_phi(t):
#             t_complex = torch.view_as_complex(t.reshape(B, self.num_heads, N, h_dim // 2, 2))
#             r = t_complex.abs()
#             energy = F.softplus(r)
#             norm_z = t_complex / (r + self.attn_eps)
#             harmonic_z = torch.pow(norm_z, self.order)
#             return self.feature_map(harmonic_z, energy)

#         phi_q = get_phi(q) # (B, H, N, 2D)
#         phi_k = get_phi(k) # (B, H, N, 2D)

#         # 线性注意力核心
#         kv = torch.matmul(phi_k.transpose(-2, -1), v)
#         num = torch.matmul(phi_q, kv)
#         k_sum = phi_k.sum(dim=2, keepdim=True)
#         den = torch.matmul(phi_q, k_sum.transpose(-2, -1)).clamp_min(self.attn_eps)

#         out = (num / den).transpose(1, 2).reshape(B, N, C)
        
#         # LEPE 分支
#         v_img = v.transpose(1, 2).reshape(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         lepe_res = self.lepe(v_img).flatten(2).transpose(1, 2)
        
#         return out + lepe_res


# class HarmonicLinearAttentionFull(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, qkv_bias=True, order=1, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.input_resolution = input_resolution
#         self.num_heads = num_heads
#         self.head_dim = dim // num_heads
#         self.order = order
#         # 定义可学习的频率参数

#         self.head_scales = nn.Parameter(torch.ones(self.num_heads) * self.order)  
#         # self.head_scales = torch.ones(self.num_heads)  
#         # self.register_buffer("head_scales", torch.ones(self.num_heads))

#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.v = nn.Linear(dim, dim, bias=qkv_bias)
        
#         self.feature_map = PreservationFeatureMap(self.head_dim)
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.attn_eps = 1e-6

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         B, N, C = x.shape
#         H, W = self.input_resolution
#         h_dim = self.head_dim

#         q = self.q(x).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
#         k = self.k(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
#         v = self.v(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)

#         if x_mask is not None:
#             q = q * x_mask.view(B, 1, N, 1)
#         if source_mask is not None:
#             k = k * source_mask.view(B, 1, N, 1)
#             v = v * source_mask.view(B, 1, N, 1)

#         def get_phi(t):
#             t_complex = torch.view_as_complex(t.reshape(B, self.num_heads, N, h_dim // 2, 2).contiguous())
#             r = t_complex.abs()
            
#             r_safe = r.clamp_min(self.attn_eps)
#             norm_z = t_complex / r_safe    # |norm_z|≈1，真正“只保相位”
#             energy = F.softplus(r)
#             # norm_z = t_complex / (r + self.attn_eps)
#             # theta = torch.atan2(t_complex.imag, t_complex.real)
#             # freq = self.head_scales.view(1, self.num_heads, 1, 1).clamp(1.0, 5.0)
#             # theta2 = theta * freq
#             # 使用可学习的频率（head_scales）
#             harmonic_z = torch.pow(norm_z, self.head_scales.view(1, self.num_heads, 1, 1).clamp(1.0, 6.0))
#             # harmonic_z = torch.complex(torch.cos(theta2), torch.sin(theta2))
#             return self.feature_map(harmonic_z, energy)

#         phi_q = get_phi(q)  # (B, H, N, 2D)
#         phi_k = get_phi(k)  # (B, H, N, 2D)

#         # 线性注意力核心
#         kv = torch.matmul(phi_k.transpose(-2, -1), v)
#         num = torch.matmul(phi_q, kv)
#         k_sum = phi_k.sum(dim=2, keepdim=True)
#         den = torch.matmul(phi_q, k_sum.transpose(-2, -1)).clamp_min(self.attn_eps)

#         out = (num / den).transpose(1, 2).reshape(B, N, C)
        
#         # LEPE 分支
#         v_img = v.transpose(1, 2).reshape(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         lepe_res = self.lepe(v_img).flatten(2).transpose(1, 2)
        
#         return out + lepe_res


# class HarmonicLinearAttentionFull(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, qkv_bias=True, order=2.0, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.num_heads = num_heads
#         self.head_dim = dim // num_heads
#         self.input_resolution = input_resolution
#         self.base_order = order  # 基础阶数参考值
#         self.attn_eps = 1e-6

#         # --- SLA 核心：引入动态门控投影 ---
#         # 这里的参数量极小（dim * num_heads），负责让模型学习“如何分配频率”
#         self.q_gate_proj = nn.Linear(dim, num_heads, bias=False)
#         self.k_gate_proj = nn.Linear(dim, num_heads, bias=False)

#         # 基础 QKV 投影
#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.v = nn.Linear(dim, dim, bias=qkv_bias)
        
#         # 假设 PreservationFeatureMap 是你定义的用于处理复数到实数特征映射的类
#         self.feature_map = PreservationFeatureMap(self.head_dim)
#         # 局部增强位置编码 (LEPE)
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)

#     def get_phi(self, t, gate_weights, mask=None):
#         """
#         t: (B, H, N, D)
#         gate_weights: (B, H, N, 1) - 已经过 Softmax 的头权重
#         mask: (B, 1, N, 1) - 序列掩码
#         """
#         B, H, N, D = t.shape
#         # 1. 转换为复数空间 (Real/Imaginary 分离)
#         t_complex = torch.view_as_complex(t.reshape(B, H, N, D // 2, 2).contiguous())
        
#         # 2. 提取相位 (norm_z) 和 能量 (energy)
#         r = t_complex.abs()
#         norm_z = t_complex / r.clamp_min(self.attn_eps)
#         energy = F.softplus(r)

#         # 3. 计算动态频率 (Natural Learning)
#         # gate_weights 的均值是 1/H，我们通过 num_heads 恢复其尺度
#         # 使用 Softplus 替代 Clamp，保证频率 > 0 且平滑增长，无上限
#         normalized_weight = gate_weights * self.num_heads
#         # 这里的公式：dynamic_freq = base_order * softplus(权重信号)
#         # 这样模型可以自然地学习到远超 base_order 的高频，也可以自发降到接近 0
#         dynamic_freq = F.softplus(normalized_weight * self.base_order)

#         # 4. 执行谐波变换：(e^{i theta})^k
#         harmonic_z = torch.pow(norm_z, dynamic_freq)
#         pdb.set_trace()
#         # 5. 映射回特征空间并应用 Mask
#         phi = self.feature_map(harmonic_z, energy) # 输出 (B, H, N, 2D)
        
#         if mask is not None:
#             # Mask 为 0 的位置，特征也为 0，不参与 KV 累积
#             phi = phi * mask.view(B, 1, N, 1)
            
#         return phi

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         B, N, C = x.shape
#         H, W = self.input_resolution
#         h_dim = self.head_dim

#         # 1. SLA 动态门控生成 (头维度竞争)
#         # s_q: (B, N, H)
#         s_q = self.q_gate_proj(x)
#         s_k = self.k_gate_proj(source)
        
#         # 在头维度做 Softmax，每个时刻的所有头权重之和为 1
#         g_q = F.softmax(s_q, dim=-1).transpose(1, 2).unsqueeze(-1) # (B, H, N, 1)
#         g_k = F.softmax(s_k, dim=-1).transpose(1, 2).unsqueeze(-1) # (B, H, N, 1)

#         # 2. QKV 基础投影
#         q = self.q(x).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
#         k = self.k(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
#         v = self.v(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)

#         # 3. 获取动态谐波特征 (包含 Mask 处理)
#         phi_q = self.get_phi(q, g_q, x_mask)
#         phi_k = self.get_phi(k, g_k, source_mask)

#         # 4. 线性注意力高效计算 O(N)
#         # (B, H, 2D, N) @ (B, H, N, D) -> (B, H, 2D, D)
#         kv = torch.matmul(phi_k.transpose(-2, -1), v)
#         # (B, H, N, 2D) @ (B, H, 2D, D) -> (B, H, N, D)
#         num = torch.matmul(phi_q, kv)
        
#         # 归一化分母计算
#         k_sum = phi_k.sum(dim=2, keepdim=True) # (B, H, 1, 2D)
#         den = torch.matmul(phi_q, k_sum.transpose(-2, -1)).clamp_min(self.attn_eps)

#         out = (num / den).transpose(1, 2).reshape(B, N, C)
        
#         # 5. 局部增强 (LEPE)
#         # 将 v 映射回图像空间进行卷积
#         v_img = v.transpose(1, 2).reshape(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         lepe_res = self.lepe(v_img).flatten(2).transpose(1, 2)
        
#         return out + lepe_res
# # ==========================================
# # 3. MLLA Block 保持不变，但支持传入 mode
# # ==========================================
# class MLLABlock(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., order=2, mode="self", qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.input_resolution = input_resolution
        
#         self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm1 = norm_layer(dim)
#         self.in_proj = nn.Linear(dim, dim)
#         self.act_proj = nn.Linear(dim, dim)
#         self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.act = nn.SiLU()
        
#         self.attn = HarmonicLinearAttentionFull(
#             dim=dim, input_resolution=input_resolution, num_heads=num_heads, 
#             qkv_bias=qkv_bias, order=order
#         )
#         self.out_proj = nn.Linear(dim, dim)
        
#         self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         H, W = self.input_resolution
#         B, L, C = x.shape

#         x_img = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe1(x_img.contiguous()).flatten(2).permute(0, 2, 1)
#         src_img = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         source = source + self.cpe1(src_img.contiguous()).flatten(2).permute(0, 2, 1)
#         shortcut = x

#         x = self.norm1(x)
#         source = self.norm1(source)
#         act_res = self.act(self.act_proj(x))
        
#         x_p = self.in_proj(x).view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         x = self.act(self.dwc(x_p)).flatten(2).permute(0, 2, 1)
#         src_p = self.in_proj(source).view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         source = self.act(self.dwc(src_p)).flatten(2).permute(0, 2, 1)

#         x = self.attn(x, source, x_mask, source_mask)
#         x = self.out_proj(x * act_res)
#         x = shortcut + x

#         x_img2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe2(x_img2.contiguous()).flatten(2).permute(0, 2, 1)
#         x = x + self.mlp(self.norm2(x))
#         return x
    

# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x)
#         x = self.act(x)
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x
# # ==========================================
# # 4. MLLA 组装：初始化 mode 区别
# # ==========================================
# class MLLA(nn.Module):
#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.):
#         super().__init__()
#         self.layer_names = ["self", "cross"] * 2
#         self.layers = nn.ModuleList()
#         for name in self.layer_names:
#             # Cross 层给更高的阶数初始值
#             order = 1 if name == "self" else 4
#             self.layers.append(
#                 MLLABlock(feature_dim, input_resolution, nhead, mlp_ratio, order=order)
#             )

#     def forward(self, feat0, feat1, mask0=None, mask1=None):
#         for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
#             if name == "self":
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif name == "cross":
#                 feat0 = layer(feat0, feat1, mask0, mask1)
#                 feat1 = layer(feat1, feat0, mask1, mask0)
#         return feat0, feat1

# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()

#         self.nhead = 8  
#         dim = 256
#         input_resolution = [104,104]
#         # input_resolution = [80,60]

#         self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
#         # self.neck = CIM()
       

#     def forward(self, data):
        
#         feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
#         # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
#         # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
#         # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
#         # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)

#         mask_c0 = mask_c1 = None  # mask is useful in training
#         if "mask0" in data:
#             mask_c0, mask_c1 = data["mask0"], data["mask1"]
#         # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
#         # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
#         feat_8_0, feat_8_1 = self.atten(feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
#         # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
#         # B, C, H, W = feat_8_0.shape
#         # feat_c0 = feat_8_0.reshape(B, H*W, C)
#         # feat_c1 = feat_8_1.reshape(B, H*W, C)
#         data.update({
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1
#         })



































# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x)
#         x = self.act(x)
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x





# class RoPE(torch.nn.Module):
#     r"""Rotary Positional Embedding.
#     """
#     def __init__(self, shape, base=10000):
#         super(RoPE, self).__init__()

#         channel_dims, feature_dim = shape[:-1], shape[-1]
#         k_max = feature_dim // (2 * len(channel_dims))

#         assert feature_dim % k_max == 0

#         # angles
#         theta_ks = 1 / (base ** (torch.arange(k_max) / k_max))
#         angles = torch.cat([t.unsqueeze(-1) * theta_ks for t in torch.meshgrid([torch.arange(d) for d in channel_dims], indexing='ij')], dim=-1)

#         # rotation
#         rotations_re = torch.cos(angles).unsqueeze(dim=-1)
#         rotations_im = torch.sin(angles).unsqueeze(dim=-1)
#         rotations = torch.cat([rotations_re, rotations_im], dim=-1)
#         self.register_buffer('rotations', rotations)

#     def forward(self, x):
#         if x.dtype != torch.float32:
#             x = x.to(torch.float32)
#         x = torch.view_as_complex(x.reshape(*x.shape[:-1], -1, 2))
#         pe_x = torch.view_as_complex(self.rotations) * x
#         return torch.view_as_real(pe_x).flatten(-2)
    



# def locality_biased_init(M: int, eps: float = 1e-6) -> torch.Tensor:
#     m = torch.zeros(M, M, dtype=torch.float32)
#     s = int(math.isqrt(M))
#     if s * s == M:
#         coords = torch.stack(
#             torch.meshgrid(
#                 torch.arange(s, dtype=torch.float32),
#                 torch.arange(s, dtype=torch.float32),
#                 indexing="ij",
#             ),
#             dim=-1
#         ).reshape(M, 2)  # float32

#         for i in range(M):
#             dist = torch.norm(coords[i] - coords, dim=-1)  # [M], float
#             maxdist = dist.max().clamp_min(eps)
#             w = 1.0 - dist / maxdist
#             w = torch.clamp(w, min=0.0)
#             w = w / (w.sum() + eps)
#             m[i] = w
#     else:
#         pos = torch.arange(M, dtype=torch.float32)
#         for i in range(M):
#             dist = (pos - pos[i]).abs()
#             maxdist = dist.max().clamp_min(eps)
#             w = 1.0 - dist / maxdist
#             w = torch.clamp(w, min=0.0)
#             w = w / (w.sum() + eps)
#             m[i] = w
#     return m
# def _flatten_mask(mask: torch.Tensor, B: int, N: int) -> torch.Tensor:
#     """
#     支持 mask 形状：
#     - [B, N]
#     - [B, H, W]
#     - [B, 1, H, W]
#     - [B, 1, N]
#     返回 [B, N]，且 dtype=float32/与计算一致
#     约定：mask==1 表示有效；mask==0 表示无效
#     """
#     if mask is None:
#         return None
#     if mask.dim() == 4:  # [B,1,H,W] or [B,C,H,W]
#         mask = mask[:, 0]  # -> [B,H,W]
#     if mask.dim() == 3:  # [B,H,W] or [B,1,N]
#         if mask.shape[1] == 1 and mask.shape[2] == N:
#             mask = mask[:, 0, :]  # [B,N]
#         else:
#             mask = mask.reshape(B, -1)  # [B,H*W]
#     if mask.dim() != 2:
#         raise ValueError(f"Unsupported mask shape: {tuple(mask.shape)}")

#     if mask.shape[1] != N:
#         raise ValueError(f"Mask length mismatch: mask={mask.shape}, expected N={N}")

#     # 转成 0/1 float（若你的 mask 是 bool/long 都行）
#     mask = mask.to(dtype=torch.float32)
#     return mask

# class LinearAttention(nn.Module):
#     """
#     MHLA (Multi-Head Linear Attention) —— 注意这里的 “Head” 是 token blocks 数 M（num_groups），
#     不是传统 multi-head 的通道分头。
#     对应论文 Eq.(3)(4)：
#       S_b = Σ_{j∈b}  K̃_j V_j^T ,  z_b = Σ_{j∈b} K̃_j
#       S^e_i = Σ_b m_{i,b} S_b ,  z^e_i = Σ_b m_{i,b} z_b
#       o = (q̃^T S^e_i) / (q̃^T z^e_i)
#     :contentReference[oaicite:5]{index=5}
#     """
#     def __init__(self, dim, input_resolution, num_heads, num_groups=64, rope=False, qkv_bias=True, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.num_heads = num_heads          # 为了兼容你外部结构，保留但不用于 MHLA 的分块逻辑
#         self.num_groups = num_groups        # 论文里的 M（blocks/head number）
#         self.isrope = rope
#         self.eps = 1e-6

#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.v = nn.Linear(dim, dim, bias=qkv_bias)

#         # 论文的系数矩阵 Mc ∈ R^{M×M}（第 i 行是 m_i）
#         # :contentReference[oaicite:6]{index=6}
#         self.mixing = nn.Parameter(torch.empty(num_groups, num_groups))

#         # locality-biased init（更稳），然后可学习
#         with torch.no_grad():
#             self.mixing.copy_(locality_biased_init(num_groups))

#         # LePE（你的原逻辑保留：DWConv 做局部增强）
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)

#         # RoPE（你原实现保留）
#         self.rope = RoPE(shape=(input_resolution[0], input_resolution[1], dim))

#     def _get_coeff(self) -> torch.Tensor:
#         """
#         论文：非负 + 归一化；并“每次更新 clip 到 (0,1)”
#         :contentReference[oaicite:7]{index=7}
#         """
#         w = torch.softmax(self.mixing, dim=-1)
#                                # nonnegative
#         w = w / (w.sum(dim=-1, keepdim=True) + self.eps)      # row-normalize
#         w = w.clamp(min=self.eps, max=1.0 - self.eps)         # clip to (0,1)
#         # 再归一化一次，避免 clamp 后行和不为 1
#         w = w / (w.sum(dim=-1, keepdim=True) + self.eps)
#         return w

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         """
#         x:      [B, N, C]
#         source: [B, N, C]
#         x_mask/source_mask: 1=valid, 0=invalid
#         """
#         B, N, C = x.shape
#         M = self.num_groups
#         assert C == self.dim
#         assert N % M == 0, f"N={N} 必须能被 num_groups(M)={M} 整除"
#         Nb = N // M

#         # ====== (0) 解析 mask ======
#         x_mask_f = _flatten_mask(x_mask, B, N) if x_mask is not None else None
#         s_mask_f = _flatten_mask(source_mask, B, N) if source_mask is not None else None

#         h_res = int(math.isqrt(N))
#         w_res = h_res
#         assert h_res * w_res == N, f"N={N} 不是平方数，无法用 sqrt(N) 还原 H,W"

#         # 1) linear attention 的 feature map
#         q = F.relu(self.q(x)) + self.eps
#         k = F.relu(self.k(source)) + self.eps
#         v = self.v(source)

#         # ====== (1) 对 K/V 做 mask（最关键）======
#         # 无效 token 的 k/v 置 0，保证 S,z 不被污染
#         if s_mask_f is not None:
#             s_mask_f = s_mask_f.to(device=k.device)  # [B,N]
#             s_mask_f = s_mask_f.unsqueeze(-1)        # [B,N,1]
#             k = k * s_mask_f
#             v = v * s_mask_f

#         # 2) RoPE（可选）
#         if self.isrope:
#             q = self.rope(q.reshape(B, h_res, w_res, C)).reshape(B, N, C)
#             k = self.rope(k.reshape(B, h_res, w_res, C)).reshape(B, N, C)

#         # ====== (2) 可选：对 Q 做 mask ======
#         # 这会让无效 query token 的输出趋向 0（更干净）
#         if x_mask_f is not None:
#             x_mask_f = x_mask_f.to(device=q.device).unsqueeze(-1)  # [B,N,1]
#             q = q * x_mask_f

#         # 3) 分块： [B, M, Nb, C]
#         q_blk = q.reshape(B, M, Nb, C).contiguous()
#         k_blk = k.reshape(B, M, Nb, C).contiguous()
#         v_blk = v.reshape(B, M, Nb, C).contiguous()

#         # ====== (3) 如果 mask 不是按 token 直接置零，也可以在 block 内再次保险（可选）======
#         # （一般上面置零已经足够，这里不再重复）

#         # 4) 局部 summaries（Eq.3）
#         S = torch.einsum("bmnc,bmnd->bmcd", k_blk, v_blk)  # [B,M,C,C]
#         z = k_blk.sum(dim=2)                               # [B,M,C]

#         # 5) mixing（Eq.4）
#         coeff = self._get_coeff()                          # [M,M]
#         Se = torch.einsum("im,bmcd->bicd", coeff, S).contiguous()  # [B,M,C,C]
#         ze = torch.einsum("im,bmc->bic",  coeff, z).contiguous()   # [B,M,C]

#         # 6) 输出（Eq.4）
#         num = torch.einsum("bmnc,bmcd->bmnd", q_blk, Se)            # [B,M,Nb,C]
#         den = torch.einsum("bmnc,bmc->bmn",  q_blk, ze) + self.eps  # [B,M,Nb]
#         out_blk = num / den.unsqueeze(-1)

#         out = out_blk.reshape(B, N, C).contiguous()

#         # ====== (4) 对输出再 mask 一下（可选但推荐）======
#         # 保证无效 query token 输出严格为 0
#         if x_mask_f is not None:
#             out = out * x_mask_f  # x_mask_f 已是 [B,N,1]

#         # 7) LePE（只对有效区域更合理；我们也可以用 source_mask 控它）
#         v_lepe = v.transpose(1, 2).reshape(B, C, h_res, w_res).contiguous()
#         lepe = self.lepe(v_lepe).flatten(2).transpose(1, 2).contiguous()

#         if x_mask_f is not None:
#             lepe = lepe * x_mask_f  # 只加到有效 query 上

#         out = out + lepe
#         return out


# # --- 后续的 MLLABlock, MLLA, JointMamba 保持结构不变，仅确保参数传递 ---
# class MLLABlock(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., rope=False, qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.input_resolution = input_resolution
        
#         # CPE 逻辑保留
#         self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm1 = norm_layer(dim)
#         self.in_proj = nn.Linear(dim, dim)
#         self.act_proj = nn.Linear(dim, dim)
#         self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.act = nn.SiLU()
        
#         # 这里使用了更新后的 MHLA LinearAttention
#         self.attn = LinearAttention(dim=dim, input_resolution=input_resolution, num_heads=num_heads, rope=rope, qkv_bias=qkv_bias)
        
#         self.out_proj = nn.Linear(dim, dim)
#         self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         H, W = self.input_resolution
#         B, L, C = x.shape

#         # CPE 1
#         x1 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe1(x1.contiguous()).flatten(2).permute(0, 2, 1)
#         source1 = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         source = source + self.cpe1(source1.contiguous()).flatten(2).permute(0, 2, 1)
        
#         shortcut = x
#         x = self.norm1(x)
#         source = self.norm1(source)
        
#         # 门控分支逻辑
#         act_res = self.act(self.act_proj(x))
        
#         # 进入 MHLA 注意力
#         x = self.attn(x, source, x_mask, source_mask)
        
#         x = self.out_proj(x * act_res)
#         x = shortcut + x
        
#         # CPE 2 & FFN
#         x2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe2(x2.contiguous()).flatten(2).permute(0, 2, 1)
#         x = x + self.mlp(self.norm2(x))
#         return x
# class MLLA(nn.Module):

#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.,):
#         super(MLLA, self).__init__()
#         self.layer_names = ["self", "cross"]*2
        
#         self_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = True,
#         )
#         cross_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = False,    
#         )

#         self.layers = nn.ModuleList(
#             [
#                 (
#                     copy.deepcopy(self_layer)
#                     if _ == "self"
#                     else copy.deepcopy(cross_layer)
#                 )
#                 for _ in self.layer_names
#             ]
#         )
#         self._reset_parameters()

#     def _reset_parameters(self):
#         for p in self.parameters():
#             if p.dim() > 1:
#                 nn.init.xavier_uniform_(p)

#     def forward(self, feat0, feat1, mask0=None, mask1=None, data=None):
#         """
#         Args:
#             feat0 (torch.Tensor): [N, C, H, W]
#             feat1 (torch.Tensor): [N, C, H, W]
#             mask0 (torch.Tensor): [N, H, W]
#             mask1 (torch.Tensor): [N, H, W]
#         """
#         # B, C, H, W = feat0.shape
#         # feat0 = feat0.reshape(B, H*W, C)
#         # feat1 = feat1.reshape(B, H*W, C)
#         for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
#             if name == "self":
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif name == "cross":
#                 feat0 = layer(feat0, feat1, mask0, mask1)
#                 feat1 = layer(feat1, feat0, mask1, mask0)
#             else:
#                 raise KeyError

#         return feat0, feat1



# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()

#         self.nhead = 8  
#         dim = 256
#         input_resolution = [104,104]

#         self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
#         # self.neck = CIM()
       

#     def forward(self, data):
        
#         feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
#         # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
#         # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
#         # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
#         # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)

#         mask_c0 = mask_c1 = None  # mask is useful in training
#         if "mask0" in data:
#             mask_c0, mask_c1 = data["mask0"], data["mask1"]
#         # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
#         # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
#         feat_8_0, feat_8_1 = self.atten(feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
#         # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
#         # B, C, H, W = feat_8_0.shape
#         # feat_c0 = feat_8_0.reshape(B, H*W, C)
#         # feat_c1 = feat_8_1.reshape(B, H*W, C)
#         data.update({
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1
#         })
















# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x)
#         x = self.act(x)
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x





# class RoPE(torch.nn.Module):
#     r"""Rotary Positional Embedding.
#     """
#     def __init__(self, shape, base=10000):
#         super(RoPE, self).__init__()

#         channel_dims, feature_dim = shape[:-1], shape[-1]
#         k_max = feature_dim // (2 * len(channel_dims))

#         assert feature_dim % k_max == 0

#         # angles
#         theta_ks = 1 / (base ** (torch.arange(k_max) / k_max))
#         angles = torch.cat([t.unsqueeze(-1) * theta_ks for t in torch.meshgrid([torch.arange(d) for d in channel_dims], indexing='ij')], dim=-1)

#         # rotation
#         rotations_re = torch.cos(angles).unsqueeze(dim=-1)
#         rotations_im = torch.sin(angles).unsqueeze(dim=-1)
#         rotations = torch.cat([rotations_re, rotations_im], dim=-1)
#         self.register_buffer('rotations', rotations)

#     def forward(self, x):
#         if x.dtype != torch.float32:
#             x = x.to(torch.float32)
#         x = torch.view_as_complex(x.reshape(*x.shape[:-1], -1, 2))
#         pe_x = torch.view_as_complex(self.rotations) * x
#         return torch.view_as_real(pe_x).flatten(-2)
    
# class LinearAttention(nn.Module):
#     r""" 基于文章 GRLA 改进的 GRBFLA 模块 """
#     def __init__(self, dim, input_resolution, num_heads, rope=False, qkv_bias=True, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.num_heads = num_heads
#         self.head_dim = dim // num_heads
#         self.isrope = rope
#         self.input_resolution = input_resolution
        
#         # 文章 3.3 节提到的带宽参数 gamma
#         self.gamma = 1.0 / (2.0 * math.sqrt(self.head_dim))
        
#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.v = nn.Linear(dim, dim, bias=qkv_bias) # 增加显式的 v 投影以符合标准架构
        
#         # LePE (Locality-enhanced Positional Encoding)
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.rope = RoPE(shape=(input_resolution[0], input_resolution[1], dim))
#         self.proj = nn.Linear(dim, dim)

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         b, n, c = x.shape
#         h, w = self.input_resolution
#         num_heads = self.num_heads
#         head_dim = self.head_dim

#         # 1. Q, K, V 投影与重塑
#         q = self.q(x).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         k = self.k(source).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#         v = self.v(source).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)

#       # 2. 位置编码 (确保连续性，修复之前提到的 DDP 警告)
#         if self.isrope:
#             q = self.rope(q.permute(0, 2, 1, 3).reshape(b, h, w, c).contiguous()).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)
#             k = self.rope(k.permute(0, 2, 1, 3).reshape(b, h, w, c).contiguous()).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3)

#         # 3. 计算 phi(K) — 根据文章 Eq. 7, 9, 12 [cite: 91, 100, 103]
#         # 注意：这里应该使用归一化前的 k 来保留二范数信息
#         k_sq_norm = torch.sum(k**2, dim=-1, keepdim=True) # [B, Head, N, 1]
#         phi_k = torch.exp(-self.gamma * k_sq_norm)        # 这里的 phi_k 就不再是常数了 

#         # 4. L2 归一化 Q 和 K (用于 Taylor 近似的稳定性) 
#         q_norm = F.normalize(q, p=2, dim=-1)
#         k_norm = F.normalize(k, p=2, dim=-1)

#         # 5. Mask 处理
#         if source_mask is not None:
#             m = source_mask.reshape(b, 1, n, 1)
#             phi_k = phi_k * m
#             v = v * m

#         # 6. 线性聚合 (文章 Eq. 12) [cite: 103]
#         # 分子项 1: sum(phi(K) * V)
#         phi_k_v = torch.sum(phi_k * v, dim=-2, keepdim=True) 
        
#         # 分子项 2: 2 * gamma * Q @ (sum(phi(K) * K^T * V))
#         # 优化计算顺序: K^T @ (phi_k * V)
#         phi_k_k = phi_k * k_norm
#         kv_interact = torch.matmul(phi_k_k.transpose(-2, -1), v) # [B, Head, D, D]
        
#         # 分母项 (归一化因子) [cite: 108, 109]
#         den_1 = torch.sum(phi_k, dim=-2, keepdim=True) # [B, Head, 1, 1]
#         phi_k_k_sum = torch.sum(phi_k_k, dim=-2, keepdim=True) # [B, Head, 1, D]

#         # 7. 组合最终输出
#         num = phi_k_v + 2 * self.gamma * torch.matmul(q_norm, kv_interact)
#         den = den_1 + 2 * self.gamma * torch.matmul(q_norm, phi_k_k_sum.transpose(-2, -1))
        
#         x_attn = num / (den + 1e-6)

#         # 8. 还原形状并添加 LePE (添加 .contiguous() 修复步长不匹配警告)
#         x_attn = x_attn.transpose(1, 2).reshape(b, n, c)
        
#         v_img = v.transpose(1, 2).reshape(b, n, c).transpose(1, 2).reshape(b, c, h, w).contiguous()
#         x_lepe = self.lepe(v_img).flatten(2).transpose(1, 2)
        
#         x = self.proj(x_attn + x_lepe)
#         return x
    
# class MLLABlock(nn.Module):
#     r""" MLLA Block.

#     Args:
#         dim (int): Number of input channels.
#         input_resolution (tuple[int]): Input resulotion.
#         num_heads (int): Number of attention heads.
#         mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
#         qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
#         drop (float, optional): Dropout rate. Default: 0.0
#         drop_path (float, optional): Stochastic depth rate. Default: 0.0
#         act_layer (nn.Module, optional): Activation layer. Default: nn.GELU
#         norm_layer (nn.Module, optional): Normalization layer.  Default: nn.LayerNorm
#     """

#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., rope=False, qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.num_heads = num_heads
#         self.mlp_ratio = mlp_ratio
#         self.input_resolution = input_resolution

#         self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm1 = norm_layer(dim)
#         self.in_proj = nn.Linear(dim, dim)
#         self.act_proj = nn.Linear(dim, dim)
#         self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.act = nn.SiLU()
#         self.attn = LinearAttention(dim=dim, input_resolution=input_resolution, num_heads=num_heads, rope = rope, qkv_bias=qkv_bias)
#         self.out_proj = nn.Linear(dim, dim)
        
#         self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, x, source, x_mask=None, source_mask=None):
        
#         '''
#             x: input feature of shape: [B, L, C]
#         '''
#         H, W = self.input_resolution
#         B, L, C = x.shape

#         x1 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe1(x1.contiguous()).flatten(2).permute(0, 2, 1)
#         source1 = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         source = source + self.cpe1(source1.contiguous()).flatten(2).permute(0, 2, 1)
#         shortcut = x

#         x = self.norm1(x)
#         source = self.norm1(source)
#         act_res = self.act(self.act_proj(x))
#         x = self.in_proj(x).view(B, H, W, C)
#         source = self.in_proj(source).view(B, H, W, C)
#         # x = self.act(self.dwc(x.permute(0, 3, 1, 2))).permute(0, 2, 3, 1).view(B, L, C)
#         x = self.act(self.dwc(x.permute(0, 3, 1, 2).contiguous())).permute(0, 2, 3, 1).view(B, L, C)
#         source = self.act(self.dwc(source.permute(0, 3, 1, 2).contiguous())).permute(0, 2, 3, 1).view(B, L, C)

#         # # Linear Attention
#         x = self.attn(x, source, x_mask, source_mask)
        
#         x = self.out_proj(x * act_res)
#         x = shortcut + x
#         x2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe2(x2.contiguous()).flatten(2).permute(0, 2, 1)

#         # # FFN
#         x = x + self.mlp(self.norm2(x))
#         return x

#     def extra_repr(self) -> str:
#         return f"dim={self.dim}, input_resolution={self.input_resolution}, num_heads={self.num_heads}, " \
#                f"mlp_ratio={self.mlp_ratio}"

# class MLLA(nn.Module):

#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.,):
#         super(MLLA, self).__init__()
#         self.layer_names = ["self", "cross"]*2
        
#         self_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = True,
#         )
#         cross_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = False,    
#         )

#         self.layers = nn.ModuleList(
#             [
#                 (
#                     copy.deepcopy(self_layer)
#                     if _ == "self"
#                     else copy.deepcopy(cross_layer)
#                 )
#                 for _ in self.layer_names
#             ]
#         )
#         self._reset_parameters()

#     def _reset_parameters(self):
#         for p in self.parameters():
#             if p.dim() > 1:
#                 nn.init.xavier_uniform_(p)

#     def forward(self, feat0, feat1, mask0=None, mask1=None, data=None):
#         """
#         Args:
#             feat0 (torch.Tensor): [N, C, H, W]
#             feat1 (torch.Tensor): [N, C, H, W]
#             mask0 (torch.Tensor): [N, H, W]
#             mask1 (torch.Tensor): [N, H, W]
#         """
#         # B, C, H, W = feat0.shape
#         # feat0 = feat0.reshape(B, H*W, C)
#         # feat1 = feat1.reshape(B, H*W, C)
#         for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
#             if name == "self":
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif name == "cross":
#                 feat0 = layer(feat0, feat1, mask0, mask1)
#                 feat1 = layer(feat1, feat0, mask1, mask0)
#             else:
#                 raise KeyError

#         return feat0, feat1



# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()

#         self.nhead = 8  
#         dim = 256
#         input_resolution = [104,104]

#         self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
#         # self.neck = CIM()
       

#     def forward(self, data):
        
#         feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
#         # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
#         # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
#         # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
#         # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)

#         mask_c0 = mask_c1 = None  # mask is useful in training
#         if "mask0" in data:
#             mask_c0, mask_c1 = data["mask0"], data["mask1"]
#         # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
#         # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
#         feat_8_0, feat_8_1 = self.atten(feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
#         # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
#         # B, C, H, W = feat_8_0.shape
#         # feat_c0 = feat_8_0.reshape(B, H*W, C)
#         # feat_c1 = feat_8_1.reshape(B, H*W, C)
#         data.update({
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1
#         })










# class LinearAttention(nn.Module):
#     r""" MALA Linear Attention with LePE and optional RoPE (gamma uses SUM(V)).

#     Args:
#         dim (int): Number of input channels.
#         input_resolution (tuple[int,int]): (H,W) of tokens (assumed square N=H*W in your code).
#         num_heads (int): Number of attention heads.
#         rope (bool): Whether to apply RoPE to q/k for content mixing.
#         qkv_bias (bool): Bias for q/k projection.
#     """

#     def __init__(self, dim, input_resolution, num_heads, rope=False, qkv_bias=True, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.isrope = rope
#         self.input_resolution = input_resolution
#         self.num_heads = num_heads

#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)

#         self.elu = nn.ELU()
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)

#         # uses your RoPE class defined above
#         self.rope = RoPE(shape=(input_resolution[0], input_resolution[1], dim))

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         """
#         Args:
#             x:      (B, N, C)
#             source: (B, N, C)   (self-attn: source=x; cross-attn: source=other)
#             x_mask: (B, H, W) or None
#             source_mask: (B, H, W) or None
#         Returns:
#             out: (B, N, C)
#         """
#         b, n, c = x.shape
#         h = int(n ** 0.5)
#         w = int(n ** 0.5)

#         num_heads = self.num_heads
#         head_dim = c // num_heads

#         # Project + feature map (phi = ELU + 1, non-negative)
#         q = self.elu(self.q(x)) + 1.0              # (B,N,C)
#         k = self.elu(self.k(source)) + 1.0         # (B,N,C)
#         v = source                                 # (B,N,C)  (as in your code)

#         # Masks (same as your logic)
#         if x_mask is not None:
#             x_mask = x_mask.reshape(b, 1, n).transpose(1, 2)    # (B,N,1)
#             q = q * x_mask
#         if source_mask is not None:
#             source_mask = source_mask.reshape(b, 1, n).transpose(1, 2)  # (B,N,1)
#             k = k * source_mask
#             v = v * source_mask

#         # Reshape to multi-head: (B,H,N,D)
#         q = q.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3).contiguous()
#         k = k.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3).contiguous()
#         v = v.reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3).contiguous()

#         # Optional RoPE (apply on q/k for content mixing)
#         if self.isrope:
#             # convert back to (B,H,W,C) for your RoPE implementation which expects (..., dim)
#             q_img = q.permute(0, 2, 1, 3).reshape(b, h, w, c)  # (B,h,w,C)
#             k_img = k.permute(0, 2, 1, 3).reshape(b, h, w, c)  # (B,h,w,C)

#             q_rope = self.rope(q_img).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3).contiguous()
#             k_rope = self.rope(k_img).reshape(b, n, num_heads, head_dim).permute(0, 2, 1, 3).contiguous()
#         else:
#             q_rope = q
#             k_rope = k

#         # =========================
#         # MALA core (paper-style):
#         # additive normalization + beta/gamma magnitude injection
#         #
#         # denom_i = phi(q_i) · mean(phi(k))    -> (B,H,N,1)
#         # beta_i  = 1 + 1/(denom_i + eps)
#         # gamma_i = denom_i
#         #
#         # Y = beta * (phi(q) @ (phi(k)^T v)) - gamma * sum(v)
#         # =========================
#         eps = 1e-6

#         denom = (q @ k.mean(dim=-2, keepdim=True).transpose(-2, -1))  # (B,H,N,1)
#         beta  = 1.0 + 1.0 / (denom + eps)                             # (B,H,N,1)
#         gamma = denom                                                 # (B,H,N,1)

#         # KV = sum phi(k)^T v  (keep your original scaling)
#         kv = (k_rope.transpose(-2, -1) * (n ** -0.5)) @ (v * (n ** -0.5))  # (B,H,D,D)

#         main = q_rope @ kv                                           # (B,H,N,D)

#         # STRICT SUM(V) for gamma term (paper-closer than mean)
#         v_sum = v.sum(dim=2, keepdim=True)                           # (B,H,1,D)  == ΣV

#         out = main * beta - gamma * v_sum                             # (B,H,N,D)
#         # =========================

#         # Merge heads back: (B,N,C)
#         out = out.transpose(1, 2).reshape(b, n, c).contiguous()

#         # LePE (same as your original)
#         v_img = v.transpose(1, 2).reshape(b, h, w, c).permute(0, 3, 1, 2).contiguous()  # (B,C,H,W)
#         out = out + self.lepe(v_img).permute(0, 2, 3, 1).reshape(b, n, c).contiguous()

#         return out

#     def extra_repr(self) -> str:
#         return f"dim={self.dim}, num_heads={self.num_heads}, rope={self.isrope}"
    



# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x)
#         x = self.act(x)
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x





# class RoPE(torch.nn.Module):
#     r"""Rotary Positional Embedding.
#     """
#     def __init__(self, shape, base=10000):
#         super(RoPE, self).__init__()

#         channel_dims, feature_dim = shape[:-1], shape[-1]
#         k_max = feature_dim // (2 * len(channel_dims))

#         assert feature_dim % k_max == 0

#         # angles
#         theta_ks = 1 / (base ** (torch.arange(k_max) / k_max))
#         angles = torch.cat([t.unsqueeze(-1) * theta_ks for t in torch.meshgrid([torch.arange(d) for d in channel_dims], indexing='ij')], dim=-1)

#         # rotation
#         rotations_re = torch.cos(angles).unsqueeze(dim=-1)
#         rotations_im = torch.sin(angles).unsqueeze(dim=-1)
#         rotations = torch.cat([rotations_re, rotations_im], dim=-1)
#         self.register_buffer('rotations', rotations)

#     def forward(self, x):
#         if x.dtype != torch.float32:
#             x = x.to(torch.float32)
#         x = torch.view_as_complex(x.reshape(*x.shape[:-1], -1, 2))
#         pe_x = torch.view_as_complex(self.rotations) * x
#         return torch.view_as_real(pe_x).flatten(-2)
    

# class MLLABlock(nn.Module):
#     r""" MLLA Block.

#     Args:
#         dim (int): Number of input channels.
#         input_resolution (tuple[int]): Input resulotion.
#         num_heads (int): Number of attention heads.
#         mlp_ratio (float): Ratio of mlp hidden dim to embedding dim.
#         qkv_bias (bool, optional): If True, add a learnable bias to query, key, value. Default: True
#         drop (float, optional): Dropout rate. Default: 0.0
#         drop_path (float, optional): Stochastic depth rate. Default: 0.0
#         act_layer (nn.Module, optional): Activation layer. Default: nn.GELU
#         norm_layer (nn.Module, optional): Normalization layer.  Default: nn.LayerNorm
#     """

#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., rope=False, qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.num_heads = num_heads
#         self.mlp_ratio = mlp_ratio
#         self.input_resolution = input_resolution

#         self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm1 = norm_layer(dim)
#         self.in_proj = nn.Linear(dim, dim)
#         self.act_proj = nn.Linear(dim, dim)
#         self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.act = nn.SiLU()
#         self.attn = LinearAttention(dim=dim, input_resolution=input_resolution, num_heads=num_heads, rope = rope, qkv_bias=qkv_bias)
#         self.out_proj = nn.Linear(dim, dim)
        
#         self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, x, source, x_mask=None, source_mask=None):
        
#         '''
#             x: input feature of shape: [B, L, C]
#         '''
#         H, W = self.input_resolution
#         B, L, C = x.shape

#         x1 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe1(x1.contiguous()).flatten(2).permute(0, 2, 1)
#         source1 = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         source = source + self.cpe1(source1.contiguous()).flatten(2).permute(0, 2, 1)
#         shortcut = x

#         x = self.norm1(x)
#         source = self.norm1(source)
#         act_res = self.act(self.act_proj(x))
#         x = self.in_proj(x).view(B, H, W, C)
#         source = self.in_proj(source).view(B, H, W, C)
#         # x = self.act(self.dwc(x.permute(0, 3, 1, 2))).permute(0, 2, 3, 1).view(B, L, C)
#         x = self.act(self.dwc(x.permute(0, 3, 1, 2).contiguous())).permute(0, 2, 3, 1).view(B, L, C)
#         source = self.act(self.dwc(source.permute(0, 3, 1, 2).contiguous())).permute(0, 2, 3, 1).view(B, L, C)

#         # # Linear Attention
#         x = self.attn(x, source, x_mask, source_mask)
        
#         x = self.out_proj(x * act_res)
#         x = shortcut + x
#         x2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe2(x2.contiguous()).flatten(2).permute(0, 2, 1)

#         # # FFN
#         x = x + self.mlp(self.norm2(x))
#         return x

#     def extra_repr(self) -> str:
#         return f"dim={self.dim}, input_resolution={self.input_resolution}, num_heads={self.num_heads}, " \
#                f"mlp_ratio={self.mlp_ratio}"

# class MLLA(nn.Module):

#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.,):
#         super(MLLA, self).__init__()
#         self.layer_names = ["self", "cross"]*2
        
#         self_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = True,
#         )
#         cross_layer = MLLABlock(
#             feature_dim,
#             input_resolution,
#             nhead,
#             mlp_ratio,
#             rope = False,    
#         )

#         self.layers = nn.ModuleList(
#             [
#                 (
#                     copy.deepcopy(self_layer)
#                     if _ == "self"
#                     else copy.deepcopy(cross_layer)
#                 )
#                 for _ in self.layer_names
#             ]
#         )
#         self._reset_parameters()

#     def _reset_parameters(self):
#         for p in self.parameters():
#             if p.dim() > 1:
#                 nn.init.xavier_uniform_(p)

#     def forward(self, feat0, feat1, mask0=None, mask1=None, data=None):
#         """
#         Args:
#             feat0 (torch.Tensor): [N, C, H, W]
#             feat1 (torch.Tensor): [N, C, H, W]
#             mask0 (torch.Tensor): [N, H, W]
#             mask1 (torch.Tensor): [N, H, W]
#         """
#         # B, C, H, W = feat0.shape
#         # feat0 = feat0.reshape(B, H*W, C)
#         # feat1 = feat1.reshape(B, H*W, C)
#         for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
#             if name == "self":
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif name == "cross":
#                 feat0 = layer(feat0, feat1, mask0, mask1)
#                 feat1 = layer(feat1, feat0, mask1, mask0)
#             else:
#                 raise KeyError

#         return feat0, feat1



# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()

#         self.nhead = 8  
#         dim = 256
#         input_resolution = [104,104]

#         self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
#         # self.neck = CIM()
       

#     def forward(self, data):
        
#         feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
#         # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
#         # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
#         # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
#         # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)

#         mask_c0 = mask_c1 = None  # mask is useful in training
#         if "mask0" in data:
#             mask_c0, mask_c1 = data["mask0"], data["mask1"]
#         # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
#         # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
#         feat_8_0, feat_8_1 = self.atten(feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
#         # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
#         # B, C, H, W = feat_8_0.shape
#         # feat_c0 = feat_8_0.reshape(B, H*W, C)
#         # feat_c1 = feat_8_1.reshape(B, H*W, C)
#         data.update({
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1
#         })





# import torch
# import torch.nn as nn
# import torch.nn.functional as F

# # ==========================================
# # 1. 基础组件：特征映射 (保持复数分布完整性)
# # ==========================================
# class PreservationFeatureMap(nn.Module):
#     def __init__(self, head_dim):
#         super().__init__()
#         self.head_dim = head_dim

#     def forward(self, x_complex, energy):
#         # 这里的 energy 对应复数的幅值 r 的 softplus
#         real = x_complex.real * energy
#         imag = x_complex.imag * energy
#         # 将复数平面拆解为 4 个非负象限，确保线性注意力的正定性
#         return torch.cat([
#             F.softplus(real), F.softplus(-real), 
#             F.softplus(imag), F.softplus(-imag)
#         ], dim=-1)

# # ==========================================
# # 2. 核心模块：多阶数并行谐波注意力
# # ==========================================
# class HarmonicLinearAttentionFull(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, qkv_bias=True, mode="self", **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.num_heads = num_heads
#         self.head_dim = dim // num_heads
#         self.input_resolution = input_resolution
#         self.attn_eps = 1e-6

#         # --- 固定骨架：根据模式分配阶数 ---
#         if mode == "self":
#             # 自注意力：偏重全局感知的低阶 (4个1阶, 2个2阶, 2个4阶)
#             orders = torch.tensor([1.0, 1.0, 1.0, 1.0, 2.0, 2.0, 4.0, 4.0])
#         else:
#             # 互注意力：偏重匹配精度的中高阶 (2个2阶, 4个4阶, 2个8阶)
#             orders = torch.tensor([2.0, 2.0, 4.0, 4.0, 4.0, 4.0, 8.0, 8.0])
        
#         # 存为 Buffer，不参与反向传播，推理速度快
#         self.register_buffer('orders', orders.view(1, num_heads, 1, 1))

#         # --- 灵活血肉：可学习的 Head 贡献权重 ---
#         self.head_scale = nn.Parameter(torch.ones(1, num_heads, 1, 1))

#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.v = nn.Linear(dim, dim, bias=qkv_bias)
        
#         self.feature_map = PreservationFeatureMap(self.head_dim)
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.out_proj = nn.Linear(dim, dim)

#     def get_phi(self, t, mask=None):
#         B, H, N, D = t.shape
#         # 1. 转换为复数空间
#         t_complex = torch.view_as_complex(t.reshape(B, H, N, D // 2, 2).contiguous())
        
#         # 2. 提取相位 (norm_z) 和 能量 (energy)
#         r = t_complex.abs()
#         norm_z = t_complex / r.clamp_min(self.attn_eps)
#         energy = F.softplus(r)

#         # 3. 核心：广播阶数变换 (n 次幂旋转)
#         # 每个 Head 对应 self.orders 中预设的阶数
#         harmonic_z = torch.pow(norm_z, self.orders)
        
#         # 4. 映射回实数特征空间
#         phi = self.feature_map(harmonic_z, energy)
        
#         if mask is not None:
#             phi = phi * mask.view(B, 1, N, 1)
#         return phi

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         B, N, C = x.shape
#         H, W = self.input_resolution

#         # QKV 投影与维度变换 (B, H, N, D)
#         q = self.q(x).view(B, N, self.num_heads, self.head_dim).permute(0, 2, 1, 3)
#         k = self.k(source).view(B, N, self.num_heads, self.head_dim).permute(0, 2, 1, 3)
#         v = self.v(source).view(B, N, self.num_heads, self.head_dim).permute(0, 2, 1, 3)

#         # 获取 phi 映射
#         phi_q = self.get_phi(q, x_mask)
#         phi_k = self.get_phi(k, source_mask)

#         # 线性注意力聚合 O(N)
#         # KV 聚合: (B, H, 2D, D)
#         kv = torch.matmul(phi_k.transpose(-2, -1), v)
        
#         # 注意力响应: (B, H, N, D)
#         num = torch.matmul(phi_q, kv)
        
#         # 归一化分母
#         k_sum = phi_k.sum(dim=2, keepdim=True)
#         den = torch.matmul(phi_q, k_sum.transpose(-2, -1)).clamp_min(self.attn_eps)

#         # 应用 Head 缩放权重并融合
#         out = (num / den) * self.head_scale
#         out = out.transpose(1, 2).reshape(B, N, C)
        
#         # 局部增强分支 (LEPE)
#         v_img = v.transpose(1, 2).reshape(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         lepe_res = self.lepe(v_img).flatten(2).transpose(1, 2)
        
#         return self.out_proj(out + lepe_res)

# # ==========================================
# # 3. MLLA 结构层：Block 与 Mlp
# # ==========================================
# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x); x = self.act(x); x = self.drop(x)
#         x = self.fc2(x); x = self.drop(x)
#         return x

# class MLLABlock(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., mode="self", qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.input_resolution = input_resolution
        
#         self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm1 = norm_layer(dim)
#         self.in_proj = nn.Linear(dim, dim)
#         self.act_proj = nn.Linear(dim, dim)
#         self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.act = nn.SiLU()
        
#         # 传入 mode (self 或 cross)
#         self.attn = HarmonicLinearAttentionFull(
#             dim=dim, input_resolution=input_resolution, num_heads=num_heads, 
#             qkv_bias=qkv_bias, mode=mode
#         )
#         self.out_proj = nn.Linear(dim, dim)
        
#         self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         H, W = self.input_resolution
#         B, L, C = x.shape

#         # CPE 1
#         x_img = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe1(x_img.contiguous()).flatten(2).permute(0, 2, 1)
#         src_img = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         source = source + self.cpe1(src_img.contiguous()).flatten(2).permute(0, 2, 1)
#         shortcut = x

#         # 前向投影与激活
#         x = self.norm1(x)
#         source = self.norm1(source)
#         act_res = self.act(self.act_proj(x))
        
#         # 深度卷积处理
#         x_p = self.in_proj(x).view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         x = self.act(self.dwc(x_p)).flatten(2).permute(0, 2, 1)
#         src_p = self.in_proj(source).view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         source = self.act(self.dwc(src_p)).flatten(2).permute(0, 2, 1)

#         # 核心注意力计算
#         x = self.attn(x, source, x_mask, source_mask)
#         x = self.out_proj(x * act_res)
#         x = shortcut + x

#         # CPE 2 & MLP
#         x_img2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe2(x_img2.contiguous()).flatten(2).permute(0, 2, 1)
#         x = x + self.mlp(self.norm2(x))
#         return x

# # ==========================================
# # 4. MLLA 组装层
# # ==========================================
# class MLLA(nn.Module):
#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.):
#         super().__init__()
#         # 定义层序列：自注意力和互注意力交替
#         self.layer_configs = ["self", "cross", "self", "cross"]
#         self.layers = nn.ModuleList()
#         for mode in self.layer_configs:
#             self.layers.append(
#                 MLLABlock(feature_dim, input_resolution, nhead, mlp_ratio, mode=mode)
#             )

#     def forward(self, feat0, feat1, mask0=None, mask1=None):
#         for layer, mode in zip(self.layers, self.layer_configs):
#             if mode == "self":
#                 # 自注意力：各自跟各自交互
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif mode == "cross":
#                 # 互注意力：双向交叉引用
#                 f0_new = layer(feat0, feat1, mask0, mask1)
#                 f1_new = layer(feat1, feat0, mask1, mask0)
#                 feat0, feat1 = f0_new, f1_new
#         return feat0, feat1

# # ==========================================
# # 5. 主框架：JointMamba
# # ==========================================
# class JointMamba(nn.Module):
#     def __init__(self, feature_dim=256):
#         super().__init__()
#         self.nhead = 8
#         self.dim = feature_dim
#         self.input_resolution = [104, 104]

#         # 初始化 MLLA 核心，内部已包含非对称阶数逻辑
#         self.atten = MLLA(self.dim, self.input_resolution, self.nhead, mlp_ratio=2.)

#     def forward(self, data):
#         # 假设输入形状 [B, C, L]，转换为 [B, L, C] 进入注意力层
#         feat_8_0 = data['feat_8_0'].permute(0, 2, 1).contiguous()
#         feat_8_1 = data['feat_8_1'].permute(0, 2, 1).contiguous()

#         mask_c0 = data.get("mask0", None)
#         mask_c1 = data.get("mask1", None)

#         # 执行 MLLA (包含 Self 和 Cross 注意力交替)
#         feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)

#         # 更新回数据字典，保持原形状 [B, L, C] 或根据需要 permute 回去
#         data.update({
#             'feat_8_0': feat_8_0, # [B, L, C]
#             'feat_8_1': feat_8_1
#         })
#         return data





# class PreservationFeatureMap(nn.Module):
#     def __init__(self, head_dim):
#         super().__init__()
#         self.head_dim = head_dim

#     def forward(self, x_complex, energy):
#         real = x_complex.real * energy
#         imag = x_complex.imag * energy
       
#         real_pos = F.softplus(real)
#         real_neg = F.softplus(-real)
#         imag_pos = F.softplus(imag)
#         imag_neg = F.softplus(-imag)
#         return torch.cat([real_pos, real_neg, imag_pos, imag_neg], dim=-1)

# # ==========================================
# # 2. 谐波线性注意力
# # ==========================================
# class HarmonicLinearAttentionFull(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, qkv_bias=True, order=2, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.input_resolution = input_resolution
#         self.num_heads = num_heads
#         self.head_dim = dim // num_heads
#         self.order = order
        
#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.v = nn.Linear(dim, dim, bias=qkv_bias)
        
#         self.feature_map = PreservationFeatureMap(self.head_dim)
#         # self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.attn_eps = 1e-6

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         B, N, C = x.shape
#         H, W = self.input_resolution
#         h_dim = self.head_dim

#         q = self.q(x).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
#         k = self.k(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
#         v = self.v(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)

#         if x_mask is not None:
#             q = q * x_mask.view(B, 1, N, 1)
#         if source_mask is not None:
#             k = k * source_mask.view(B, 1, N, 1)
#             v = v * source_mask.view(B, 1, N, 1)

#         def get_phi(t):
#             t_complex = torch.view_as_complex(t.reshape(B, self.num_heads, N, h_dim // 2, 2))
#             r = t_complex.abs()
#             energy = F.softplus(r)
#             norm_z = t_complex / (r + self.attn_eps)
#             harmonic_z = torch.pow(norm_z, self.order)
#             return self.feature_map(harmonic_z, energy)

#         phi_q = get_phi(q) # (B, H, N, 2D)
#         phi_k = get_phi(k) # (B, H, N, 2D)

#         # 线性注意力核心
#         kv = torch.matmul(phi_k.transpose(-2, -1), v)
#         num = torch.matmul(phi_q, kv)
#         k_sum = phi_k.sum(dim=2, keepdim=True)
#         den = torch.matmul(phi_q, k_sum.transpose(-2, -1)).clamp_min(self.attn_eps)

#         out = (num / den).transpose(1, 2).reshape(B, N, C)
        
#         # LEPE 分支
#         # v_img = v.transpose(1, 2).reshape(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         # lepe_res = self.lepe(v_img).flatten(2).transpose(1, 2)
        
#         # return out + lepe_res
#         return out 

# # ==========================================
# # 3. MLLA Block 
# # ==========================================
# class MLLABlock(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., order=2, qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.input_resolution = input_resolution
        
#         # 1. CPE: 条件位置编码分支
#         self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
        
#         # 2. 主路径预处理
#         self.norm1 = norm_layer(dim)
#         self.in_proj = nn.Linear(dim, dim)
#         self.act_proj = nn.Linear(dim, dim) 
#         self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim) 
#         self.act = nn.SiLU()
        
#         # 3. 谐波注意力
#         self.attn = HarmonicLinearAttentionFull(
#             dim=dim, input_resolution=input_resolution, num_heads=num_heads, 
#             qkv_bias=qkv_bias, order=order
#         )
#         self.out_proj = nn.Linear(dim, dim)
        
#         # 4. FFN 部分
#         self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         H, W = self.input_resolution
#         B, L, C = x.shape

#         # --- CPE1 阶段 ---
#         x1 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe1(x1.contiguous()).flatten(2).permute(0, 2, 1)
#         source1 = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         source = source + self.cpe1(source1.contiguous()).flatten(2).permute(0, 2, 1)
#         shortcut = x

#         # --- 变换阶段 ---
#         x = self.norm1(x)
#         source = self.norm1(source)
        
#         # 激活残差分支 (Gating Mechanism)
#         act_res = self.act(self.act_proj(x))
        
#         # # 投影与 DWC 增强
#         x_proj = self.in_proj(x).view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         x = self.act(self.dwc(x_proj)).flatten(2).permute(0, 2, 1)
        
#         src_proj = self.in_proj(source).view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         source = self.act(self.dwc(src_proj)).flatten(2).permute(0, 2, 1)

#         # --- 注意力计算 ---
#         x = self.attn(x, source, x_mask, source_mask)
        
#         # 融合门控并投影
#         x = self.out_proj(x * act_res)
#         x = shortcut + x

#         # --- FFN & CPE2 阶段 ---
#         x2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe2(x2.contiguous()).flatten(2).permute(0, 2, 1)
#         x = x + self.mlp(self.norm2(x))
#         return x


# # ==========================================
# # 3. 基础 MLP 模块
# # ==========================================
# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x)
#         x = self.act(x)
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x



# # ==========================================
# # 5. 最终 MLLA 模块 (支持 Self & Cross Attention)
# # ==========================================
# class MLLA(nn.Module):
#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.):
#         super().__init__()
#         self.layer_names = ["self", "cross"] * 2
        
#         # Self-Attention 通常阶数低，Cross-Attention 阶数高以增强几何匹配
#         self.layers = nn.ModuleList()
#         for name in self.layer_names:
#             order = 1 if name == "self" else 4
#             self.layers.append(
#                 MLLABlock(feature_dim, input_resolution, nhead, mlp_ratio, order=order)
#             )

#     def forward(self, feat0, feat1, mask0=None, mask1=None):
#         for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
#             if name == "self":
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif name == "cross":
#                 feat0 = layer(feat0, feat1, mask0, mask1)
#                 feat1 = layer(feat1, feat0, mask1, mask0)
#         return feat0, feat1


# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()

#         self.nhead = 8  
#         dim = 256
#         input_resolution = [104,104]
#         # input_resolution = [80,60]

#         self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
#         # self.neck = CIM()
       

#     def forward(self, data):
        
#         feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
#         # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
#         # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
#         # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
#         # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)

#         mask_c0 = mask_c1 = None  # mask is useful in training
#         if "mask0" in data:
#             mask_c0, mask_c1 = data["mask0"], data["mask1"]
#         # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
#         # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
#         feat_8_0, feat_8_1 = self.atten(feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
#         # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
#         # B, C, H, W = feat_8_0.shape
#         # feat_c0 = feat_8_0.reshape(B, H*W, C)
#         # feat_c1 = feat_8_1.reshape(B, H*W, C)
#         data.update({
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1
# #         })
# import os

# class PreservationFeatureMap(nn.Module):
#     def __init__(self, head_dim):
#         super().__init__()
#         self.head_dim = head_dim

#     def forward(self, x_complex, energy):
#         real = x_complex.real * energy
#         imag = x_complex.imag * energy
       
#         real_pos = F.softplus(real)
#         real_neg = F.softplus(-real)
#         imag_pos = F.softplus(imag)
#         imag_neg = F.softplus(-imag)
#         return torch.cat([real_pos, real_neg, imag_pos, imag_neg], dim=-1)
#         # return torch.cat([real_pos, imag_pos], dim=-1)
# # ==========================================
# # 2. 谐波线性注意力
# # ==========================================
# class HarmonicLinearAttentionFull(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, qkv_bias=True, order=2, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.input_resolution = input_resolution
#         self.num_heads = num_heads
#         self.head_dim = dim // num_heads
#         self.order = order
        
#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.v = nn.Linear(dim, dim, bias=qkv_bias)
        
#         self.feature_map = PreservationFeatureMap(self.head_dim)
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.attn_eps = 1e-6

#     def forward(self, data,x, source, x_mask=None, source_mask=None):
#         B, N, C = x.shape
#         H = data['imagec_0'].shape[-2]//8
#         W = data['imagec_0'].shape[-1]//8
#         h_dim = self.head_dim

#         q = self.q(x).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
#         k = self.k(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
#         v = self.v(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)

#         if x_mask is not None:
#             q = q * x_mask.view(B, 1, N, 1)
#         if source_mask is not None:
#             k = k * source_mask.view(B, 1, N, 1)
#             v = v * source_mask.view(B, 1, N, 1)

#         def get_phi(t):
#             t_complex = torch.view_as_complex(t.reshape(B, self.num_heads, N, h_dim // 2, 2))
#             r = t_complex.abs()
#             energy = F.softplus(r)
#             norm_z = t_complex / (r + self.attn_eps)
#             harmonic_z = torch.pow(norm_z, self.order)
#             return self.feature_map(harmonic_z, energy)
#             # return harmonic_z*energy
#         phi_q = get_phi(q) # (B, H, N, 2D)
#         phi_k = get_phi(k) # (B, H, N, 2D)

#         # 线性注意力核心
#         kv = torch.matmul(phi_k.transpose(-2, -1), v)
#         num = torch.matmul(phi_q, kv)
#         k_sum = phi_k.sum(dim=2, keepdim=True)
#         den = torch.matmul(phi_q, k_sum.transpose(-2, -1)).clamp_min(self.attn_eps)

#         out = (num / den).transpose(1, 2).reshape(B, N, C)
     
#         # # 计算相似度矩阵 (1, Heads, N, N)
#         # # 因为 BS=1，直接计算即可
#         # attn_matrix = torch.matmul(phi_q, phi_k.transpose(-2, -1)) / den
#         # save_path = '/home/wang/Desktop'
#         # # 压缩精度节省硬盘 (float32 -> float16)
#         # attn_matrix = attn_matrix.half().cpu()

#         # os.makedirs(save_path, exist_ok=True)
#         # tag = "self" if x is source else "cross"
#         # # 文件名：例如 attn_layer0_self_order1.pt
#         # file_name = f"attn_{tag}_order{self.order}.pt"
#         # pdb.set_trace()
#         # torch.save(attn_matrix, os.path.join(save_path, file_name))
#         # LEPE 分支
#         v_img = v.transpose(1, 2).reshape(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         lepe_res = self.lepe(v_img).flatten(2).transpose(1, 2)
        
#         return out + lepe_res

# # ==========================================
# # 3. MLLA Block 
# # ==========================================
# class MLLABlock(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., order=2, qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.input_resolution = input_resolution
        
#         # 1. CPE: 条件位置编码分支
#         self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
        
#         # 2. 主路径预处理
#         self.norm1 = norm_layer(dim)
#         self.in_proj = nn.Linear(dim, dim)
#         self.act_proj = nn.Linear(dim, dim) # 激活分支
#         self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim) # 深度卷积增强
#         self.act = nn.SiLU()
        
#         # 3. 谐波注意力
#         self.attn = HarmonicLinearAttentionFull(
#             dim=dim, input_resolution=input_resolution, num_heads=num_heads, 
#             qkv_bias=qkv_bias, order=order
#         )
#         self.out_proj = nn.Linear(dim, dim)
        
#         # 4. FFN 部分
#         self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, data,x, source, x_mask=None, source_mask=None):
#         H = data['imagec_0'].shape[-2]//8
#         W = data['imagec_0'].shape[-1]//8
#         B, L, C = x.shape

#         # --- CPE1 阶段 ---
#         x1 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe1(x1.contiguous()).flatten(2).permute(0, 2, 1)
#         source1 = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         source = source + self.cpe1(source1.contiguous()).flatten(2).permute(0, 2, 1)
#         shortcut = x

#         # --- 变换阶段 ---
#         x = self.norm1(x)
#         source = self.norm1(source)
        
#         # 激活残差分支 (Gating Mechanism)
#         act_res = self.act(self.act_proj(x))
        
#         # 投影与 DWC 增强
#         x_proj = self.in_proj(x).view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         x = self.act(self.dwc(x_proj)).flatten(2).permute(0, 2, 1)
        
#         src_proj = self.in_proj(source).view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         source = self.act(self.dwc(src_proj)).flatten(2).permute(0, 2, 1)

#         # --- 注意力计算 ---
#         x = self.attn(data,x, source, x_mask, source_mask)
        
#         # 融合门控并投影
#         x = self.out_proj(x * act_res)
#         x = shortcut + x

#         # --- FFN & CPE2 阶段 ---
#         x2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe2(x2.contiguous()).flatten(2).permute(0, 2, 1)
#         x = x + self.mlp(self.norm2(x))
#         return x


# # ==========================================
# # 3. 基础 MLP 模块
# # ==========================================
# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x)
#         x = self.act(x)
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x



# # ==========================================
# # 5. 最终 MLLA 模块 (支持 Self & Cross Attention)
# # ==========================================
# class MLLA(nn.Module):
#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.):
#         super().__init__()
#         self.layer_names = ["self", "cross"] * 2
        
#         # Self-Attention 通常阶数低，Cross-Attention 阶数高以增强几何匹配
#         self.layers = nn.ModuleList()
#         for name in self.layer_names:
#             order = 1 if name == "self" else 1
#             self.layers.append(
#                 MLLABlock(feature_dim, input_resolution, nhead, mlp_ratio, order=order)
#             )

#     def forward(self,data, feat0, feat1, mask0=None, mask1=None):
#         for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
#             if name == "self":
#                 feat0 = layer(data,feat0, feat0, mask0, mask0)
#                 feat1 = layer(data,feat1, feat1, mask1, mask1)
#             elif name == "cross":
#                 feat0 = layer(data,feat0, feat1, mask0, mask1)
#                 feat1 = layer(data,feat1, feat0, mask1, mask0)
#         return feat0, feat1


# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()

#         self.nhead = 8  
#         dim = 256
#         input_resolution = [104,104]
#         # input_resolution = [80,60]

#         self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
#         # self.neck = CIM()
       

#     def forward(self, data):
        
#         feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
#         # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
#         # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
#         # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
#         # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)

#         mask_c0 = mask_c1 = None  # mask is useful in training
#         if "mask0" in data:
#             mask_c0, mask_c1 = data["mask0"], data["mask1"]
#         # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
#         # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
#         feat_8_0, feat_8_1 = self.atten(data, feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
#         # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
#         # B, C, H, W = feat_8_0.shape
#         # feat_c0 = feat_8_0.reshape(B, H*W, C)
#         # feat_c1 = feat_8_1.reshape(B, H*W, C)
#         data.update({
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1
#         })
import os


# class PreservationFeatureMap(nn.Module):
#     def __init__(self, head_dim):
#         super().__init__()
#         self.head_dim = head_dim

#     def forward(self, x_complex, energy):
#         real = x_complex.real * energy
#         imag = x_complex.imag * energy
        
#         real_pos = F.softplus(real)
#         real_neg = F.softplus(-real)
#         imag_pos = F.softplus(imag)
#         imag_neg = F.softplus(-imag)
#         return torch.cat([real_pos, real_neg, imag_pos, imag_neg], dim=-1)
#         # return torch.cat([real_pos, imag_pos], dim=-1)

# # ==========================================
# # 2. 谐波线性注意力
# # ==========================================
# class HarmonicLinearAttentionFull(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, qkv_bias=True, order=2, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.input_resolution = input_resolution
#         self.num_heads = num_heads
#         self.head_dim = dim // num_heads
#         self.order = order
        
#         self.q = nn.Linear(dim, dim, bias=qkv_bias)
#         self.k = nn.Linear(dim, dim, bias=qkv_bias)
#         self.v = nn.Linear(dim, dim, bias=qkv_bias)
        
#         self.feature_map = PreservationFeatureMap(self.head_dim)
#         self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.attn_eps = 1e-6

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         B, N, C = x.shape
#         H, W = self.input_resolution
#         h_dim = self.head_dim

#         q = self.q(x).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
#         k = self.k(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
#         v = self.v(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)

#         if x_mask is not None:
#             q = q * x_mask.view(B, 1, N, 1)
#         if source_mask is not None:
#             k = k * source_mask.view(B, 1, N, 1)
#             v = v * source_mask.view(B, 1, N, 1)

#         def get_phi(t):
#             t_complex = torch.view_as_complex(t.reshape(B, self.num_heads, N, h_dim // 2, 2))
#             r = t_complex.abs()
#             energy = F.softplus(r)
#             norm_z = t_complex / (r + self.attn_eps)
#             harmonic_z = torch.pow(norm_z, self.order)
#             return self.feature_map(harmonic_z, energy)
#             #phi = harmonic_z*energy
#             #return torch.view_as_real(phi).reshape(B, self.num_heads, N, h_dim)
#         phi_q = get_phi(q) # (B, H, N, 2D)
#         phi_k = get_phi(k) # (B, H, N, 2D)


#         # 线性注意力核心
#         kv = torch.matmul(phi_k.transpose(-2, -1), v)
#         num = torch.matmul(phi_q, kv)
#         k_sum = phi_k.sum(dim=2, keepdim=True)
#         den = torch.matmul(phi_q, k_sum.transpose(-2, -1)).clamp_min(self.attn_eps)

#         out = (num / den).transpose(1, 2).reshape(B, N, C)
#         # 计算相似度矩阵 (1, Heads, N, N)
#         # 因为 BS=1，直接计算即可
#         # attn_matrix = torch.matmul(phi_q, phi_k.transpose(-2, -1)) / den
#         # save_path = '/home/wang/Desktop'
#         # # 压缩精度节省硬盘 (float32 -> float16)
#         # attn_matrix = attn_matrix.half().cpu()

#         # os.makedirs(save_path, exist_ok=True)
#         # tag = "self" if x is source else "cross"
#         # # 文件名：例如 attn_layer0_self_order1.pt
#         # file_name = f"attn_{tag}_order{self.order}.pt"
#         # pdb.set_trace()
#         # torch.save(attn_matrix, os.path.join(save_path, file_name))
#         # # LEPE 分支
#         # if x_mask is not None:
#         #     mask_file = f"mask_{tag}_order{self.order}.pt"
#         #     # 保存为字典，包含所有需要的掩码信息
#         #     mask_dict = {
#         #         'x_mask': x_mask.cpu(),
#         #         'source_mask': source_mask.cpu() if source_mask is not None else None,
#         #         'H': H,
#         #         'W': W,
#         #         'N': N
#         #     }
#         #     torch.save(mask_dict, os.path.join(save_path, mask_file))
#         #     print(f"✓ 已保存掩码: {mask_file}")
#         v_img = v.transpose(1, 2).reshape(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         lepe_res = self.lepe(v_img).flatten(2).transpose(1, 2)
        
#         return out + lepe_res

# # ==========================================
# # 3. MLLA Block 
# # ==========================================
# class MLLABlock(nn.Module):
#     def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., order=2, qkv_bias=True, drop=0.,
#                  act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
#         super().__init__()
#         self.dim = dim
#         self.input_resolution = input_resolution
        
#         # 1. CPE: 条件位置编码分支
#         self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)

#         self.norm1 = norm_layer(dim)
#         self.in_proj = nn.Linear(dim, dim)
#         self.act_proj = nn.Linear(dim, dim) 
#         self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim) 
#         self.act = nn.SiLU()
        
#         # 3. 谐波注意力
#         self.attn = HarmonicLinearAttentionFull(
#             dim=dim, input_resolution=input_resolution, num_heads=num_heads, 
#             qkv_bias=qkv_bias, order=order
#         )
#         self.out_proj = nn.Linear(dim, dim)
        
#         # 4. FFN 部分
#         self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
#         self.norm2 = norm_layer(dim)
#         self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         H, W = self.input_resolution
#         B, L, C = x.shape

#         # --- CPE1 阶段 ---
#         x1 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe1(x1.contiguous()).flatten(2).permute(0, 2, 1)
#         source1 = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         source = source + self.cpe1(source1.contiguous()).flatten(2).permute(0, 2, 1)
#         shortcut = x

#         # --- 变换阶段 ---
#         x = self.norm1(x)
#         source = self.norm1(source)
        
#         # 激活残差分支 (Gating Mechanism)
#         act_res = self.act(self.act_proj(x))
        
#         # # 投影与 DWC 增强
#         x_proj = self.in_proj(x).view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         x = self.act(self.dwc(x_proj)).flatten(2).permute(0, 2, 1)
        
#         src_proj = self.in_proj(source).view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
#         source = self.act(self.dwc(src_proj)).flatten(2).permute(0, 2, 1)

#         # --- 注意力计算 ---
#         x = self.attn(x, source, x_mask, source_mask)

#         # 融合门控并投影
#         x = self.out_proj(x * act_res)
#         x = shortcut + x
 
#         # --- FFN & CPE2 阶段 ---
#         x2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
#         x = x + self.cpe2(x2.contiguous()).flatten(2).permute(0, 2, 1)
#         x = x + self.mlp(self.norm2(x))
#         return x


# # ==========================================
# # 3. 基础 MLP 模块
# # ==========================================
# class Mlp(nn.Module):
#     def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
#         super().__init__()
#         out_features = out_features or in_features
#         hidden_features = hidden_features or in_features
#         self.fc1 = nn.Linear(in_features, hidden_features)
#         self.act = act_layer()
#         self.fc2 = nn.Linear(hidden_features, out_features)
#         self.drop = nn.Dropout(drop)

#     def forward(self, x):
#         x = self.fc1(x)
#         x = self.act(x)
#         x = self.drop(x)
#         x = self.fc2(x)
#         x = self.drop(x)
#         return x



# # ==========================================
# # 5. 最终 MLLA 模块 (支持 Self & Cross Attention)
# # ==========================================
# class MLLA(nn.Module):
#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.):
#         super().__init__()
#         self.layer_names = ["self", "cross"] * 2
        
#         # Self-Attention 通常阶数低，Cross-Attention 阶数高以增强几何匹配
#         self.layers = nn.ModuleList()
#         for name in self.layer_names:
#             order = 1 if name == "self" else 4
#             self.layers.append(
#                 MLLABlock(feature_dim, input_resolution, nhead, mlp_ratio, order=order)
#             )

#     def forward(self, feat0, feat1, mask0=None, mask1=None):
#         for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
#             if name == "self":
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif name == "cross":
#                 feat0 = layer(feat0, feat1, mask0, mask1)
#                 feat1 = layer(feat1, feat0, mask1, mask0)
#         return feat0, feat1


# class JointMamba(nn.Module):
#     def __init__(self, feature_dim: int, profiler=None):
#         super().__init__()
#         self.profiler = profiler or PassThroughProfiler()

#         self.nhead = 8  
#         dim = 256
#         input_resolution = [104,104]
#         #input_resolution = [60,80]

#         self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
#         # self.neck = CIM()
       

#     def forward(self, data):
        
#         feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
#         # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
#         # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
#         # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
#         # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)

#         mask_c0 = mask_c1 = None  # mask is useful in training
#         if "mask0" in data:
#             mask_c0, mask_c1 = data["mask0"], data["mask1"]
#         # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
#         # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
#         feat_8_0, feat_8_1 = self.atten(feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
#         # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
#         # B, C, H, W = feat_8_0.shape
#         # feat_c0 = feat_8_0.reshape(B, H*W, C)
#         # feat_c1 = feat_8_1.reshape(B, H*W, C)
#         data.update({
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1
#         })





class PreservationFeatureMap(nn.Module):
    def __init__(self, head_dim):
        super().__init__()
        self.head_dim = head_dim

    def forward(self, x_complex, energy):
        real = x_complex.real * energy
        imag = x_complex.imag * energy
        
        real_pos = F.softplus(real)
        real_neg = F.softplus(-real)
        imag_pos = F.softplus(imag)
        imag_neg = F.softplus(-imag)
        return torch.cat([real_pos, real_neg, imag_pos, imag_neg], dim=-1)
        # return torch.cat([real_pos, imag_pos], dim=-1)

# ==========================================
# 2. 谐波线性注意力
# ==========================================
class HarmonicLinearAttentionFull(nn.Module):
    def __init__(self, dim, input_resolution, num_heads, qkv_bias=True, order=2, **kwargs):
        super().__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.order = order
        
        self.q = nn.Linear(dim, dim, bias=qkv_bias)
        self.k = nn.Linear(dim, dim, bias=qkv_bias)
        self.v = nn.Linear(dim, dim, bias=qkv_bias)
        
        self.feature_map = PreservationFeatureMap(self.head_dim)
        self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
        self.attn_eps = 1e-6

    def forward(self,data, x, source, x_mask=None, source_mask=None):
        B, N, C = x.shape
        H = data['h_8']
        W = data['w_8']
        # H, W = self.input_resolution
        h_dim = self.head_dim

        q = self.q(x).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
        k = self.k(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)
        v = self.v(source).view(B, N, self.num_heads, h_dim).permute(0, 2, 1, 3)

        if x_mask is not None:
            q = q * x_mask.view(B, 1, N, 1)
        if source_mask is not None:
            k = k * source_mask.view(B, 1, N, 1)
            v = v * source_mask.view(B, 1, N, 1)

        def get_phi(t):
            t_complex = torch.view_as_complex(t.reshape(B, self.num_heads, N, h_dim // 2, 2))
            r = t_complex.abs()
            energy = F.softplus(r)
            norm_z = t_complex / (r + self.attn_eps)
            harmonic_z = torch.pow(norm_z, self.order)
            return self.feature_map(harmonic_z, energy)
            #phi = harmonic_z*energy
            #return torch.view_as_real(phi).reshape(B, self.num_heads, N, h_dim)
        phi_q = get_phi(q) # (B, H, N, 2D)
        phi_k = get_phi(k) # (B, H, N, 2D)


        # 线性注意力核心
        kv = torch.matmul(phi_k.transpose(-2, -1), v)
        num = torch.matmul(phi_q, kv)
        k_sum = phi_k.sum(dim=2, keepdim=True)
        den = torch.matmul(phi_q, k_sum.transpose(-2, -1)).clamp_min(self.attn_eps)

        out = (num / den).transpose(1, 2).reshape(B, N, C)
        # 计算相似度矩阵 (1, Heads, N, N)
        # 因为 BS=1，直接计算即可
        # attn_matrix = torch.matmul(phi_q, phi_k.transpose(-2, -1)) / den
        # save_path = '/home/wang/Desktop'
        # # 压缩精度节省硬盘 (float32 -> float16)
        # attn_matrix = attn_matrix.half().cpu()

        # os.makedirs(save_path, exist_ok=True)
        # tag = "self" if x is source else "cross"
        # # 文件名：例如 attn_layer0_self_order1.pt
        # file_name = f"attn_{tag}_order{self.order}.pt"
        # pdb.set_trace()
        # torch.save(attn_matrix, os.path.join(save_path, file_name))
        # # LEPE 分支
        # if x_mask is not None:
        #     mask_file = f"mask_{tag}_order{self.order}.pt"
        #     # 保存为字典，包含所有需要的掩码信息
        #     mask_dict = {
        #         'x_mask': x_mask.cpu(),
        #         'source_mask': source_mask.cpu() if source_mask is not None else None,
        #         'H': H,
        #         'W': W,
        #         'N': N
        #     }
        #     torch.save(mask_dict, os.path.join(save_path, mask_file))
        #     print(f"✓ 已保存掩码: {mask_file}")
        v_img = v.transpose(1, 2).reshape(B, H, W, C).permute(0, 3, 1, 2).contiguous()
        lepe_res = self.lepe(v_img).flatten(2).transpose(1, 2)
        
        return out + lepe_res

# ==========================================
# 3. MLLA Block 
# ==========================================
class MLLABlock(nn.Module):
    def __init__(self, dim, input_resolution, num_heads, mlp_ratio=2., order=2, qkv_bias=True, drop=0.,
                 act_layer=nn.GELU, norm_layer=nn.LayerNorm, **kwargs):
        super().__init__()
        self.dim = dim
        self.input_resolution = input_resolution
        
        # 1. CPE: 条件位置编码分支
        self.cpe1 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)

        self.norm1 = norm_layer(dim)
        self.in_proj = nn.Linear(dim, dim)
        self.act_proj = nn.Linear(dim, dim) 
        self.dwc = nn.Conv2d(dim, dim, 3, padding=1, groups=dim) 
        self.act = nn.SiLU()
        
        # 3. 谐波注意力
        self.attn = HarmonicLinearAttentionFull(
            dim=dim, input_resolution=input_resolution, num_heads=num_heads, 
            qkv_bias=qkv_bias, order=order
        )
        self.out_proj = nn.Linear(dim, dim)
        
        # 4. FFN 部分
        self.cpe2 = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)
        self.norm2 = norm_layer(dim)
        self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)

    def forward(self, data, x, source, x_mask=None, source_mask=None):
        H = data['h_8']
        W = data['w_8']
        # H, W = self.input_resolution
        B, L, C = x.shape

        # --- CPE1 阶段 ---
        x1 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
        x = x + self.cpe1(x1.contiguous()).flatten(2).permute(0, 2, 1)
        source1 = source.reshape(B, H, W, C).permute(0, 3, 1, 2)
        source = source + self.cpe1(source1.contiguous()).flatten(2).permute(0, 2, 1)
        shortcut = x

        # --- 变换阶段 ---
        x = self.norm1(x)
        source = self.norm1(source)
        
        # 激活残差分支 (Gating Mechanism)
        act_res = self.act(self.act_proj(x))
        
        # # 投影与 DWC 增强
        x_proj = self.in_proj(x).view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
        x = self.act(self.dwc(x_proj)).flatten(2).permute(0, 2, 1)
        
        src_proj = self.in_proj(source).view(B, H, W, C).permute(0, 3, 1, 2).contiguous()
        source = self.act(self.dwc(src_proj)).flatten(2).permute(0, 2, 1)

        # --- 注意力计算 ---
        x = self.attn(data ,x, source, x_mask, source_mask)

        # 融合门控并投影
        x = self.out_proj(x * act_res)
        x = shortcut + x
 
        # --- FFN & CPE2 阶段 ---
        x2 = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
        x = x + self.cpe2(x2.contiguous()).flatten(2).permute(0, 2, 1)
        x = x + self.mlp(self.norm2(x))
        return x


# ==========================================
# 3. 基础 MLP 模块
# ==========================================
class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x



# ==========================================
# 5. 最终 MLLA 模块 (支持 Self & Cross Attention)
# ==========================================
class MLLA(nn.Module):
    def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.):
        super().__init__()
        self.layer_names = ["self", "cross"] * 2
        
        # Self-Attention 通常阶数低，Cross-Attention 阶数高以增强几何匹配
        self.layers = nn.ModuleList()
        for name in self.layer_names:
            order = 1 if name == "self" else 3
            self.layers.append(
                MLLABlock(feature_dim, input_resolution, nhead, mlp_ratio, order=order)
            )

    def forward(self,data, feat0, feat1, mask0=None, mask1=None):
        for i, (layer, name) in enumerate(zip(self.layers, self.layer_names)):
            if name == "self":
                feat0 = layer(data, feat0, feat0, mask0, mask0)
                feat1 = layer(data, feat1, feat1, mask1, mask1)
            elif name == "cross":
                feat0 = layer(data, feat0, feat1, mask0, mask1)
                feat1 = layer(data, feat1, feat0, mask1, mask0)
        return feat0, feat1
# from torch.nn import Module
# def elu_feature_map(x):
#     return torch.nn.functional.elu(x) + 1


# class LinearAttention(Module):
#     def __init__(self, eps=1e-6):
#         super().__init__()
#         self.feature_map = elu_feature_map
#         self.eps = eps

#     def forward(self, queries, keys, values, q_mask=None, kv_mask=None):
#         """ Multi-Head linear attention proposed in "Transformers are RNNs"
#         Args:
#             queries: [N, L, H, D]
#             keys: [N, S, H, D]
#             values: [N, S, H, D]
#             q_mask: [N, L]
#             kv_mask: [N, S]
#         Returns:
#             queried_values: (N, L, H, D)
#         """
#         N, L, H, D = queries.shape
#         Q = self.feature_map(queries)
#         K = self.feature_map(keys)
# #         if x_mask is not None:
# #             q = q * x_mask.view(B, 1, N, 1)
# #         if source_mask is not None:
# #             k = k * source_mask.view(B, 1, N, 1)
# #             v = v * source_mask.view(B, 1, N, 1)
#         # set padded position to zero
#         if q_mask is not None:
#             Q = Q * q_mask.view(N, L, 1, 1)
#         if kv_mask is not None:
#             K = K * kv_mask.view(N, L, 1, 1)
#             values = values * kv_mask.view(N, L, 1, 1)

#         v_length = values.size(1)
#         values = values / v_length  # prevent fp16 overflow
#         KV = torch.einsum("nshd,nshv->nhdv", K, values)  # (S,D)' @ S,V
#         Z = 1 / (torch.einsum("nlhd,nhd->nlh", Q, K.sum(dim=1)) + self.eps)
#         queried_values = torch.einsum("nlhd,nhdv,nlh->nlhv", Q, KV, Z) * v_length

#         return queried_values.contiguous()



# class LoFTREncoderLayer(nn.Module):
#     def __init__(self,
#                  d_model,
#                  nhead,
#                  attention='linear'):
#         super(LoFTREncoderLayer, self).__init__()

#         self.dim = d_model // nhead
#         self.nhead = nhead

#         # multi-head attention
#         self.q_proj = nn.Linear(d_model, d_model, bias=False)
#         self.k_proj = nn.Linear(d_model, d_model, bias=False)
#         self.v_proj = nn.Linear(d_model, d_model, bias=False)
#         self.attention = LinearAttention() 
#         self.merge = nn.Linear(d_model, d_model, bias=False)

#         # feed-forward network
#         self.mlp = nn.Sequential(
#             nn.Linear(d_model*2, d_model*2, bias=False),
#             nn.ReLU(True),
#             nn.Linear(d_model*2, d_model, bias=False),
#         )

#         # norm and dropout
#         self.norm1 = nn.LayerNorm(d_model)
#         self.norm2 = nn.LayerNorm(d_model)

#     def forward(self, x, source, x_mask=None, source_mask=None):
#         """
#         Args:
#             x (torch.Tensor): [N, L, C]
#             source (torch.Tensor): [N, S, C]
#             x_mask (torch.Tensor): [N, L] (optional)
#             source_mask (torch.Tensor): [N, S] (optional)
#         """
#         bs = x.size(0)
#         query, key, value = x, source, source

#         # multi-head attention
#         query = self.q_proj(query).view(bs, -1, self.nhead, self.dim)  # [N, L, (H, D)]
#         key = self.k_proj(key).view(bs, -1, self.nhead, self.dim)  # [N, S, (H, D)]
#         value = self.v_proj(value).view(bs, -1, self.nhead, self.dim)
#         message = self.attention(query, key, value, q_mask=x_mask, kv_mask=source_mask)  # [N, L, (H, D)]
#         message = self.merge(message.view(bs, -1, self.nhead*self.dim))  # [N, L, C]
#         message = self.norm1(message)

#         # feed-forward network
#         message = self.mlp(torch.cat([x, message], dim=2))
#         message = self.norm2(message)

#         return x + message


# class LocalFeatureTransformer(nn.Module):
#     """A Local Feature Transformer (LoFTR) module."""

#     def __init__(self, feature_dim, input_resolution, nhead, mlp_ratio=2.):
#         super(LocalFeatureTransformer, self).__init__()

#         self.d_model = feature_dim
#         self.nhead = nhead
#         self.layer_names = ["self", "cross"] * 2
#         encoder_layer = LoFTREncoderLayer(feature_dim, nhead, attention='linear')
#         self.layers = nn.ModuleList([copy.deepcopy(encoder_layer) for _ in range(len(self.layer_names))])
#         self._reset_parameters()

#     def _reset_parameters(self):
#         for p in self.parameters():
#             if p.dim() > 1:
#                 nn.init.xavier_uniform_(p)

#     def forward(self, feat0, feat1, mask0=None, mask1=None):
#         """
#         Args:
#             feat0 (torch.Tensor): [N, L, C]
#             feat1 (torch.Tensor): [N, S, C]
#             mask0 (torch.Tensor): [N, L] (optional)
#             mask1 (torch.Tensor): [N, S] (optional)
#         """

#         assert self.d_model == feat0.size(2), "the feature number of src and transformer must be equal"

#         for layer, name in zip(self.layers, self.layer_names):
#             if name == 'self':
#                 feat0 = layer(feat0, feat0, mask0, mask0)
#                 feat1 = layer(feat1, feat1, mask1, mask1)
#             elif name == 'cross':
#                 feat0 = layer(feat0, feat1, mask0, mask1)
#                 feat1 = layer(feat1, feat0, mask1, mask0)
#             else:
#                 raise KeyError
#         # pdb.set_trace()
#         return feat0, feat1

class JointMamba(nn.Module):
    def __init__(self, feature_dim: int, profiler=None):
        super().__init__()
        self.profiler = profiler or PassThroughProfiler()

        self.nhead = 8  
        dim = 256
        input_resolution = [104,104]
        #input_resolution = [60,80]

        self.atten = MLLA(dim, input_resolution, self.nhead, mlp_ratio=2.,)
        # self.neck = CIM()
       

    def forward(self, data):
        
        feat_8_0, feat_8_1 = data['feat_8_0'], data['feat_8_1']     # [B, C, L]
        # feat_8_0, feat_8_1 = feat_8_0.view(data['bs'], -1, data['h_8'], data['w_8']), feat_8_1.view(data['bs'], -1, data['h_8'], data['w_8'])
        # feat_16_0, feat_16_1 = data['feat_16_0'], data['feat_16_1']
        # f8 = torch.cat([feat_8_0, feat_8_1], dim=0)
        # f16 = torch.cat([feat_16_0, feat_16_1], dim=0)

        mask_c0 = mask_c1 = None  # mask is useful in training
        if "mask0" in data:
            mask_c0, mask_c1 = data["mask0"], data["mask1"]
        # # feat_c0, feat_c1 = f8.chunk(2,dim=0)
        # feat_8_0, feat_8_1 = self.neck(f8, f16, mask_c0, mask_c1)    # [B, C, H, W]
        feat_8_0, feat_8_1 = self.atten(data, feat_8_0.permute(0,2,1).contiguous(), feat_8_1.permute(0,2,1).contiguous(), mask_c0, mask_c1)  # [B, L, C]
        # feat_8_0, feat_8_1 = self.atten(feat_8_0, feat_8_1, mask_c0, mask_c1)  # [B, L, C]
        # B, C, H, W = feat_8_0.shape
        # feat_c0 = feat_8_0.reshape(B, H*W, C)
        # feat_c1 = feat_8_1.reshape(B, H*W, C)
        data.update({
            'feat_8_0': feat_8_0,
            'feat_8_1': feat_8_1
        })

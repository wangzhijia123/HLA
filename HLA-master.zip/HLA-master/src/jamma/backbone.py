import torch
import torch.nn as nn
from kornia.utils import create_meshgrid
from einops import rearrange
from src.convnextv2.convnextv2 import convnextv2_nano
import pdb
# import timm

# class CovNextV2_nano(nn.Module):
#     """
#     使用 timm 官方 convnextv2_nano 作为 backbone，
#     输出 1/4, 1/8, 1/16 分辨率特征（以及对应的 grid）。
#     """
#     def __init__(self):
#         super().__init__()

#         # 1) 建立 timm 模型
#         # 你可以打印 timm.list_models('convnextv2*') 看可用的名字
#         self.backbone = timm.create_model(
#             'convnextv2_nano.fcmae_ft_in22k_in1k',
#             pretrained=True,
#             features_only=True,
#             out_indices=(0, 1, 2, 3),   # 4 个 stage
#         )

#         self.lin_4  = nn.Conv2d( 80, 64,  1)
#         self.lin_8  = nn.Conv2d(160, 128,  1)
#         self.lin_16 = nn.Conv2d(320, 128, 1)

#     def extract_pyramid(self, x):
#         """
#         x: (2B, 3, H, W)
#         return:
#             feat_4:  (2B, C4,  H/4,  W/4)
#             feat_8:  (2B, C8,  H/8,  W/8)
#             feat_16: (2B, C16, H/16, W/16)
#         """
#         feats = self.backbone(x)   # list of 4 tensors

#         feat_4  = self.lin_4(feats[0])   # 1/4
#         feat_8  = self.lin_8(feats[1])   # 1/8
#         feat_16 = self.lin_16(feats[2])  # 1/16

#         return feat_4, feat_8, feat_16

#     def forward(self, data):
#         """
#         data:
#             'imagec_0': (B, 3, H, W)
#             'imagec_1': (B, 3, H, W)
#         update data:
#             'feat_4_0', 'feat_4_1'
#             'feat_8_0', 'feat_8_1'
#             'feat_16_0', 'feat_16_1'
#             以及 h/w/hw/grid_8, grid_16 等信息
#         """
#         pdb.set_trace()
#         B, _, H, W = data['imagec_0'].shape
#         device = data['imagec_0'].device

#         # 拼成 2B 一起过 backbone
#         x = torch.cat([data['imagec_0'], data['imagec_1']], dim=0)   # (2B, 3, H, W)

#         feat_4, feat_8, feat_16 = self.extract_pyramid(x)
#         feat_4_0,  feat_4_1  = feat_4.split(B, dim=0)
#         feat_8_0,  feat_8_1  = feat_8.split(B, dim=0)
#         feat_16_0, feat_16_1 = feat_16.split(B, dim=0)

#         # 1/8 网格（你原来的逻辑）
#         scale_8 = 8
#         h_8, w_8 = H // scale_8, W // scale_8
#         grid_8_single = rearrange(
#             (create_meshgrid(h_8, w_8, False, device) * scale_8).squeeze(0),
#             'h w t -> (h w) t'
#         )   # (h_8 * w_8, 2)
#         grid_8 = torch.stack([grid_8_single] * B, dim=0)  # (B, h_8*w_8, 2)

#         data.update({
#             'bs': B,
#             'feat_4_0': feat_4_0,
#             'feat_4_1': feat_4_1,

#             'c_8':  feat_8_0.shape[1],
#             'h_8':  h_8,
#             'w_8':  w_8,
#             'hw_8': h_8 * w_8,
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1,
#             'grid_8':  grid_8,

#             'c_16':  feat_16_0.shape[1],
#             'feat_16_0': feat_16_0,
#             'feat_16_1': feat_16_1,
#         })
class CovNextV2_nano(nn.Module):
    def __init__(self):
        super().__init__()
        self.cnn = convnextv2_nano()
        self.cnn.norm = None
        self.cnn.head = None
        self.cnn.downsample_layers[2] = None
        self.cnn.downsample_layers[3] = None
        self.cnn.stages[2] = None
        self.cnn.stages[3] = None

        state_dict = torch.hub.load_state_dict_from_url(
            'https://github.com/leoluxxx/JamMa/releases/download/v0.1/convnextv2_nano_pretrain.ckpt',
            file_name='convnextv2_nano_pretrain.ckpt')
        self.cnn.load_state_dict(state_dict, strict=True)

        self.lin_4 = nn.Conv2d(80, 128, 1)
        self.lin_8 = nn.Conv2d(160, 256, 1)
        # self.lin_16 = nn.Conv2d(320, 128, 1)
        # self.head_16 = nn.Sequential(
        #     nn.Conv2d(256, 256, kernel_size=3, stride=2, padding=1),  # stride=2 → 下采样一倍
        #     nn.ReLU(inplace=True),
        # )
    def forward(self, data):
        B, _, H, W = data['imagec_0'].shape
        x = torch.cat([data['imagec_0'], data['imagec_1']], 0)
        feature_pyramid = self.cnn.forward_features_8(x)
        feat_8_0, feat_8_1 = self.lin_8(feature_pyramid[8]).split(B)
        feat_4_0, feat_4_1 = self.lin_4(feature_pyramid[4]).split(B)
        # feat_16_0, feat_16_1 = self.lin_16(feature_pyramid[16]).split(B)
        # feat_16_0 = self.head_16(feat_8_0)   # (B, 256, H/16, W/16)
        # feat_16_1 = self.head_16(feat_8_1)
        scale = 8
        h_8, w_8 = H//scale, W//scale
        device = data['imagec_0'].device
        grid = [rearrange((create_meshgrid(h_8, w_8, False, device) * scale).squeeze(0), 'h w t->(h w) t')] * B  # kpt_xy
        grid_8 = torch.stack(grid, 0)

        data.update({
            'bs': B,
            'c': feat_8_0.shape[1],
            'h_8': h_8,
            'w_8': w_8,
            'hw_8': h_8 * w_8,
            'feat_8_0': feat_8_0,
            'feat_8_1': feat_8_1,
            # 'feat_16_0': feat_16_0,
            # 'feat_16_1': feat_16_1,
            'feat_4_0': feat_4_0,
            'feat_4_1': feat_4_1,
            'grid_8': grid_8,
        })





# def conv1x1(in_planes, out_planes, stride=1, bias=False):
#     """1x1 convolution without padding"""
#     return nn.Conv2d(
#         in_planes, out_planes, kernel_size=1, stride=stride, padding=0, bias=bias
#     )


# def conv3x3(in_planes, out_planes, stride=1, groups=1, bias=False):
#     """3x3 convolution with padding"""
#     return nn.Conv2d(
#         in_planes,
#         out_planes,
#         kernel_size=3,
#         stride=stride,
#         padding=1,
#         groups=groups,
#         bias=bias,
#     )


# class BasicBlock(nn.Module):
#     def __init__(self, in_planes, planes, stride=1):
#         super().__init__()
#         self.conv1 = conv3x3(in_planes, planes, stride)
#         self.conv2 = conv3x3(planes, planes)
#         self.bn1 = nn.GroupNorm(8, planes)
#         self.bn2 = nn.GroupNorm(8, planes)
#         self.relu = nn.ReLU(inplace=True)

#         if stride == 1:
#             self.downsample = None
#         else:
#             self.downsample = nn.Sequential(
#                 conv1x1(in_planes, planes, stride=stride), nn.GroupNorm(8, planes)
#             )

#     def forward(self, x):
#         y = x
#         y = self.relu(self.bn1(self.conv1(y)))
#         y = self.bn2(self.conv2(y))

#         if self.downsample is not None:
#             x = self.downsample(x)

#         return self.relu(x + y)


# class ResNet18(nn.Module):
#     """
#     Fewer channels
#     """

#     def __init__(self):
#         super().__init__()
#         # Config
#         block_dims = [32, 64, 128, 256]

#         # Networks
#         self.conv3 = nn.Conv2d(
#             3, block_dims[0], kernel_size=7, stride=2, padding=3, bias=False
#         )
#         self.bn1 = nn.GroupNorm(8, block_dims[0])
#         self.relu = nn.ReLU(inplace=True)
#         self.layer1 = self._make_layer(
#             BasicBlock, block_dims[0], block_dims[0], stride=1
#         )  # 1/2
#         self.layer2 = self._make_layer(
#             BasicBlock, block_dims[0], block_dims[1], stride=2
#         )  # 1/4
#         self.layer3 = self._make_layer(
#             BasicBlock, block_dims[1], block_dims[2], stride=2
#         )  # 1/8
#         self.layer4 = self._make_layer(
#             BasicBlock, block_dims[2], block_dims[3], stride=2
#         )  # 1/16

#         for m in self.modules():
#             if isinstance(m, nn.Conv2d):
#                 nn.init.kaiming_normal_(
#                     m.weight, mode="fan_out", nonlinearity="relu")
#             elif isinstance(m, nn.GroupNorm):
#                 nn.init.constant_(m.weight, 1)
#                 nn.init.constant_(m.bias, 0)

#     def _make_layer(self, block, in_dim, out_dim, stride=1):
#         layer1 = block(in_dim, out_dim, stride=stride)
#         layer2 = block(out_dim, out_dim, stride=1)
#         layers = (layer1, layer2)

#         return nn.Sequential(*layers)

#     def forward(self, data):
#         B, _, H, W = data['imagec_0'].shape
#         x = torch.cat([data['imagec_0'], data['imagec_1']], 0)
#         x0 = self.relu(self.bn1(self.conv3(x)))
#         x1 = self.layer1(x0)  # 1/2
#         x2 = self.layer2(x1)  # 1/4
#         x3 = self.layer3(x2)  # 1/8
#         x4 = self.layer4(x3)  # 1/16


#         feat_2_0, feat_2_1 = x1.split(B)    #[B, C, H, W]
#         feat_4_0, feat_4_1 = x2.split(B)
#         feat_8_0, feat_8_1 = x3.split(B)
#         feat_16_0, feat_16_1 = x4.split(B)
        
#         scale = 8
#         h_8, w_8 = H//scale, W//scale
#         device = data['imagec_0'].device
#         grid = [rearrange((create_meshgrid(h_8, w_8, False, device) * scale).squeeze(0), 'h w t->(h w) t')] * B  # kpt_xy
#         grid_8 = torch.stack(grid, 0)

#         data.update({
#             'bs': B,
#             'c': feat_8_0.shape[1],
#             'c16': feat_16_0.shape[1],
#             'h_8': h_8,
#             'w_8': w_8,
#             'hw_8': h_8 * w_8,
#             # 'f8': x3,
#             # 'f16': x4,
#             'feat_2_0': feat_2_0,#[B, C, H, W]
#             'feat_2_1': feat_2_1,
#             'feat_4_0': feat_4_0,
#             'feat_4_1': feat_4_1,
#             'feat_8_0': feat_8_0,
#             'feat_8_1': feat_8_1,
#             'feat_16_0': feat_16_0,
#             'feat_16_1': feat_16_1,
#             'grid_8': grid_8,
#         })


